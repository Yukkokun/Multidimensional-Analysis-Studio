//
//  ContentView.swift
//  Multidimensional Analysis MacTag
//
//  真正的界面在 Studio/RootView.swift；这里保留一个薄壳，便于 SwiftUI 预览。
//

import SwiftUI

@MainActor
struct ContentView: View {
    @State private var workspace = Workspace()

    var body: some View {
        RootView()
            .environment(workspace)
    }
}

#Preview {
    ContentView()
        .frame(width: 1180, height: 780)
}
