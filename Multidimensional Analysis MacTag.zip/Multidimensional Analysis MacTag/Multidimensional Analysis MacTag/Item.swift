//
//  Item.swift
//  Multidimensional Analysis MacTag
//
//  Created by 集莜轲 on 2026/10/22.
//

import Foundation
import SwiftData

@Model
final class Item {
    var timestamp: Date
    
    init(timestamp: Date) {
        self.timestamp = timestamp
    }
}
