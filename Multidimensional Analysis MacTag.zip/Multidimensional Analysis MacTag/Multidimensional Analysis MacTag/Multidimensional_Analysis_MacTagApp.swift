//
//  Multidimensional_Analysis_MacTagApp.swift
//  Multidimensional Analysis MacTag
//
//  MA Studio —— 原生 macOS 版 Multidimensional Analysis Tagger
//

import SwiftUI
import AppKit
import MATCore

final class AppDelegate: NSObject, NSApplicationDelegate {
    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.regular)
        NSApp.activate(ignoringOtherApps: true)
        // 截图/演示用：强制外观
        switch ProcessInfo.processInfo.environment["MAT_APPEARANCE"] {
        case "dark":  NSApp.appearance = NSAppearance(named: .darkAqua)
        case "light": NSApp.appearance = NSAppearance(named: .aqua)
        default: break
        }
    }
    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool { true }
}

@main
@MainActor
struct Multidimensional_Analysis_MacTagApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) private var appDelegate
    @State private var workspace = Workspace()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environment(workspace)
                .frame(minWidth: 1080, minHeight: 720)
        }
        .windowStyle(.hiddenTitleBar)
        .windowToolbarStyle(.unified(showsTitle: false))
        .commands {
            CommandGroup(replacing: .newItem) {
                Button("导入语料…") {
                    ImportPanel.open { workspace.importItems($0) }
                }
                .keyboardShortcut("o")
            }
            CommandGroup(replacing: .help) {
                Button("Introduction") { workspace.helpSheet = .introduction }
                Button("Manual") { workspace.helpSheet = .manual }
                Button("GitHub Homepage") { workspace.helpSheet = .github }
                Divider()
                Button("Show License") { workspace.helpSheet = .license }
                Button("Show Version History") { workspace.helpSheet = .versionHistory }
                Divider()
                Button("Check for Update") { workspace.helpSheet = .update }
            }
            CommandGroup(after: .toolbar) {
                Button("概览") { workspace.tab = .overview }.keyboardShortcut("1")
                Button("维度") { workspace.tab = .dimensions }.keyboardShortcut("2")
                Button("特征") { workspace.tab = .features }.keyboardShortcut("3")
                Button("分布") { workspace.tab = .distribution }.keyboardShortcut("4")
                Button("对比") { workspace.tab = .compare }.keyboardShortcut("5")
            }
        }

        Settings {
            SettingsPane()
                .environment(workspace)
        }
    }
}

@MainActor
struct SettingsPane: View {
    @Environment(Workspace.self) private var ws

    var body: some View {
        @Bindable var ws = ws
        Form {
            Section("Language") {
                Picker("Interface language", selection: Bindable(Localizer.shared).lang) {
                    ForEach(Lang.allCases) { lang in
                        Text(lang.label).tag(lang)
                    }
                }
                .pickerStyle(.segmented)
                Text("Switching applies immediately — no restart needed.")
                    .font(.caption).foregroundStyle(.secondary)
            }
            Section(T("分析")) {
                Picker(T("TTR 窗口"), selection: $ws.settings.ttrWindow) {
                    Text(T("400（默认）")).tag(400)
                    Text("200").tag(200)
                    Text("100").tag(100)
                }
                Toggle(T("Zscore correction（z 截断 ±5）"), isOn: $ws.settings.clamp)
                Toggle(T("Count: 全部词性（All tags）"), isOn: $ws.settings.allTags)
                Text(T("改动立即生效；已有语料需要 ⌘R 重跑才会用新设置。"))
                    .font(.caption).foregroundStyle(.secondary)
            }
            Section(T("引擎")) {
                LabeledContent("Java", value: ws.engine.java?.lastPathComponent ?? T("未找到"))
                LabeledContent(T("模型 .tagger"), value: ws.engine.model?.lastPathComponent ?? T("未找到"))
                Button(T("打开引擎设置…")) { ws.showEngineSheet = true }
            }
        }
        .formStyle(.grouped)
        .frame(width: 460)
    }
}
