import Foundation

// MARK: - 版本与仓库信息

enum AppInfo {
    static let name = "MA Studio"

    /// 版本号只有一个来源：bundle 的 CFBundleShortVersionString
    /// （Xcode 来自 MARKETING_VERSION，SPM 构建来自 Tools/ui-build 生成的 Info.plist）。
    /// 直接跑二进制（没有 bundle）时回退到下面的默认值。
    static var version: String {
        if let v = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String,
           !v.isEmpty {
            return v
        }
        return fallbackVersion
    }
    static let fallbackVersion = "1.1.1"
    static var build: String {
        (Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String) ?? "1"
    }
    static let buildDate = "2026-10-25"
    static let copyright = "© 2026 MA Studio · GPL-3.0"

    /// 仓库还没公开。发布后把 owner/repo 换成真实值、并把 isPublished 改成 true，
    /// 「Check for Update」与「GitHub Homepage」立即生效，不需要改别的地方。
    static let repoOwner = "your-github-name"
    static let repoName = "ma-studio"
    static let isPublished = false

    static var githubURL: URL { URL(string: "https://github.com/\(repoOwner)/\(repoName)")! }
    static var releasesAPI: URL { URL(string: "https://api.github.com/repos/\(repoOwner)/\(repoName)/releases/latest")! }
    static var releasesPageURL: URL { githubURL.appendingPathComponent("releases") }
}

// MARK: - 版本历史
//
// 每次更新把版本号 +0.1，并在这里加一条。界面里的「Show Version History」直接读它。

struct ChangelogEntry: Identifiable {
    var version: String
    var date: String
    var summary: LText
    var notes: [LText]
    var id: String { version }
}

enum Changelog {
    /// 版本号规则：功能性更新 +0.1（1.1 → 1.2），修 bug +0.0.1（1.1 → 1.1.1）
    static let entries: [ChangelogEntry] = [
        .init(version: "1.1.1", date: "2026-10-25",
              summary: LText("修复：补完界面翻译与图表标签",
                             "Fixes: remaining untranslated UI and chart labels"),
              notes: [
                LText("补全遗漏的双语文案：空状态、Introduction、版本历史、进度提示、设置项、校正方式下拉",
                      "Completed the missing bilingual copy: empty state, Introduction, version history, progress labels, settings, correction menu"),
                LText("维度图与横向柱状图的数值标签不再压住柱子，轴标签留出边距",
                      "Value labels no longer sit on top of the bars; axis labels get proper margin"),
                LText("六维概览的双语料改为同一维度内上下两条，不再左右挤压",
                      "Two-corpus six-dimension view now stacks the two bars within each dimension instead of squeezing them side by side"),
                
              ]),
        .init(version: "1.1", date: "2026-10-25",
              summary: LText("界面语言（English / 简体中文）与图文手册",
                             "Interface language (English / Chinese) and an illustrated manual"),
              notes: [
                LText("全界面支持中英双语，默认英语，设置里即时切换",
                      "The whole interface is bilingual, English by default, switched live in Settings"),
                LText("Help → Manual：七章手册，配现场绘制的示意图与数字速查表",
                      "Help → Manual: seven chapters with live-drawn diagrams and a glossary"),
                LText("Help 菜单：Introduction / Manual / GitHub Homepage / Show License / Show Version History / Check for Update",
                      "Help menu: Introduction / Manual / GitHub Homepage / Show License / Show Version History / Check for Update"),
                LText("各数据表可复制到 Excel、可导出为图片",
                      "Every data table can be copied into Excel or exported as an image"),
                LText("Z 对比支持逐变量隐藏，以及 BH-FDR / Holm / 不校正三种校正",
                      "Z-compare supports hiding individual variables and BH-FDR / Holm / no correction"),
              ]),
        .init(version: "1.0", date: "2026-10-24",
              summary: LText("首个版本：多维分析的原生 macOS 实现",
                             "First release: a native macOS implementation of Multidimensional Analysis"),
              notes: [
                LText("分析内核与 Perl 原版逐字节一致：token 流、Statistics（85 列）、Zscores、Dimensions 三层回归全绿",
                      "The analysis core matches the original Perl byte for byte: token stream, Statistics (85 columns), Zscores and Dimensions all pass"),
                LText("八个页签：概览 / 维度 / 六维 / 文本类型 / 特征 / 分布 / 对比 / Z 对比",
                      "Eight tabs: Overview / Dimensions / Six dims / Text types / Features / Distribution / Compare / Z-compare"),
                LText("维度图两种呈现：误差线图、横向柱状图；8 个参考体裁各自配色",
                      "Two dimension views: error bars and horizontal bars, with a colour per reference genre"),
                LText("文本类型两种呈现：散点（每维一列、每类一个带名字的点）、维度轮廓折线",
                      "Two text-type views: the scatter (one column per dimension, a labelled dot per type) and profile lines"),
                LText("双语料对比：维度图叠加、六维并排、Z 分数逐变量比较",
                      "Two-corpus comparison: overlay on the dimension chart, side-by-side six dimensions, variable-by-variable z-scores"),
                LText("分布页给出正态性检验与「该用 t 还是 U」的建议；对比页并列 Welch t 与 Mann–Whitney U，附效应量与 95% 置信区间",
                      "The Distribution tab tests normality and recommends t or U; Compare runs Welch's t and Mann–Whitney U side by side with effect sizes and 95% confidence intervals"),
                LText("导出：六张维度图（可合并）、文本类型大图、三个 CSV、各数据表的复制与图片导出",
                      "Export: six dimension charts (optionally merged), a text-type chart, three CSVs, plus table copy and image export"),
                LText("GPL-3.0 许可", "Released under GPL-3.0"),
              ]),
    ]

    static var current: ChangelogEntry { entries[0] }
}

// MARK: - 检查更新

@MainActor
enum UpdateChecker {

    enum State: Equatable {
        case idle
        case checking
        case upToDate(current: String)
        case newer(current: String, latest: String, url: URL)
        case notPublished
        case failed(String)
    }

    /// 语义化比较：1.2 > 1.10 这种要按数字比，不能按字符串比
    static func isNewer(_ lhs: String, than rhs: String) -> Bool {
        let a = lhs.trimmingCharacters(in: CharacterSet(charactersIn: "vV")).split(separator: ".")
        let b = rhs.trimmingCharacters(in: CharacterSet(charactersIn: "vV")).split(separator: ".")
        for i in 0..<max(a.count, b.count) {
            let x = i < a.count ? Int(a[i]) ?? 0 : 0
            let y = i < b.count ? Int(b[i]) ?? 0 : 0
            if x != y { return x > y }
        }
        return false
    }

    static func check() async -> State {
        guard AppInfo.isPublished else {
            // 还没有公开仓库：给一点「确实检查过」的延迟，避免瞬间返回显得像假的
            try? await Task.sleep(nanoseconds: 350_000_000)
            return .notPublished
        }
        do {
            var request = URLRequest(url: AppInfo.releasesAPI)
            request.timeoutInterval = 12
            request.setValue("application/vnd.github+json", forHTTPHeaderField: "Accept")
            let (data, response) = try await URLSession.shared.data(for: request)
            guard let http = response as? HTTPURLResponse else {
                return .failed("没有收到有效响应")
            }
            if http.statusCode == 404 {
                return .notPublished
            }
            guard http.statusCode == 200 else {
                return .failed("GitHub 返回 \(http.statusCode)")
            }
            guard let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let tag = json["tag_name"] as? String else {
                return .failed("返回内容里没有版本号")
            }
            let htmlURL = (json["html_url"] as? String).flatMap(URL.init(string:)) ?? AppInfo.releasesPageURL
            if isNewer(tag, than: AppInfo.version) {
                return .newer(current: AppInfo.version, latest: tag, url: htmlURL)
            }
            return .upToDate(current: AppInfo.version)
        } catch {
            return .failed(error.localizedDescription)
        }
    }
}
