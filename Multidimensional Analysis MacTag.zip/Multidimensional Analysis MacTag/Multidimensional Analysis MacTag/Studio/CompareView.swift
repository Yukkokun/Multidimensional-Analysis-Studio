import SwiftUI
import Charts
import MATCore

// MARK: - 两个语料对比

@MainActor
struct CompareView: View {
    @Environment(Workspace.self) private var ws

    private var left: Corpus? { ws.corpora.first { $0.id == ws.compareLeft } ?? ws.corpora.first }
    private var right: Corpus? {
        let candidate = ws.corpora.first { $0.id == ws.compareRight }
        if let c = candidate, c.id != left?.id { return c }
        return ws.corpora.first { $0.id != left?.id }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            if ws.corpora.count < 2 {
                EmptyHint(icon: "arrow.left.arrow.right",
                          title: T("需要两个语料库"),
                          message: T("再导入一个语料库，就能做组间比较。\n每个语料库里至少要有 4 篇，Shapiro–Wilk 才给得出结论。"))
            } else if let l = left, let r = right {
                pickers(l, r)
                mainCard(l, r)
                dimensionTable(l, r)
            }
        }
    }

    // MARK: 选择

    private func pickers(_ l: Corpus, _ r: Corpus) -> some View {
        @Bindable var ws = ws
        return HStack(spacing: 10) {
            corpusMenu(title: T("A 组"), selection: $ws.compareLeft, fallback: l)
            Image(systemName: "arrow.left.arrow.right")
                .font(.system(size: 11, weight: .semibold))
                .foregroundStyle(.tertiary)
            corpusMenu(title: T("B 组"), selection: $ws.compareRight, fallback: r)

            Divider().frame(height: 18)

            Menu {
                Section("维度") {
                    ForEach(Dims.all) { m in
                        Button("D\(m.id) · \(m.title)") { ws.compareMetric = .dimension(m.id) }
                    }
                }
                Section("指标与特征") {
                    Button("AWL") { ws.compareMetric = .feature("AWL") }
                    Button("TTR") { ws.compareMetric = .feature("TTR") }
                    Divider()
                    ForEach(Catalog.shared.featureOrder.filter { $0 != "AWL" && $0 != "TTR" }, id: \.self) { f in
                        Button("\(f) · \(Features.glossText(f))") { ws.compareMetric = .feature(f) }
                    }
                }
            } label: {
                HStack(spacing: 6) {
                    Circle().fill(ws.compareMetric.color).frame(width: 6, height: 6)
                    Text(ws.compareMetric.title).font(.system(size: 11.5, weight: .medium))
                    Image(systemName: "chevron.down").font(.system(size: 8, weight: .semibold))
                        .foregroundStyle(.tertiary)
                }
                .padding(.horizontal, 9).padding(.vertical, 5)
                .background { Capsule().fill(.thinMaterial) }
            }
            .menuStyle(.borderlessButton)
            .fixedSize()

            Spacer()
        }
    }

    private func corpusMenu(title: String, selection: Binding<Corpus.ID?>, fallback: Corpus) -> some View {
        Menu {
            ForEach(ws.corpora) { c in
                Button(c.name) { selection.wrappedValue = c.id }
            }
        } label: {
            HStack(spacing: 6) {
                Text(title).font(.system(size: 9.5, weight: .semibold)).foregroundStyle(.tertiary)
                Text((selection.wrappedValue.flatMap { id in ws.corpora.first { $0.id == id }?.name }) ?? fallback.name)
                    .font(.system(size: 12, weight: .medium))
                Text(T("%@ 篇", fallback.documents.count))
                    .font(.system(size: 9.5, design: .rounded)).foregroundStyle(.tertiary)
                Image(systemName: "chevron.down").font(.system(size: 8, weight: .semibold))
                    .foregroundStyle(.tertiary)
            }
            .padding(.horizontal, 9).padding(.vertical, 5)
            .background {
                Capsule().fill(.thinMaterial)
                    .overlay { Capsule().strokeBorder(Color.primary.opacity(0.07), lineWidth: 1) }
            }
        }
        .menuStyle(.borderlessButton)
        .fixedSize()
    }

    // MARK: 主卡

    private func mainCard(_ l: Corpus, _ r: Corpus) -> some View {
        let mL = ws.compareMetric
        let a = l.samples(mL), b = r.samples(mL)
        let sa = Stats.describe(a), sb = Stats.describe(b)
        let t = Stats.welchT(a, b)
        let u = Stats.mannWhitneyU(a, b)
        let normalA = Stats.shapiroWilk(a)?.isNormal
        let normalB = Stats.shapiroWilk(b)?.isNormal
        let useT = (normalA ?? false) && (normalB ?? false)

        // 柱子是从 0 起算的，y 域必须包含 0，否则柱体会画到绘图区之外（会压住下面的卡片）
        let lo = min(0, min(sa.mean - sa.sem, sb.mean - sb.sem))
        let hi = max(0, max(sa.mean + sa.sem, sb.mean + sb.sem))
        let pad = max(0.4, (hi - lo) * 0.12)

        return VStack(alignment: .leading, spacing: 14) {
            HStack(alignment: .firstTextBaseline) {
                HStack(spacing: 6) {
                    SectionHeader(mL.title)
                    HStack(spacing: 3) {
                        Text(T("每根须是 ±1 标准误")).font(.system(size: 11.5)).foregroundStyle(.secondary)
                        HelpDot(term: T("标准误（SEM）"),
                                plain: T("均值的「抖动幅度」：标准误 = 标准差 ÷ √篇数。它告诉您「如果重抽一批文本，均值大概会晃多少」，所以比标准差小得多。"),
                                example: T("10 篇、标准差 5，标准误约 1.6；须很短说明均值估得比较稳。"),
                                width: 300)
                    }
                }
                Spacer()
                Badge(text: T(useT ? "推荐 Welch t" : "推荐 Mann–Whitney U"),
                      tint: useT ? Dims.color(5) : Dims.color(2), filled: true)
            }

            Chart {
                BarMark(x: .value("组", "A · \(l.name)"), y: .value("均值", sa.mean), width: .ratio(0.5))
                    .foregroundStyle(LinearGradient(colors: [SeriesColors.a.opacity(0.45), SeriesColors.a],
                                                    startPoint: .bottom, endPoint: .top))
                    .cornerRadius(8)
                    .annotation(position: .top, spacing: 4) {
                        Text(String(format: "%.2f", sa.mean))
                            .font(.system(size: 11, weight: .semibold, design: .rounded).monospacedDigit())
                            .foregroundStyle(SeriesColors.a)
                    }
                BarMark(x: .value("组", "B · \(r.name)"), y: .value("均值", sb.mean), width: .ratio(0.5))
                    .foregroundStyle(LinearGradient(colors: [SeriesColors.b.opacity(0.45), SeriesColors.b],
                                                    startPoint: .bottom, endPoint: .top))
                    .cornerRadius(8)
                    .annotation(position: .top, spacing: 4) {
                        Text(String(format: "%.2f", sb.mean))
                            .font(.system(size: 11, weight: .semibold, design: .rounded).monospacedDigit())
                            .foregroundStyle(SeriesColors.b)
                    }

                // 标准误须
                BarMark(x: .value("组", "A · \(l.name)"),
                        yStart: .value("lo", sa.mean - sa.sem), yEnd: .value("hi", sa.mean + sa.sem),
                        width: .fixed(4))
                    .foregroundStyle(Color.primary.opacity(0.55))
                    .cornerRadius(2)
                BarMark(x: .value("组", "B · \(r.name)"),
                        yStart: .value("lo", sb.mean - sb.sem), yEnd: .value("hi", sb.mean + sb.sem),
                        width: .fixed(4))
                    .foregroundStyle(Color.primary.opacity(0.55))
                    .cornerRadius(2)

                RuleMark(y: .value("zero", 0))
                    .foregroundStyle(Color.primary.opacity(0.10))
            }
            .chartYScale(domain: (lo - pad)...(hi + pad))
            .chartXAxis {
                AxisMarks { v in
                    AxisValueLabel {
                        if let s = v.as(String.self) {
                            Text(s).font(.system(size: 11, weight: .medium))
                        }
                    }
                }
            }
            .chartYAxis {
                AxisMarks(position: .leading, values: .automatic(desiredCount: 5)) { v in
                    AxisGridLine().foregroundStyle(Color.primary.opacity(0.05))
                    AxisValueLabel {
                        if let d = v.as(Double.self) {
                            Text(String(format: "%.1f", d))
                                .font(.system(size: 10, design: .rounded).monospacedDigit())
                                .foregroundStyle(.tertiary)
                        }
                    }
                }
            }
            .frame(height: 240)
            .clipped()

            HStack(spacing: 12) {
                testCard("Welch t", value: t.map { String(format: "p = %.4f", $0.p) } ?? "—",
                         detail: t.map { r in
                             let ci = r.ci95
                             return String(format: "t = %.2f, df = %.1f, d = %.2f\n95%% CI [%.2f, %.2f]",
                                           r.t, r.df, r.cohensD, ci.low, ci.high)
                         } ?? T("样本不足"),
                         significant: t?.isSignificant ?? false,
                         highlighted: useT, tint: Dims.color(5),
                         help: (T("Welch t 检验"),
                                T("比较两组的平均值是否有差别。Welch 版本不要求两组方差一样大，样本量不同也照常能用，所以比课本上的「学生 t」更稳。"),
                                T("p = 0.03 表示：如果两组真的没差别，看到这么大差距的概率只有 3%。")))
                testCard("Mann–Whitney U", value: u.map { String(format: "p = %.4f", $0.p) } ?? "—",
                         detail: u.map { String(format: "U = %.0f, z = %.2f, r = %.2f", $0.u, $0.z, $0.rankBiserial) } ?? T("样本不足"),
                         significant: u?.isSignificant ?? false,
                         highlighted: !useT, tint: Dims.color(2),
                         help: (T("Mann–Whitney U 检验"),
                                T("不比平均值，比「排名」：把两组混在一起排序，看 A 组的名次是不是整体靠前。分布偏斜、有离群值时比 t 检验可靠。"),
                                T("A 组 10 篇全排在前 10 名 → U 很小 → p 很小，说明两组确实不一样。")))
                deltaCard(sa, sb)
            }

            HStack(spacing: 6) {
                Image(systemName: "info.circle").font(.system(size: 10)).foregroundStyle(.tertiary)
                Text(hint(a: a, b: b, normalA: normalA, normalB: normalB, useT: useT))
                    .font(.system(size: 10.5))
                    .foregroundStyle(.secondary)
            }
        }
        .glassCard()
    }

    private func hint(a: [Double], b: [Double], normalA: Bool?, normalB: Bool?, useT: Bool) -> String {
        if a.count < 4 || b.count < 4 {
            return T("有一组少于 4 篇，正态性检验不可用；p 值仅供参考。")
        }
        if useT {
            return T("两组都没偏离正态（p ≥ 0.05），用 t 检验；Welch 版本不要求方差齐性，比学生 t 更稳。")
        }
        return T("至少一组偏离正态（A: %@，B: %@），优先看 U 检验。", normalA == true ? T("正态") : T("非正态"), normalB == true ? T("正态") : T("非正态"))
    }

    private func testCard(_ title: String, value: String, detail: String,
                          significant: Bool, highlighted: Bool, tint: Color,
                          help: (term: String, plain: String, example: String)) -> some View {
        VStack(alignment: .leading, spacing: 5) {
            HStack(spacing: 5) {
                Text(title).font(.system(size: 10.5, weight: .semibold)).foregroundStyle(.secondary)
                HelpDot(term: help.term, plain: help.plain, example: help.example, width: 300)
                if highlighted {
                    Badge(text: T("推荐"), tint: tint)
                }
                Spacer()
                if significant {
                    Image(systemName: "star.fill").font(.system(size: 8)).foregroundStyle(tint)
                }
            }
            Text(value)
                .font(.system(size: 17, weight: .semibold, design: .rounded).monospacedDigit())
                .foregroundStyle(significant ? tint : .primary)
            Text(detail)
                .font(.system(size: 9.5, design: .rounded).monospacedDigit())
                .foregroundStyle(.tertiary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(11)
        .background {
            RoundedRectangle(cornerRadius: 11, style: .continuous)
                .fill(highlighted ? tint.opacity(0.10) : Color.primary.opacity(0.035))
                .overlay {
                    RoundedRectangle(cornerRadius: 11, style: .continuous)
                        .strokeBorder(highlighted ? tint.opacity(0.35) : Color.clear, lineWidth: 1)
                }
        }
    }

    private func deltaCard(_ a: Stats.Summary, _ b: Stats.Summary) -> some View {
        VStack(alignment: .leading, spacing: 5) {
            HStack(spacing: 4) {
                Text(T("差值 A − B")).font(.system(size: 10.5, weight: .semibold)).foregroundStyle(.secondary)
                HelpDot(term: T("效应量 d / r"),
                        plain: T("p 只说「有没有差别」，效应量说「差多少」。d≈0.2 小、0.5 中、0.8 大；秩相关 r 同理，0.1/0.3/0.5 分别算小/中/大。"),
                        example: T("p = 0.001 但 d = 0.1：差别确实存在，但小到没什么实际意义。"),
                        width: 290)
            }
            Text(String(format: "%+.2f", a.mean - b.mean))
                .font(.system(size: 17, weight: .semibold, design: .rounded).monospacedDigit())
                .foregroundStyle(abs(a.mean - b.mean) > 0 ? .primary : .secondary)
            Text(String(format: "%.2f vs %.2f", a.mean, b.mean))
                .font(.system(size: 9.5, design: .rounded).monospacedDigit())
                .foregroundStyle(.tertiary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(11)
        .background {
            RoundedRectangle(cornerRadius: 11, style: .continuous).fill(Color.primary.opacity(0.035))
        }
    }

    // MARK: 六维总表

    private func dimensionTable(_ l: Corpus, _ r: Corpus) -> some View {
        // 先算好，表格与导出共用同一份数字
        let data: [(m: DimMeta, ma: Double, mb: Double, tp: Double?, up: Double?, verdict: String, tint: Color)] =
            Dims.all.map { m in
                let a = l.samples(.dimension(m.id)), b = r.samples(.dimension(m.id))
                let t = Stats.welchT(a, b), u = Stats.mannWhitneyU(a, b)
                let ma = Stats.describe(a).mean, mb = Stats.describe(b).mean
                let both = (t?.isSignificant ?? false) && (u?.isSignificant ?? false)
                let one = (t?.isSignificant ?? false) || (u?.isSignificant ?? false)
                let verdict = (t == nil || u == nil) ? T("样本不足")
                    : T(both ? "差异显著" : (one ? "结论不一致" : "无显著差异"))
                let tint: Color = both ? m.color : (one ? .orange : .secondary)
                return (m, ma, mb, t?.p, u?.p, verdict, tint)
            }

        let header = ["维度", "A · \(l.name)", "B · \(r.name)", "差值", "t 检验 p", "U 检验 p", "结论"]
        let tsvRows: [[String]] = data.map { d in
            ["D\(d.m.id) \(d.m.title)",
             String(format: "%.2f", d.ma), String(format: "%.2f", d.mb),
             String(format: "%+.2f", d.ma - d.mb),
             d.tp.map { String(format: "%.4f", $0) } ?? "—",
             d.up.map { String(format: "%.4f", $0) } ?? "—",
             d.verdict]
        }

        return VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 8) {
                SectionHeader(T("六个维度的差异"), subtitle: T("每种检验各算一遍，看结论是否一致"))
                Spacer()
                IconAction(systemName: "doc.on.doc", help: T("复制整张表（Tab 分隔，可直接粘进 Excel）")) {
                    TableExport.copyTSV([header] + tsvRows)
                }
                IconAction(systemName: "square.and.arrow.up", help: T("导出为图片…")) {
                    TableExport.askAndExport(title: T("六个维度的差异"),
                                             subtitle: T("A · %@（%@ 篇） vs B · %@（%@ 篇）", l.name, l.documents.count, r.name, r.documents.count),
                                             header: header, rows: tsvRows)
                }
            }

            Grid(alignment: .leading, horizontalSpacing: 16, verticalSpacing: 6) {
                GridRow {
                    Text(T("维度"))
                    Text("A · \(l.name)").gridColumnAlignment(.trailing).lineLimit(1)
                    Text("B · \(r.name)").gridColumnAlignment(.trailing).lineLimit(1)
                    Text(T("差值")).gridColumnAlignment(.trailing)
                    Text(T("t 检验 p")).gridColumnAlignment(.trailing)
                    Text(T("U 检验 p")).gridColumnAlignment(.trailing)
                    Text(T("结论")).gridColumnAlignment(.trailing)
                }
                .font(.system(size: 10, weight: .medium))
                .foregroundStyle(.tertiary)

                Divider().gridCellColumns(7).opacity(0.3)

                ForEach(data, id: \.m.id) { d in
                    GridRow {
                        HStack(spacing: 6) {
                            Circle().fill(d.m.color).frame(width: 6, height: 6)
                            Text("D\(d.m.id) \(d.m.title)")
                                .font(.system(size: 11.5))
                                .lineLimit(1)
                        }
                        Text(String(format: "%.2f", d.ma))
                            .font(.system(size: 11, design: .rounded).monospacedDigit())
                            .foregroundStyle(SeriesColors.a)
                        Text(String(format: "%.2f", d.mb))
                            .font(.system(size: 11, design: .rounded).monospacedDigit())
                            .foregroundStyle(SeriesColors.b)
                        Text(String(format: "%+.2f", d.ma - d.mb))
                            .font(.system(size: 11, weight: .medium, design: .rounded).monospacedDigit())
                            .foregroundStyle(d.m.color)
                        pCell(d.tp)
                        pCell(d.up)
                        Text(d.verdict)
                            .font(.system(size: 9.5, weight: .medium))
                            .padding(.horizontal, 6).padding(.vertical, 2)
                            .background { Capsule().fill(d.tint.opacity(0.14)) }
                            .foregroundStyle(d.tint)
                    }
                    .padding(.vertical, 2)
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .glassCard()
    }

    private func pCell(_ p: Double?) -> some View {
        Group {
            if let p {
                Text(String(format: "%.4f", p))
                    .font(.system(size: 11, weight: p < 0.05 ? .semibold : .regular, design: .rounded).monospacedDigit())
                    .foregroundStyle(p < 0.05 ? Color.primary : .secondary)
            } else {
                Text("—").font(.system(size: 11)).foregroundStyle(.tertiary)
            }
        }
    }
}
