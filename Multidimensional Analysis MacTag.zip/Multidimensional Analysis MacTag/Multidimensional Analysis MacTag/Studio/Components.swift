import SwiftUI
import MATCore

// MARK: - 复用组件
//
// 目标是「不需要读文档也知道每个数字是什么」：
// 大数字配等宽圆体、单位跟在后面小一号、变化用数字滚动动画。

@MainActor
struct SectionHeader: View {
    var title: String
    var subtitle: String?
    var action: AnyView?

    init(_ title: String, subtitle: String? = nil) {
        self.title = title
        self.subtitle = subtitle
        self.action = nil
    }

    var body: some View {
        HStack(alignment: .firstTextBaseline, spacing: 10) {
            Text(title)
                .font(.system(size: 15, weight: .semibold, design: .rounded))
            if let subtitle {
                Text(subtitle)
                    .font(.system(size: 11.5))
                    .foregroundStyle(.secondary)
            }
            Spacer()
            if let action { action }
        }
    }
}

// MARK: 大数字

@MainActor
struct BigNumber: View {
    var value: Double
    var unit: String = ""
    var decimals: Int = 2
    var color: Color = .primary
    var size: CGFloat = 30

    private var text: String {
        let f = NumberFormatter()
        f.minimumFractionDigits = decimals
        f.maximumFractionDigits = decimals
        f.groupingSeparator = ","
        f.numberStyle = .decimal
        return f.string(from: NSNumber(value: value)) ?? "\(value)"
    }

    var body: some View {
        HStack(alignment: .firstTextBaseline, spacing: 4) {
            Text(text)
                .font(.system(size: size, weight: .semibold, design: .rounded).monospacedDigit())
                .foregroundStyle(color)
                .contentTransition(.numericText())
            if !unit.isEmpty {
                Text(unit).font(.system(size: size * 0.42, weight: .medium))
                    .foregroundStyle(.secondary)
            }
        }
        .animation(Motion.snappy, value: value)
    }
}

// MARK: 指标卡

@MainActor
struct StatTile: View {
    var label: String
    var value: Double
    var unit: String = ""
    var decimals: Int = 2
    var tint: Color = .secondary
    var icon: String?

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 6) {
                if let icon {
                    Image(systemName: icon)
                        .font(.system(size: 10, weight: .semibold))
                        .foregroundStyle(tint)
                }
                Text(label)
                    .font(.system(size: 11, weight: .medium))
                    .foregroundStyle(.secondary)
                    .textCase(.uppercase)
                    .kerning(0.4)
            }
            BigNumber(value: value, unit: unit, decimals: decimals, size: 22)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .glassCard(padding: 13)
    }
}

// MARK: 芯片

@MainActor
struct Chip: View {
    var text: String
    var isOn: Bool
    var tint: Color = Theme.accent
    var action: () -> Void

    @State private var hover = false

    var body: some View {
        Button(action: action) {
            Text(text)
                .font(.system(size: 11.5, weight: .medium))
                .lineLimit(1)
                .padding(.horizontal, 10)
                .padding(.vertical, 5)
                .background {
                    Capsule()
                        .fill(isOn ? AnyShapeStyle(tint.opacity(0.18)) : AnyShapeStyle(.ultraThinMaterial))
                        .overlay {
                            Capsule().strokeBorder(isOn ? tint.opacity(0.55) : Color.primary.opacity(0.07),
                                                   lineWidth: 1)
                        }
                }
                .foregroundStyle(isOn ? tint : .secondary)
        }
        .buttonStyle(.plain)
        .scaleEffect(hover ? 1.03 : 1)
        .onHover { hover = $0 }
        .animation(Motion.quick, value: hover)
        .animation(Motion.snappy, value: isOn)
    }
}

// MARK: 维度条（正值往右、负值往左）

@MainActor
struct DivergingBar: View {
    var value: Double
    var maxAbs: Double
    var color: Color
    var height: CGFloat = 6

    var body: some View {
        GeometryReader { geo in
            let w = geo.size.width
            let frac = maxAbs > 0 ? min(1, abs(value) / maxAbs) : 0
            ZStack(alignment: value >= 0 ? .leading : .trailing) {
                Capsule().fill(Color.primary.opacity(0.07))
                Capsule()
                    .fill(LinearGradient(colors: [color.opacity(0.55), color],
                                         startPoint: .leading, endPoint: .trailing))
                    .frame(width: max(2, w * 0.5 * frac))
                    .offset(x: value >= 0 ? w * 0.5 : -w * 0.5)
            }
            .overlay(alignment: .center) {
                Rectangle().fill(Color.primary.opacity(0.12)).frame(width: 1)
            }
            .clipShape(Capsule())
        }
        .frame(height: height)
    }
}

// MARK: 状态徽章

@MainActor
struct Badge: View {
    var text: String
    var tint: Color
    var filled: Bool = false

    var body: some View {
        Text(text)
            .font(.system(size: 10.5, weight: .semibold, design: .rounded))
            .padding(.horizontal, 8)
            .padding(.vertical, 3.5)
            .background {
                Capsule().fill(filled ? tint.opacity(0.20) : Color.primary.opacity(0.05))
                    .overlay { Capsule().strokeBorder(tint.opacity(filled ? 0.5 : 0.25), lineWidth: 1) }
            }
            .foregroundStyle(tint)
    }
}

// MARK: 空状态

@MainActor
struct EmptyHint: View {
    var icon: String
    var title: String
    var message: String
    var actionTitle: String?
    var action: (() -> Void)?

    @State private var pulse = false

    var body: some View {
        VStack(spacing: 16) {
            ZStack {
                Circle()
                    .fill(LinearGradient(colors: [Theme.accent.opacity(0.30), Theme.accent.opacity(0.02)],
                                         startPoint: .top, endPoint: .bottom))
                    .frame(width: 96, height: 96)
                    .scaleEffect(pulse ? 1.06 : 0.96)
                    .opacity(pulse ? 0.75 : 1)
                Image(systemName: icon)
                    .font(.system(size: 34, weight: .light))
                    .foregroundStyle(Theme.accent)
            }
            VStack(spacing: 6) {
                Text(title).font(.system(size: 17, weight: .semibold, design: .rounded))
                Text(message)
                    .font(.system(size: 12.5))
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                    .frame(maxWidth: 380)
            }
            if let actionTitle, let action {
                Button(actionTitle, action: action)
                    .buttonStyle(.borderedProminent)
                    .controlSize(.large)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .onAppear {
            withAnimation(.easeInOut(duration: 2.2).repeatForever(autoreverses: true)) { pulse = true }
        }
    }
}

// MARK: 进度条

@MainActor
struct RunProgressBar: View {
    var progress: Workspace.Progress

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 8) {
                ProgressView().controlSize(.small)
                Text(progress.label)
                    .font(.system(size: 11.5))
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
                Spacer()
                Text("\(Int(progress.fraction * 100))%")
                    .font(.system(size: 11, weight: .medium, design: .rounded).monospacedDigit())
                    .foregroundStyle(.secondary)
            }
            GeometryReader { geo in
                ZStack(alignment: .leading) {
                    Capsule().fill(Color.primary.opacity(0.08))
                    Capsule()
                        .fill(LinearGradient(colors: [Dims.color(1), Theme.accent, Dims.color(5)],
                                             startPoint: .leading, endPoint: .trailing))
                        .frame(width: max(6, geo.size.width * progress.fraction))
                        .animation(.easeOut(duration: 0.25), value: progress.fraction)
                }
            }
            .frame(height: 5)
        }
        .padding(12)
        .background {
            RoundedRectangle(cornerRadius: 12, style: .continuous).fill(.ultraThinMaterial)
        }
    }
}

// MARK: 悬停放大

struct HoverScale: ViewModifier {
    @State private var hover = false
    var amount: CGFloat = 1.015
    func body(content: Content) -> some View {
        content
            .scaleEffect(hover ? amount : 1)
            .onHover { hover = $0 }
            .animation(Motion.quick, value: hover)
    }
}

extension View {
    func hoverScale(_ amount: CGFloat = 1.015) -> some View { modifier(HoverScale(amount: amount)) }
}

// MARK: - 术语帮助（问号 + 大白话 + 例子）
//
// 早期版本让每个问号各自持有一个浮窗（overlay + material + shadow），结果是：
//   · 指针一进去，浮窗本身截获了 hover，离开事件收不到 → 关不掉；
//   · 每个问号都有独立状态 → 挪到下一个问号时旧的还开着，叠成一堆；
//   · 多个 material+shadow 在 ScrollView 里实时合成 → 卡顿。
//
// 现在改成**全局唯一宿主**：所有问号只往 HelpCenter 里写一条记录，
// 由根视图在顶层画一个 `.allowsHitTesting(false)` 的浮窗。
// 指针永远碰不到浮窗，所以不可能出现「关不掉」。

@MainActor
@Observable
final class HelpCenter {
    struct Item: Equatable {
        var title: String
        var plain: String
        var example: String?
        var width: CGFloat
        var anchor: CGRect          // 相对根视图坐标空间
    }

    static let shared = HelpCenter()

    private(set) var item: Item?
    private var hideTask: Task<Void, Never>?

    func show(_ new: Item) {
        hideTask?.cancel()
        hideTask = nil
        item = new
    }

    /// 离开问号后延迟关闭，给指针一点余量；期间若进入另一个问号会被 show 取消
    func hideSoon() {
        hideTask?.cancel()
        hideTask = Task { @MainActor in
            try? await Task.sleep(nanoseconds: 120_000_000)
            guard !Task.isCancelled else { return }
            item = nil
        }
    }

    func hideNow() {
        hideTask?.cancel()
        hideTask = nil
        item = nil
    }
}

/// 问号本身：只负责上报位置，不画任何浮窗
struct HelpDot: View {
    var term: String
    var plain: String
    var example: String? = nil
    var width: CGFloat = 268

    @State private var hovering = false
    @State private var frame: CGRect = .zero

    var body: some View {
        Image(systemName: "questionmark.circle")
            .font(.system(size: 9.5, weight: .semibold))
            .foregroundStyle(hovering ? Theme.accent : Color.secondary.opacity(0.55))
            .contentShape(Circle())
            .background {
                GeometryReader { geo in
                    Color.clear
                        .onAppear { frame = geo.frame(in: .named(HelpSpace.name)) }
                        .onChange(of: geo.frame(in: .named(HelpSpace.name))) { _, new in frame = new }
                }
            }
            .onHover { inside in
                hovering = inside
                if inside {
                    HelpCenter.shared.show(.init(title: term, plain: plain, example: example,
                                                 width: width, anchor: frame))
                } else {
                    HelpCenter.shared.hideSoon()
                }
            }
            .onDisappear {
                if HelpCenter.shared.item?.title == term { HelpCenter.shared.hideNow() }
            }
            .animation(Motion.quick, value: hovering)
    }
}

enum HelpSpace {
    static let name = "help-space"
}

/// 根视图里的唯一浮窗
struct HelpTooltipLayer: View {
    var item: HelpCenter.Item

    var body: some View {
        GeometryReader { geo in
            let width = item.width
            let gap: CGFloat = 10
            let estHeight: CGFloat = 120
            let spaceRight = geo.size.width - item.anchor.maxX
            let x = spaceRight > width + gap + 8
                ? item.anchor.maxX + gap
                : max(8, item.anchor.minX - width - gap)
            let y = min(max(8, item.anchor.minY - 8),
                        max(8, geo.size.height - estHeight - 8))

            VStack(alignment: .leading, spacing: 5) {
                Text(item.title)
                    .font(.system(size: 11, weight: .semibold, design: .rounded))
                Text(item.plain)
                    .font(.system(size: 10.5))
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                if let example = item.example {
                    HStack(alignment: .top, spacing: 4) {
                        Text(T("例"))
                            .font(.system(size: 8, weight: .bold))
                            .padding(.horizontal, 3).padding(.vertical, 1)
                            .background { RoundedRectangle(cornerRadius: 3).fill(Theme.accent.opacity(0.16)) }
                            .foregroundStyle(Theme.accent)
                        Text(example)
                            .font(.system(size: 10.5))
                            .foregroundStyle(.secondary)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }
            }
            .padding(10)
            .frame(width: width, alignment: .leading)
            .background {
                RoundedRectangle(cornerRadius: 9, style: .continuous)
                    .fill(.regularMaterial)
                    .overlay {
                        RoundedRectangle(cornerRadius: 9, style: .continuous)
                            .strokeBorder(Theme.accent.opacity(0.30), lineWidth: 1)
                    }
                    .shadow(color: .black.opacity(0.20), radius: 12, y: 5)
            }
            .position(x: x + width / 2, y: y + min(estHeight, 70))
            .allowsHitTesting(false)
        }
        .transition(.opacity)
        .animation(.easeOut(duration: 0.12), value: item)
    }
}

/// 标题 + 术语问号的组合
struct TermLabel: View {
    var text: String
    var term: String
    var plain: String
    var example: String? = nil

    var body: some View {
        HStack(spacing: 4) {
            Text(text)
            HelpDot(term: term, plain: plain, example: example)
        }
    }
}

// MARK: - 统一图例

/// 图例的形状必须和图上真实画的东西一致，否则「直方图」和「核密度」会长得一样。
enum LegendShape {
    case bar        // 实心块：直方图 / 柱
    case line       // 实线：密度曲线
    case dashed     // 虚线上：正态曲线
    case dot        // 点：均值 / 样本
    case band       // 半透明带：参考区间
}

struct LegendItem: View {
    var shape: LegendShape
    var color: Color
    var label: String

    var body: some View {
        HStack(spacing: 5) {
            Group {
                switch shape {
                case .bar:
                    RoundedRectangle(cornerRadius: 2)
                        .fill(color.opacity(0.75))
                        .frame(width: 13, height: 8)
                case .line:
                    Capsule().fill(color).frame(width: 14, height: 2.4)
                case .dashed:
                    HStack(spacing: 2.5) {
                        Capsule().fill(color).frame(width: 5, height: 2)
                        Capsule().fill(color).frame(width: 5, height: 2)
                    }
                case .dot:
                    Circle().fill(color).frame(width: 7, height: 7)
                case .band:
                    RoundedRectangle(cornerRadius: 1.5)
                        .fill(color.opacity(0.28))
                        .overlay { RoundedRectangle(cornerRadius: 1.5).strokeBorder(color.opacity(0.55), lineWidth: 0.8) }
                        .frame(width: 13, height: 8)
                }
            }
            .frame(width: 15)
            Text(label)
                .font(.system(size: 10))
                .foregroundStyle(.secondary)
                .lineLimit(1)
                .fixedSize()
        }
    }
}
