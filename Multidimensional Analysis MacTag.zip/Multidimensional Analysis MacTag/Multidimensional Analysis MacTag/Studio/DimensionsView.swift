import SwiftUI
import Charts
import MATCore

// MARK: - 维度图（可复用：页面 / 导出都用它）

/// 一条「参考区间 + 均值」的数据带。参考体裁、本次语料、对比语料都是这种形状。
struct DimSeries: Identifiable {
    enum Kind { case reference, a, b }
    var id: String
    var label: String          // 轴上显示
    var full: String           // 悬停/表格里显示
    var low: Double
    var high: Double
    var mean: Double
    var kind: Kind
    var genreIndex: Int = -1

    var color: Color {
        switch kind {
        case .reference: return GenrePalette.color(index: genreIndex)
        case .a: return SeriesColors.a
        case .b: return SeriesColors.b
        }
    }
}

enum SeriesColors {
    /// 两个语料必须靠颜色一眼分清：暖珊瑚 vs 冷天蓝
    static let a = Color(hex: 0xFF7A59)
    static let b = Color(hex: 0x4EA8FF)
    static let reference = Color.gray
}

/// 只画图，不带页面外壳。导出时直接拿它渲染成 PNG。
@MainActor
struct DimensionChartView: View {
    var corpus: Corpus
    var compare: Corpus?
    var dim: Int
    var style: Workspace.ChartStyle
    var documentName: String? = nil
    var height: CGFloat = 330
    var showLegend: Bool = true
    var showTitle: Bool = true
    var showHoverHint: Bool = true
    /// 外部（参考表）驱动的悬停
    var externalHover: String? = nil
    var onHover: ((String?) -> Void)? = nil

    @State private var localHover: String?
    private var hovered: String? { externalHover ?? localHover }

    private func setHover(_ label: String?) {
        localHover = label
        onHover?(label)
    }

    private var meta: DimMeta { Dims.meta(dim) }

    var rows: [DimSeries] {
        var out: [DimSeries] = Catalog.shared.genres.enumerated().map { idx, g in
            DimSeries(id: g.name, label: GenreRow.shortName(g.name), full: g.name,
                      low: g.low[safe: dim - 1] ?? 0,
                      high: g.high[safe: dim - 1] ?? 0,
                      mean: g.values[safe: dim - 1] ?? 0,
                      kind: .reference, genreIndex: idx)
        }
        let aSamples: [Double]
        if let name = documentName, let doc = corpus.documents.first(where: { $0.name == name }) {
            aSamples = [doc.dims[dim] ?? 0]
        } else {
            aSamples = corpus.samples(.dimension(dim))
        }
        out.append(DimSeries(id: "A",
                             label: CorpusLabel.short(documentName ?? corpus.name),
                             full: documentName ?? corpus.name,
                             low: aSamples.min() ?? 0, high: aSamples.max() ?? 0,
                             mean: aSamples.isEmpty ? 0 : aSamples.reduce(0, +) / Double(aSamples.count),
                             kind: .a))
        if let b = compare {
            let bSamples = b.samples(.dimension(dim))
            out.append(DimSeries(id: "B", label: CorpusLabel.short(b.name), full: b.name,
                                 low: bSamples.min() ?? 0, high: bSamples.max() ?? 0,
                                 mean: bSamples.isEmpty ? 0 : bSamples.reduce(0, +) / Double(bSamples.count),
                                 kind: .b))
        }
        return out
    }

    private var allValues: [Double] { rows.flatMap { [$0.low, $0.high, $0.mean] } }
    private var domain: ClosedRange<Double> {
        let lo = allValues.min() ?? -30
        let hi = allValues.max() ?? 60
        let pad = max(4, (hi - lo) * 0.10)
        return (lo - pad)...(hi + pad)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            if showTitle {
                HStack(alignment: .firstTextBaseline, spacing: 8) {
                    Text("D\(dim) · \(meta.english)")
                        .font(.system(size: 12.5, weight: .semibold))
                    Spacer()
                    if compare == nil {
                        Badge(text: "\(corpus.name) \(fmt(rows.last?.mean ?? 0))",
                              tint: SeriesColors.a, filled: true)
                    }
                }
            }

            switch style {
            case .legacy: legacyChart
            case .horizontal: horizontalChart
            }

            if showLegend { legend }

            if showHoverHint { hoverStrip }
        }
        .animation(Motion.soft, value: dim)
    }

    // MARK: 原版风格（竖向误差线）

    private var legacyChart: some View {
        Chart {
            RuleMark(y: .value("zero", 0))
                .foregroundStyle(Color.primary.opacity(0.10))
                .lineStyle(StrokeStyle(lineWidth: 1))

            ForEach(rows) { r in
                BarMark(x: .value("体裁", r.label),
                        yStart: .value("低", r.low),
                        yEnd: .value("高", r.high),
                        width: .fixed(r.kind == .reference ? 7 : 12))
                    .foregroundStyle(
                        LinearGradient(colors: [r.color.opacity(r.kind == .reference ? 0.22 : 0.65),
                                                r.color.opacity(r.kind == .reference ? 0.55 : 0.95)],
                                       startPoint: .bottom, endPoint: .top))
                    .cornerRadius(3.5)
                    .opacity(hovered == nil || hovered == r.label ? 1 : 0.35)

                PointMark(x: .value("体裁", r.label), y: .value("均值", r.mean))
                    .symbolSize(hovered == r.label ? 120 : (r.kind == .reference ? 46 : 80))
                    .foregroundStyle(r.kind == .reference ? Color.primary.opacity(0.55) : r.color)
                    .opacity(hovered == nil || hovered == r.label ? 1 : 0.35)
            }
        }
        .chartYScale(domain: domain)
        .chartXScale(range: .plotDimension(padding: 10))
        .chartXAxis {
            AxisMarks { value in
                AxisValueLabel {
                    if let s = value.as(String.self) {
                        Text(s).font(.system(size: 10.5))
                    }
                }
                AxisTick().foregroundStyle(.clear)
            }
        }
        .chartYAxis { axis }
        .chartOverlay { proxy in
            GeometryReader { geo in
                Rectangle().fill(.clear).contentShape(Rectangle())
                    .onContinuousHover { phase in
                        switch phase {
                        case .active(let p):
                            guard let plot = proxy.plotFrame else { return }
                            let x = p.x - geo[plot].origin.x
                            if let name: String = proxy.value(atX: x) { setHover(name) }
                        case .ended: setHover(nil)
                        }
                    }
            }
        }
        .frame(height: height)
        .animation(Motion.snappy, value: hovered)
    }

    // MARK: 横向柱状图（同一份数据，坐标轴转 90°）

    /// 用**数值纵轴 + 索引**而不是分类纵轴：
    /// 分类 band 下 BarMark 的 `height: .fixed()` 与 AxisValueLabel 会各算一套位置，
    /// 在窗口尺寸变化后标签会整体错位（用户截图里 9 个标签挤在上半部分）。
    /// 改成 y = 索引后，柱子和标签共用同一个线性刻度，永远不会错位。
    private var horizontalChart: some View {
        let items = Array(rows.enumerated())
        let count = rows.count

        return Chart {
            RuleMark(x: .value("zero", 0))
                .foregroundStyle(Color.primary.opacity(0.10))

            ForEach(items, id: \.element.id) { i, r in
                BarMark(xStart: .value("低", r.low),
                        xEnd: .value("高", r.high),
                        y: .value("行", Double(count - 1 - i)),
                        height: .fixed(r.kind == .reference ? 8 : 11))
                    .foregroundStyle(
                        LinearGradient(colors: [r.color.opacity(r.kind == .reference ? 0.22 : 0.65),
                                                r.color.opacity(r.kind == .reference ? 0.55 : 0.95)],
                                       startPoint: .leading, endPoint: .trailing))
                    .cornerRadius(3.5)
                    .opacity(hovered == nil || hovered == r.label ? 1 : 0.35)

                PointMark(x: .value("均值", r.mean), y: .value("行", Double(count - 1 - i)))
                    .symbolSize(hovered == r.label ? 110 : (r.kind == .reference ? 42 : 74))
                    .foregroundStyle(r.kind == .reference ? Color.primary.opacity(0.55) : r.color)
                    .opacity(hovered == nil || hovered == r.label ? 1 : 0.35)

                if r.kind != .reference {
                    PointMark(x: .value("标注", r.mean), y: .value("行", Double(count - 1 - i)))
                        .symbolSize(0.1)
                        .annotation(position: .trailing, spacing: 7) {
                            Text(fmt(r.mean))
                                .font(.system(size: 9.5, weight: .semibold, design: .rounded).monospacedDigit())
                                .foregroundStyle(r.color)
                                .fixedSize()
                        }
                }
            }
        }
        .chartXScale(domain: domain, range: .plotDimension(padding: 18))
        .chartYScale(domain: -0.6...(Double(count) - 0.4))
        .chartYAxis {
            AxisMarks(position: .leading, values: (0..<count).map { Double($0) }) { value in
                AxisValueLabel {
                    if let d = value.as(Double.self) {
                        let idx = count - 1 - Int(d.rounded())
                        if idx >= 0, idx < count {
                            Text(rows[idx].label)
                                .font(.system(size: 10.5))
                                .fixedSize()
                        }
                    }
                }
                AxisTick().foregroundStyle(.clear)
            }
        }
        .chartXAxis {
            AxisMarks(values: .automatic(desiredCount: 6)) { value in
                AxisGridLine().foregroundStyle(Color.primary.opacity(0.06))
                AxisValueLabel {
                    if let d = value.as(Double.self) {
                        Text(String(format: "%.0f", d))
                            .font(.system(size: 10, design: .rounded).monospacedDigit())
                            .foregroundStyle(.tertiary)
                    }
                }
            }
        }
        .chartOverlay { proxy in
            GeometryReader { geo in
                Rectangle().fill(.clear).contentShape(Rectangle())
                    .onContinuousHover { phase in
                        switch phase {
                        case .active(let p):
                            guard let plot = proxy.plotFrame else { return }
                            let y = p.y - geo[plot].origin.y
                            if let row: Double = proxy.value(atY: y) {
                                let idx = count - 1 - Int(row.rounded())
                                if idx >= 0, idx < count { setHover(rows[idx].label) }
                            }
                        case .ended:
                            setHover(nil)
                        }
                    }
            }
        }
        .frame(height: height)
        .animation(Motion.snappy, value: hovered)
    }

    private var axis: some AxisContent {
        AxisMarks(position: .leading, values: .automatic(desiredCount: 6)) { value in
            AxisGridLine().foregroundStyle(Color.primary.opacity(0.06))
            AxisValueLabel {
                if let d = value.as(Double.self) {
                    Text(String(format: "%.0f", d))
                        .font(.system(size: 10, design: .rounded).monospacedDigit())
                        .foregroundStyle(.tertiary)
                }
            }
        }
    }

    // MARK: 图例

    private var legend: some View {
        HStack(spacing: 14) {
            if compare == nil {
                LegendItem(shape: .band, color: SeriesColors.a, label: T("%@（最低~最高）", corpus.name))
                LegendItem(shape: .dot, color: SeriesColors.a, label: T("均值"))
            } else {
                LegendItem(shape: .band, color: SeriesColors.a, label: corpus.name)
                LegendItem(shape: .band, color: SeriesColors.b, label: compare?.name ?? "")
                LegendItem(shape: .dot, color: Color.primary.opacity(0.55), label: T("组内均值"))
            }
            Text(T("参考体裁")).font(.system(size: 10)).foregroundStyle(.secondary)
            HStack(spacing: 4) {
                ForEach(0..<GenrePalette.names.count, id: \.self) { i in
                    Circle()
                        .fill(GenrePalette.color(index: i))
                        .frame(width: 8, height: 8)
                        .overlay { Circle().strokeBorder(Color.primary.opacity(0.15), lineWidth: 0.5) }
                        .help(GenreRow.shortName(GenrePalette.names[i]))
                }
            }
            if compare == nil {
                LegendItem(shape: .dot, color: Color.primary.opacity(0.55), label: T("体裁均值"))
            }
            Spacer()
        }
        .animation(Motion.quick, value: compare?.id)
    }

    // MARK: 悬停信息条

    private var hoverStrip: some View {
        let row = rows.first { $0.label == hovered }
        return HStack(spacing: 10) {
            if let row {
                let _ = 0
                Circle().fill(row.color).frame(width: 7, height: 7)
                Text(row.full).font(.system(size: 11.5, weight: .semibold))
                Text(T("均值 %@", fmt(row.mean))).font(.system(size: 11)).foregroundStyle(.secondary)
                Text(T("区间 %@ ~ %@", fmt(row.low), fmt(row.high))).font(.system(size: 11)).foregroundStyle(.secondary)
                if row.kind == .reference, let a = rows.first(where: { $0.kind == .a }) {
                    Text(T("距离 %@", fmt(abs(row.mean - a.mean))))
                        .font(.system(size: 11, weight: .medium, design: .rounded).monospacedDigit())
                        .foregroundStyle(meta.color)
                }
            } else {
                Text(T("把指针移到任意一条上，看它的均值与区间"))
                    .font(.system(size: 11)).foregroundStyle(.tertiary)
            }
            Spacer()
        }
        .lineLimit(1)
        .minimumScaleFactor(0.85)
        .frame(height: 16)
    }

    private func fmt(_ v: Double) -> String { String(format: "%.2f", v) }
}

// MARK: - 维度页

@MainActor
struct DimensionsView: View {
    @Environment(Workspace.self) private var ws
    var corpus: Corpus

    /// 图 ↔ 参考表 共用的悬停行
    @State private var hovered: String?

    /// 距离列排序：0 = 与 A 的距离，1 = 与 B 的距离；nil = 原始顺序
    @State private var sortColumn: Int?
    @State private var ascending = true

    private var compare: Corpus? {
        guard let id = ws.dimCompareID, id != corpus.id else { return nil }
        return ws.corpora.first { $0.id == id }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            controls
            dimChips
            DimensionChartView(corpus: corpus, compare: compare, dim: ws.selectedDim,
                               style: ws.chartStyle, documentName: ws.selectedDocument,
                               height: 330,
                               externalHover: hovered,
                               onHover: { value in withAnimation(Motion.quick) { hovered = value } })
                .glassCard()
            referenceTable
        }
    }

    private var controls: some View {
        @Bindable var ws = ws
        return HStack(spacing: 10) {
            Picker("", selection: $ws.chartStyle) {
                ForEach(Workspace.ChartStyle.allCases) { s in Text(s.title).tag(s) }
            }
            .pickerStyle(.segmented)
            .labelsHidden()
            .frame(width: 212)
            .controlSize(.small)

            Menu {
                Button(T("不叠加")) { ws.dimCompareID = nil }
                Divider()
                ForEach(ws.corpora.filter { $0.id != corpus.id }) { c in
                    Button(c.name) { ws.dimCompareID = c.id }
                }
            } label: {
                HStack(spacing: 6) {
                    Image(systemName: "square.on.square")
                        .font(.system(size: 9.5, weight: .semibold))
                    Text(compare.map { T("叠加：%@", $0.name) } ?? T("叠加对比语料"))
                        .font(.system(size: 11.5))
                    Image(systemName: "chevron.down").font(.system(size: 8, weight: .semibold))
                        .foregroundStyle(.tertiary)
                }
                .padding(.horizontal, 9).padding(.vertical, 5)
                .background {
                    Capsule()
                        .fill(compare == nil ? AnyShapeStyle(.ultraThinMaterial)
                                             : AnyShapeStyle(SeriesColors.b.opacity(0.16)))
                        .overlay {
                            Capsule().strokeBorder(compare == nil ? Color.primary.opacity(0.07)
                                                                  : SeriesColors.b.opacity(0.45),
                                                   lineWidth: 1)
                        }
                }
                .foregroundStyle(compare == nil ? Color.secondary : SeriesColors.b)
            }
            .menuStyle(.borderlessButton)
            .fixedSize()

            if compare != nil {
                Button {
                    withAnimation(Motion.snappy) { ws.dimCompareID = nil }
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .font(.system(size: 11)).foregroundStyle(.tertiary)
                }
                .buttonStyle(.plain)
                .help(T("取消叠加"))
            }

            Spacer()

            HStack(spacing: 4) {
                Text(T("怎么读")).font(.system(size: 10.5)).foregroundStyle(.tertiary)
                HelpDot(term: T("这张图在说什么"),
                        plain: T("灰棒是 Biber 研究里 8 个参考体裁的得分区间，灰点是它们的平均分；彩色棒是你自己的语料（叠加时还有第二个）。棒越长，说明组内各篇差异越大。"),
                        example: T("如果红色那根整体落在「对话」的灰棒区间里，说明你的语料读起来最像对话。"))
            }
        }
    }

    private var dimChips: some View {
        HStack(spacing: 6) {
            ForEach(Dims.all) { m in
                Chip(text: "\(m.label) \(m.title)", isOn: ws.selectedDim == m.id, tint: SeriesColors.a) {
                    withAnimation(Motion.snappy) { ws.selectedDim = m.id }
                }
            }
        }
    }

    private var referenceTable: some View {
        let chart = DimensionChartView(corpus: corpus, compare: compare, dim: ws.selectedDim,
                                       style: ws.chartStyle, documentName: ws.selectedDocument)
        let all = chart.rows
        let a = all.first { $0.kind == .a }
        let b = all.first { $0.kind == .b }
        let aName = a?.full ?? corpus.name
        let bName = compare?.name ?? ""
        let columns = compare == nil ? 4 : 5

        return VStack(alignment: .leading, spacing: 10) {
            SectionHeader(T("参考数据"), subtitle: T("Biber 1988 的体裁均值与区间"))
            Grid(alignment: .leading, horizontalSpacing: 14, verticalSpacing: 7) {
                GridRow {
                    Text(T("条 / 体裁"))
                    Text(T("均值")).gridColumnAlignment(.trailing)
                    Text(T("区间")).gridColumnAlignment(.trailing)
                    sortHeader(column: 0, name: aName).gridColumnAlignment(.trailing)
                    if compare != nil {
                        sortHeader(column: 1, name: bName).gridColumnAlignment(.trailing)
                    }
                }
                .font(.system(size: 10, weight: .medium))
                .foregroundStyle(.tertiary)

                Divider().gridCellColumns(columns).opacity(0.3)

                ForEach(sortedRows(all, a: a, b: b)) { r in
                    GridRow {
                        HStack(spacing: 6) {
                            Circle()
                                .fill(r.color)
                                .frame(width: 6, height: 6)
                                .overlay {
                                    Circle().strokeBorder(Color.primary.opacity(0.15), lineWidth: 0.5)
                                }
                            Text(r.kind == .reference ? r.label : r.full)
                                .font(.system(size: 11.5, weight: r.kind == .reference ? .regular : .semibold))
                                .lineLimit(1)
                        }
                        Text(fmt(r.mean))
                            .font(.system(size: 11, design: .rounded).monospacedDigit())
                            .foregroundStyle(.secondary)
                        Text("\(fmt(r.low)) ~ \(fmt(r.high))")
                            .font(.system(size: 10.5, design: .rounded).monospacedDigit())
                            .foregroundStyle(.tertiary)
                        distanceCell(r, base: a)
                        if compare != nil {
                            distanceCell(r, base: b)
                        }
                    }
                    .padding(.horizontal, 6)
                    .padding(.vertical, 4)
                    .background {
                        if hovered == r.label {
                            RoundedRectangle(cornerRadius: 6, style: .continuous)
                                .fill(r.color.opacity(0.12))
                        }
                    }
                    .contentShape(Rectangle())
                    .onHover { inside in
                        withAnimation(Motion.quick) {
                            if inside { hovered = r.label }
                            else if hovered == r.label { hovered = nil }
                        }
                    }
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)

            Text(T("区间来自原版 `@dimN_max/min` 换算后的绝对上下界；「与 X 的距离」= |该体裁均值 − X 的均值|。"))
                .font(.system(size: 10))
                .foregroundStyle(.tertiary)
        }
        .glassCard()
    }

    /// 可点击的排序表头：图标随状态切换（无排序 → 上下箭头；升序 → ↑；降序 → ↓）
    private func sortHeader(column: Int, name: String) -> some View {
        let active = sortColumn == column
        let icon = active ? (ascending ? "arrow.up" : "arrow.down") : "arrow.up.arrow.down"
        return Button {
            withAnimation(Motion.snappy) {
                if sortColumn == column {
                    if ascending { ascending = false }
                    else { sortColumn = nil; ascending = true }
                } else {
                    sortColumn = column
                    ascending = true
                }
            }
        } label: {
            HStack(spacing: 3) {
                Text(T("与 %@ 的距离", name)).fixedSize(horizontal: false, vertical: true)
                Image(systemName: icon)
                    .font(.system(size: 8.5, weight: .bold))
                    .foregroundStyle(active ? SeriesColors.a : Color.secondary.opacity(0.7))
                    .contentTransition(.symbolEffect(.replace))
                    .scaleEffect(active ? 1.15 : 1)
                    .rotationEffect(.degrees(active ? 0 : 0))
            }
            .foregroundStyle(active ? Color.primary : Color.secondary)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .help(active ? (ascending ? "按距离升序（点一下改降序）" : "按距离降序（再点一下取消）")
                     : T("点这里按与 %@ 的距离排序", name))
    }

    /// 参考体裁按所选列排序；A/B 行始终沉底
    private func sortedRows(_ all: [DimSeries], a: DimSeries?, b: DimSeries?) -> [DimSeries] {
        let refs = all.filter { $0.kind == .reference }
        let rest = all.filter { $0.kind != .reference }
        guard let column = sortColumn else { return refs + rest }
        let base = (column == 0 ? a : b)?.mean ?? 0
        let sorted = refs.sorted { l, r in
            let dl = abs(l.mean - base), dr = abs(r.mean - base)
            if dl == dr { return l.label < r.label }
            return ascending ? dl < dr : dl > dr
        }
        return sorted + rest
    }

    @ViewBuilder
    private func distanceCell(_ r: DimSeries, base: DimSeries?) -> some View {
        if r.kind == .reference, let base {
            Text(fmt(abs(r.mean - base.mean)))
                .font(.system(size: 11, weight: .medium, design: .rounded).monospacedDigit())
                .foregroundStyle(base.kind == .a ? SeriesColors.a : SeriesColors.b)
        } else {
            Text("—").font(.system(size: 11)).foregroundStyle(.tertiary)
        }
    }

    private func fmt(_ v: Double) -> String { String(format: "%.2f", v) }
}

// MARK: - 体裁短名

struct GenreRow {
    static let shortEN: [String: String] = [
        "Conversations": "Conversation", "Broadcasts": "Broadcast",
        "Prepared speeches": "Speech", "Personal letters": "Letters",
        "General fiction": "Fiction", "Press reportage": "Press",
        "Academic prose": "Academic", "Official documents": "Official",
    ]

    @MainActor static func shortName(_ s: String) -> String {
        if Localizer.shared.lang == .en { return shortEN[s] ?? s }
        switch s {
        case "Conversations": return "对话"
        case "Broadcasts": return "广播"
        case "Prepared speeches": return "演讲"
        case "Personal letters": return "书信"
        case "General fiction": return "小说"
        case "Press reportage": return "新闻"
        case "Academic prose": return "学术"
        case "Official documents": return "公文"
        default: return s
        }
    }
}
