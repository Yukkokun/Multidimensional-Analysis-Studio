import SwiftUI
import Charts
import MATCore

// MARK: - 分布 / 正态性

@MainActor
struct DistributionView: View {
    @Environment(Workspace.self) private var ws
    var corpus: Corpus

    private var metric: Metric { ws.distributionMetric }
    private var values: [Double] { corpus.samples(metric) }
    private var summary: Stats.Summary { Stats.describe(values) }
    private var normality: Stats.Normality? { Stats.shapiroWilk(values) }

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            controls
            HStack(alignment: .top, spacing: 16) {
                chartCard
                statsCard
            }
            verdict
        }
    }

    // MARK: 控制

    private var controls: some View {
        HStack(spacing: 10) {
            metricPicker

            HStack(spacing: 3) {
                Toggle(isOn: Bindable(ws).showDensity) {
                    Text(T("核密度")).font(.system(size: 11.5))
                }
                .toggleStyle(.switch)
                .controlSize(.mini)
                HelpDot(term: T("核密度估计（KDE）"),
                        plain: T("不把数据切成箱子，而是在每一篇的位置放一个平滑的小鼓包，全部加起来就是曲线。它比直方图更平滑，但样本少时会「画得太满」。"),
                        example: T("10 篇时曲线可能鼓出数据范围之外，这是正常的边缘效应，不代表真有那样的样本。"),
                        width: 290)
            }

            HStack(spacing: 3) {
                Toggle(isOn: Bindable(ws).showNormalCurve) {
                    Text(T("正态曲线")).font(.system(size: 11.5))
                }
                .toggleStyle(.switch)
                .controlSize(.mini)
                HelpDot(term: T("正态曲线"),
                        plain: T("用这批数据的均值和标准差，画一条「理想正态分布」的钟形曲线。它是一条参照线，不是拟合结果。"),
                        example: T("实际曲线比它更尖、尾巴更长，就说明偏离正态，t 检验的前提不太成立。"),
                        width: 280)
            }

            Spacer()

            Text(T("%@ 篇，每点是一篇的%@", values.count, metric.short))
                .font(.system(size: 10.5))
                .foregroundStyle(.tertiary)
        }
    }

    private var metricPicker: some View {
        @Bindable var ws = ws
        return Menu {
            Section("维度") {
                ForEach(Dims.all) { m in
                    Button("D\(m.id) · \(m.title)") { ws.distributionMetric = .dimension(m.id) }
                        .tag(Metric.dimension(m.id))
                }
            }
            Section("指标") {
                Button(T("AWL 平均词长")) { ws.distributionMetric = .feature("AWL") }
                Button(T("TTR 类符/形符比")) { ws.distributionMetric = .feature("TTR") }
            }
            Section("特征") {
                ForEach(Catalog.shared.featureOrder.filter { $0 != "AWL" && $0 != "TTR" }, id: \.self) { f in
                    Button("\(f) · \(Features.glossText(f))") { ws.distributionMetric = .feature(f) }
                }
            }
        } label: {
            HStack(spacing: 7) {
                Circle().fill(metric.color).frame(width: 7, height: 7)
                Text(metric.title).font(.system(size: 12, weight: .medium))
                Image(systemName: "chevron.down").font(.system(size: 9, weight: .semibold))
                    .foregroundStyle(.tertiary)
            }
            .padding(.horizontal, 10).padding(.vertical, 6)
            .background {
                Capsule().fill(.thinMaterial)
                    .overlay { Capsule().strokeBorder(Color.primary.opacity(0.07), lineWidth: 1) }
            }
        }
        .menuStyle(.borderlessButton)
        .fixedSize()
    }

    // MARK: 图

    private var chartCard: some View {
        let s = summary
        let (bins, width) = Stats.histogram(values, desiredBins: values.count <= 12 ? 5 : 10)
        let color = metric.color
        let n = Double(values.count)

        let lo = bins.first?.lower ?? 0
        let hi = bins.last?.upper ?? 1
        let grid = stride(from: lo, through: hi, by: max((hi - lo) / 120, 0.0001)).map { $0 }
        let density = Stats.kde(values, at: grid).map { $0 * n * width }
        let normal = grid.map { Stats.normalPDF($0, mean: s.mean, sd: s.sd) * n * width }

        return VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 6) {
                SectionHeader(T("分布"), subtitle: T("%@ 个样本", values.count))
                HelpDot(term: T("直方图 / 核密度 / 正态曲线"),
                        plain: T("直方图把取值切成几段、数每段有几篇；核密度是把这些柱子磨平后的曲线；虚线是「如果这批数据完全正态，应该长这样」。三条叠在一起，就能看出实际分布像不像正态。"),
                        example: T("曲线左边比虚线胖、右边拖长尾巴 = 右偏，这时候均值会被尾巴拉高，该用中位数描述。"),
                        width: 300)
                Spacer()
            }

            Chart {
                ForEach(bins) { b in
                    BarMark(xStart: .value("低", b.lower), xEnd: .value("高", b.upper),
                            y: .value("频数", b.count))
                        .foregroundStyle(
                            LinearGradient(colors: [color.opacity(0.35), color.opacity(0.70)],
                                           startPoint: .bottom, endPoint: .top))
                        .cornerRadius(2)
                }

                if ws.showDensity {
                    ForEach(Array(grid.enumerated()), id: \.offset) { i, x in
                        LineMark(x: .value("x", x), y: .value("密度", density[i]),
                                 series: .value("s", "kde"))
                            .foregroundStyle(color)
                            .lineStyle(StrokeStyle(lineWidth: 2.2, lineCap: .round))
                            .interpolationMethod(.catmullRom)
                    }
                }

                if ws.showNormalCurve {
                    ForEach(Array(grid.enumerated()), id: \.offset) { i, x in
                        LineMark(x: .value("x", x), y: .value("正态", normal[i]),
                                 series: .value("s", "normal"))
                            .foregroundStyle(Color.primary.opacity(0.45))
                            .lineStyle(StrokeStyle(lineWidth: 1.4, dash: [5, 4]))
                            .interpolationMethod(.catmullRom)
                    }
                }

                if s.isUsable {
                    RuleMark(x: .value("mean", s.mean))
                        .foregroundStyle(color.opacity(0.9))
                        .lineStyle(StrokeStyle(lineWidth: 1.2, dash: [3, 3]))
                        .annotation(position: .top, alignment: .center) {
                            Text("x̄ \(String(format: "%.2f", s.mean))")
                                .font(.system(size: 9.5, weight: .medium, design: .rounded).monospacedDigit())
                                .foregroundStyle(color)
                        }
                }

                ForEach(Array(values.enumerated()), id: \.offset) { _, v in
                    PointMark(x: .value("样本", v), y: .value("rug", 0))
                        .symbolSize(14)
                        .foregroundStyle(color.opacity(0.55))
                }
            }
            .chartXScale(domain: (lo - width * 0.5)...(hi + width * 0.5))
            .chartXAxis {
                AxisMarks(values: .automatic(desiredCount: 7)) { v in
                    AxisGridLine().foregroundStyle(Color.primary.opacity(0.05))
                    AxisValueLabel {
                        if let d = v.as(Double.self) {
                            Text(String(format: "%.1f", d))
                                .font(.system(size: 10, design: .rounded).monospacedDigit())
                                .foregroundStyle(.tertiary)
                        }
                    }
                }
            }
            .chartYScale(domain: 0...(Double(bins.map(\.count).max() ?? 1) * 1.25))
            .chartYScale(domain: 0...(Double(bins.map(\.count).max() ?? 1) * 1.25))
            .chartYAxis {
                AxisMarks(position: .leading, values: .automatic(desiredCount: 4)) { v in
                    AxisGridLine().foregroundStyle(Color.primary.opacity(0.05))
                    AxisValueLabel {
                        if let d = v.as(Double.self) {
                            Text(String(format: "%.0f", d))
                                .font(.system(size: 10, design: .rounded).monospacedDigit())
                                .foregroundStyle(.tertiary)
                        }
                    }
                }
            }
            .frame(height: 300)

            ViewThatFits(in: .horizontal) {
                HStack(spacing: 12) { legendItems }
                VStack(alignment: .leading, spacing: 4) {
                    HStack(spacing: 12) { legendItems }
                }
            }
        }
        .frame(maxWidth: .infinity)
        .glassCard()
    }

    @ViewBuilder
    private var legendItems: some View {
        let color = metric.color
        LegendItem(shape: .bar, color: color, label: T("直方图"))
        if ws.showDensity { LegendItem(shape: .line, color: color, label: T("核密度")) }
        if ws.showNormalCurve {
            LegendItem(shape: .dashed, color: Color.primary.opacity(0.45), label: T("正态分布"))
        }
        LegendItem(shape: .dot, color: color.opacity(0.55), label: T("每篇取值"))
    }

    private func legend(_ c: Color, _ t: String) -> some View {
        HStack(spacing: 5) {
            Circle().fill(c).frame(width: 6, height: 6)
            Text(t).font(.system(size: 10)).foregroundStyle(.secondary)
        }
    }

    // MARK: 统计卡

    private var statsCard: some View {
        let s = summary
        return VStack(alignment: .leading, spacing: 12) {
            SectionHeader(T("描述统计"))
            row(T("样本量 n"), "\(s.n)")
            row(T("均值"), fmt(s.mean))
            HStack(spacing: 4) {
                Text(T("标准差")).font(.system(size: 11)).foregroundStyle(.secondary)
                HelpDot(term: T("标准差"),
                        plain: T("各篇离平均值平均差多远。越大说明组内越参差。"),
                        example: T("均值 10、标准差 25，说明有一两篇特别高，把平均拉上去了。"),
                        width: 240)
                Spacer()
                Text(fmt(s.sd)).font(.system(size: 11.5, weight: .medium, design: .rounded).monospacedDigit())
            }
            row(T("中位数"), fmt(s.median))
            row(T("最小值"), fmt(s.min))
            row(T("最大值"), fmt(s.max))
            Divider().opacity(0.4)
            HStack(spacing: 4) {
                Text(T("偏度")).font(.system(size: 11)).foregroundStyle(.secondary)
                HelpDot(term: T("偏度"),
                        plain: T("分布是否歪。0 是左右对称；正数=右边拖着长尾（少数高分把均值抬高）；负数=左边拖尾。"),
                        example: T("偏度 1.2 时，均值会明显高于中位数。"),
                        width: 260)
                Spacer()
                Text(T(s.skewness > 0 ? "右偏" : "左偏")).font(.system(size: 9)).foregroundStyle(.tertiary)
                Text(fmt(s.skewness)).font(.system(size: 11.5, weight: .medium, design: .rounded).monospacedDigit())
            }
            HStack(spacing: 4) {
                Text(T("超额峰度")).font(.system(size: 11)).foregroundStyle(.secondary)
                HelpDot(term: T("超额峰度"),
                        plain: T("分布的「尖」或「平」。0 = 和正态一样；正数=更尖、尾巴更厚（离群值多）；负数=更平。"),
                        example: T("峰度 3 且样本少时，一两个极端值就能主导结果。"),
                        width: 260)
                Spacer()
                Text(T(s.kurtosis > 0 ? "尖峰" : "平峰")).font(.system(size: 9)).foregroundStyle(.tertiary)
                Text(fmt(s.kurtosis)).font(.system(size: 11.5, weight: .medium, design: .rounded).monospacedDigit())
            }

            if let w = normality {
                Divider().opacity(0.4)
                HStack(spacing: 4) {
                    Text("Shapiro–Wilk").font(.system(size: 11)).foregroundStyle(.secondary)
                    HelpDot(term: T("Shapiro–Wilk 检验"),
                            plain: T("专门用来判断「这批数据像不像正态分布」。它给一个 p 值：p 大（≥0.05）说明没有证据说它不正态；p 小说明明显不像。"),
                            example: T("p = 0.50 → 可以按正态处理，用 t 检验；p = 0.01 → 用 Mann–Whitney U。"),
                            width: 300)
                    Spacer()
                    Text("W = \(fmt(w.statistic))").font(.system(size: 11, design: .rounded).monospacedDigit())
                }
                HStack {
                    Text(T("p 值")).font(.system(size: 11)).foregroundStyle(.secondary)
                    Spacer()
                    Text(fmt(w.p)).font(.system(size: 12, weight: .semibold, design: .rounded).monospacedDigit())
                        .foregroundStyle(w.isNormal ? Color.green : Color.orange)
                }
            }
        }
        .frame(width: 268)
        .glassCard()
    }

    private func row(_ k: String, _ v: String, hint: String? = nil) -> some View {
        HStack(spacing: 6) {
            Text(k).font(.system(size: 11)).foregroundStyle(.secondary)
            Spacer()
            if let hint {
                Text(hint).font(.system(size: 9)).foregroundStyle(.tertiary)
            }
            Text(v).font(.system(size: 11.5, weight: .medium, design: .rounded).monospacedDigit())
        }
    }

    private func fmt(_ v: Double) -> String {
        v.isFinite ? String(format: "%.2f", v) : "—"
    }

    // MARK: 结论

    private var verdict: some View {
        let s = summary
        let w = normality
        let normal = w?.isNormal ?? false
        let enough = s.n >= 4
        let tint: Color = !enough ? .gray : (normal ? .green : .orange)

        return HStack(alignment: .top, spacing: 12) {
            Image(systemName: enough ? (normal ? "checkmark.seal.fill" : "exclamationmark.triangle.fill")
                                     : "questionmark.circle")
                .font(.system(size: 20))
                .foregroundStyle(tint)

            VStack(alignment: .leading, spacing: 3) {
                Text(headline(enough: enough, normal: normal))
                    .font(.system(size: 13, weight: .semibold, design: .rounded))
                Text(detail(enough: enough, normal: normal, w: w, n: s.n))
                    .font(.system(size: 11.5))
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            Spacer()
            if enough {
                Button(T("去对比两个语料")) {
                    withAnimation(Motion.snappy) {
                        ws.compareMetric = metric
                        ws.tab = .compare
                    }
                }
                .buttonStyle(.bordered)
                .controlSize(.small)
            }
        }
        .padding(14)
        .background {
            RoundedRectangle(cornerRadius: Theme.radius, style: .continuous)
                .fill(tint.opacity(0.10))
                .overlay {
                    RoundedRectangle(cornerRadius: Theme.radius, style: .continuous)
                        .strokeBorder(tint.opacity(0.28), lineWidth: 1)
                }
        }
    }

    private func headline(enough: Bool, normal: Bool) -> String {
        if !enough { return T("样本太少，正态性无法判断") }
        return T(normal ? "近似正态 → 建议用 t 检验" : "偏离正态 → 建议用 Mann–Whitney U")
    }

    private func detail(enough: Bool, normal: Bool, w: Stats.Normality?, n: Int) -> String {
        if !enough {
            return T("只有 %@ 篇，Shapiro–Wilk 至少需要 4 个样本。少于 4 篇时不要做两组检验；要么增加文本数量，要么只做描述性比较。", n)
        }
        let p = w.map { String(format: "%.2f", $0.p) } ?? "—"
        if normal {
            return T("Shapiro–Wilk p = %@ ≥ 0.05，没有证据说它偏离正态。对比两组时用 Welch t 检验（不假设方差齐性）最稳。", p)
        }
        return T("Shapiro–Wilk p = %@ < 0.05，分布明显偏离正态。对比两组时用 Mann–Whitney U，它只看秩，不受偏态影响。", p)
    }
}
