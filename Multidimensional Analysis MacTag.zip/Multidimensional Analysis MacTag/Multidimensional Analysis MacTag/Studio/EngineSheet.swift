import SwiftUI
import AppKit
import UniformTypeIdentifiers
import MATCore

// MARK: - 引擎设置

@MainActor
struct EngineSheet: View {
    @Environment(Workspace.self) private var ws
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text(T("标注引擎")).font(.system(size: 16, weight: .semibold, design: .rounded))
                    Text(T("MAT 用 Stanford MaxEnt 做词性标注，需要 Java + jar + 模型三件套"))
                        .font(.system(size: 11)).foregroundStyle(.secondary)
                }
                Spacer()
                Button { dismiss() } label: { Image(systemName: "xmark.circle.fill") }
                    .buttonStyle(.plain).foregroundStyle(.tertiary)
            }

            VStack(spacing: 8) {
                item(T("Java 运行时"), ws.engine.java?.path, ok: ws.engine.java != nil,
                     hint: T("任意 8+ 版本。系统没装时可以用 JetBrains 自带的 JBR。"))
                item("stanford-postagger.jar", ws.engine.jar?.lastPathComponent, ok: ws.engine.jar != nil,
                     hint: T("必须和模型配套：left3words-wsj-0-18 只能用 3.1.4（2012-11-11 包）的 jar。"))
                item(T("模型 .tagger"), ws.engine.model?.lastPathComponent, ok: ws.engine.model != nil,
                     hint: T("原版模型是 left3words-wsj-0-18.tagger，从 MAT 的 Windows 安装目录取。"))
                item(T("Vendor 目录"), ws.engine.vendor?.path, ok: ws.engine.vendor != nil,
                     hint: T("里面应有 stanford-postagger.jar 和 models/。"))
            }

            if let p = ws.engine.problem {
                HStack(spacing: 8) {
                    Image(systemName: "exclamationmark.triangle.fill").foregroundStyle(.orange)
                    Text(p).font(.system(size: 11.5))
                }
                .padding(10)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background { RoundedRectangle(cornerRadius: 10).fill(Color.orange.opacity(0.10)) }
            }

            Text(T("没有 Java 也能用：直接导入已经标注好的 `word_TAG` 文本（例如原版 MAT 产出的 `MAT_*` 文件），分析不走引擎。"))
                .font(.system(size: 10.5))
                .foregroundStyle(.secondary)

            HStack {
                Button(T("选择 Vendor 目录…")) { chooseVendor() }
                Button(T("重新检测")) {
                    ws.engine = EngineStatus.detect()
                }
                Spacer()
                Button(T("完成")) { dismiss() }.keyboardShortcut(.defaultAction)
            }
        }
        .padding(20)
        .frame(width: 520)
    }

    private func item(_ title: String, _ path: String?, ok: Bool, hint: String) -> some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: ok ? "checkmark.circle.fill" : "circle.dashed")
                .font(.system(size: 13))
                .foregroundStyle(ok ? Color.green : Color.secondary)
                .padding(.top, 1)
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.system(size: 11.5, weight: .medium))
                Text(path ?? hint)
                    .font(.system(size: 10, design: path == nil ? .default : .monospaced))
                    .foregroundStyle(path == nil ? .tertiary : .secondary)
                    .lineLimit(2)
                    .truncationMode(.middle)
            }
            Spacer()
        }
        .padding(9)
        .background {
            RoundedRectangle(cornerRadius: 9, style: .continuous)
                .fill(Color.primary.opacity(0.035))
        }
    }

    private func chooseVendor() {
        let panel = NSOpenPanel()
        panel.canChooseDirectories = true
        panel.canChooseFiles = false
        panel.title = T("选择 Vendor/Tagging 目录")
        panel.message = T("选包含 stanford-postagger.jar 与 models/ 的那个文件夹")
        if panel.runModal() == .OK, let url = panel.url {
            UserDefaults.standard.set(url.path, forKey: "MATVendorPath")
            ws.engine = EngineStatus.detect()
        }
    }
}

// MARK: - 导出

@MainActor
enum ExportService {

    // MARK: CSV

    static func exportCSV(_ corpus: Corpus?) {
        guard let c = corpus else { return }
        let panel = NSOpenPanel()
        panel.canChooseDirectories = true
        panel.canChooseFiles = false
        panel.canCreateDirectories = true
        panel.title = T("导出 CSV")
        panel.message = T("选一个目录，会写入 Statistics / Zscores / Dimensions 三个文件")
        guard panel.runModal() == .OK, let dir = panel.url else { return }

        let name = c.name
        let files: [(String, String)] = [
            ("Statistics_\(name).csv", Reports.statistics(c.result, allTags: c.settings.allTags)),
            ("Zscores_\(name).csv", Reports.zscores(c.result)),
            ("Dimensions_\(name).csv", Reports.dimensions(c.result)),
        ]
        for (f, body) in files {
            try? body.write(to: dir.appendingPathComponent(f), atomically: true, encoding: .utf8)
        }
        NSWorkspace.shared.activateFileViewerSelecting([dir])
    }

    // MARK: 六个维度一次导出

    /// 一次导出六张维度图（当前风格），并额外合成一张 2×3 的汇总图。
    static func exportDimensions(_ ws: Workspace, style: Workspace.ChartStyle) {
        guard let c = ws.current else { return }
        let panel = NSOpenPanel()
        panel.canChooseDirectories = true
        panel.canChooseFiles = false
        panel.canCreateDirectories = true
        panel.title = T("导出六张维度图")
        panel.message = T("选一个目录：会写 D1…D6 六张 PNG，外加一张合并图")
        guard panel.runModal() == .OK, let dir = panel.url else { return }
        writeDimensions(ws, style: style, to: dir)
        NSWorkspace.shared.activateFileViewerSelecting([dir])
    }

    /// 真正落盘的部分（不含文件选择，便于自动化验证）
    static func writeDimensions(_ ws: Workspace, style: Workspace.ChartStyle, to dir: URL) {
        guard let c = ws.current else { return }
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        let compare = ws.dimCompareID.flatMap { id in ws.corpora.first { $0.id == id } }
        let cell = CGSize(width: 1180, height: 640)
        var images: [NSImage] = []

        for dim in 1...6 {
            let content = VStack(alignment: .leading, spacing: 12) {
                HStack(alignment: .firstTextBaseline, spacing: 8) {
                    Text("D\(dim) · \(Dims.meta(dim).english)")
                        .font(.system(size: 17, weight: .semibold, design: .rounded))
                    Spacer()
                    Text(style.title)
                        .font(.system(size: 10, weight: .medium))
                        .padding(.horizontal, 8).padding(.vertical, 3)
                        .background { Capsule().fill(Color.primary.opacity(0.06)) }
                        .foregroundStyle(.secondary)
                }
                Text(T("灰色是 8 个参考体裁的区间与均值；彩色是本语料（叠加时还有对比语料）"))
                    .font(.system(size: 11))
                    .foregroundStyle(.secondary)

                DimensionChartView(corpus: c, compare: compare, dim: dim, style: style,
                                   documentName: ws.selectedDocument,
                                   height: 430, showTitle: false, showHoverHint: false)
                Spacer(minLength: 4)
                HStack(spacing: 6) {
                    Text(T("%@ · %@ 篇 · %@ 词 · %@", c.name, c.documents.count, c.tokens, c.settings.summary))
                        .font(.system(size: 9.5))
                        .foregroundStyle(.tertiary)
                    Spacer()
                    Text("MA Studio")
                        .font(.system(size: 9.5, weight: .medium, design: .rounded))
                        .foregroundStyle(.tertiary)
                }
            }
            .padding(26)
            .frame(width: cell.width, height: cell.height, alignment: .topLeading)
            .background(Color(nsColor: .windowBackgroundColor))

            guard let img = render(content, size: cell) else { continue }
            images.append(img)
            write(img, to: dir.appendingPathComponent("D\(dim)_\(c.name).png"))
        }

        if let merged = merge(images, cell: cell, scale: 2) {
            let suffix = style == .legacy ? "legacy" : "bars"
            write(merged, to: dir.appendingPathComponent("Dimensions_\(c.name)_all_\(suffix).png"))
        }
    }

    // MARK: 文本类型大图

    static func exportTextType(_ ws: Workspace) {
        guard let c = ws.current else { return }
        let panel = NSSavePanel()
        panel.allowedContentTypes = [.png]
        panel.nameFieldStringValue = "TextTypes_\(c.name).png"
        guard panel.runModal() == .OK, let url = panel.url else { return }
        writeTextType(ws, to: url)
    }

    static func writeTextType(_ ws: Workspace, to url: URL) {
        guard let c = ws.current else { return }
        let ranking = TextTypeRanking.rank(dims: c.dims)
        let size = CGSize(width: 1900, height: 830)
        let content = VStack(alignment: .leading, spacing: 16) {
            HStack(alignment: .firstTextBaseline) {
                VStack(alignment: .leading, spacing: 3) {
                    Text(T("文本类型 · %@", TextTypes.name(c.textType)))
                        .font(.system(size: 26, weight: .semibold, design: .rounded))
                    Text(c.textType)
                        .font(.system(size: 12))
                        .foregroundStyle(.secondary)
                }
                Spacer()
                if let best = ranking.first {
                    Text(T("最近距离 %@", String(format: "%.2f", best.distance)))
                        .font(.system(size: 12, weight: .medium, design: .rounded).monospacedDigit())
                        .padding(.horizontal, 10).padding(.vertical, 5)
                        .background { Capsule().fill(Dims.color(2).opacity(0.16)) }
                        .foregroundStyle(Dims.color(2))
                }
            }

            TextTypeChartView(corpus: c, style: ws.textTypeStyle, height: 580, showTitle: false)

            HStack(alignment: .top, spacing: 40) {
                ForEach(Array(ranking.prefix(4).enumerated()), id: \.element.id) { i, r in
                    VStack(alignment: .leading, spacing: 2) {
                        Text("\(i + 1). \(TextTypes.name(r.name))")
                            .font(.system(size: 12, weight: i == 0 ? .semibold : .regular))
                        Text(String(format: "%.2f", r.distance))
                            .font(.system(size: 11, design: .rounded).monospacedDigit())
                            .foregroundStyle(.secondary)
                    }
                }
                Spacer()
            }

            HStack {
                Text(T("八条灰线 = Biber 1989 的八种文本类型原型；彩色线 = %@（细线为单篇）。D1 图上除以 10 以平衡量级。", c.name))
                    .font(.system(size: 10))
                    .foregroundStyle(.tertiary)
                Spacer()
                Text("MA Studio")
                    .font(.system(size: 10, weight: .medium, design: .rounded))
                    .foregroundStyle(.tertiary)
            }
        }
        .padding(36)
        .frame(width: size.width, height: size.height, alignment: .topLeading)
        .background(Color(nsColor: .windowBackgroundColor))

        if let img = render(content, size: size) { write(img, to: url) }
    }

    // MARK: 渲染工具

    private static func render<V: View>(_ view: V, size: CGSize, scale: CGFloat = 2) -> NSImage? {
        let renderer = ImageRenderer(content: view.frame(width: size.width, height: size.height))
        renderer.scale = scale
        return renderer.nsImage
    }

    private static func write(_ image: NSImage, to url: URL) {
        guard let tiff = image.tiffRepresentation,
              let rep = NSBitmapImageRep(data: tiff),
              let png = rep.representation(using: .png, properties: [:]) else { return }
        try? png.write(to: url)
    }

    /// 2 列 × 3 行拼成一张（保持 2× 分辨率）
    private static func merge(_ images: [NSImage], cell: CGSize, scale: CGFloat) -> NSImage? {
        guard images.count == 6 else { return nil }
        let width = cell.width * 2, height = cell.height * 3
        guard let rep = NSBitmapImageRep(bitmapDataPlanes: nil,
                                         pixelsWide: Int(width * scale), pixelsHigh: Int(height * scale),
                                         bitsPerSample: 8, samplesPerPixel: 4, hasAlpha: true,
                                         isPlanar: false, colorSpaceName: .deviceRGB,
                                         bytesPerRow: 0, bitsPerPixel: 0) else { return nil }
        rep.size = NSSize(width: width, height: height)
        NSGraphicsContext.saveGraphicsState()
        NSGraphicsContext.current = NSGraphicsContext(bitmapImageRep: rep)
        NSColor.windowBackgroundColor.setFill()
        NSRect(x: 0, y: 0, width: width, height: height).fill()
        for (i, img) in images.enumerated() {
            let col = i % 2, row = i / 2
            let rect = NSRect(x: CGFloat(col) * cell.width,
                              y: CGFloat(2 - row) * cell.height,
                              width: cell.width, height: cell.height)
            img.draw(in: rect)
        }
        NSGraphicsContext.restoreGraphicsState()
        let out = NSImage(size: NSSize(width: width, height: height))
        out.addRepresentation(rep)
        return out
    }
}
