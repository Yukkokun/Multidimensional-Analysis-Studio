import SwiftUI
import MATCore

// MARK: - 特征表

@MainActor
struct FeaturesView: View {
    @Environment(Workspace.self) private var ws
    var corpus: Corpus

    @State private var query = ""
    @State private var dimFilter: Int? = nil
    @State private var sort: SortKey = .absZ

    enum SortKey: String, CaseIterable, Identifiable {
        case absZ = "按 |z|"
        case freq = "按频次"
        case name = "按名称"
        var id: String { rawValue }
    }

    private var doc: DocumentResult? {
        guard let n = ws.selectedDocument else { return nil }
        return corpus.documents.first { $0.name == n }
    }

    private var rows: [FeatureRow] {
        // 65 个 Biber 特征 + AWL / TTR，共 67 个 linguistic variable
        let ids = ["AWL", "TTR"] + Catalog.shared.featureOrder.filter { $0 != "AWL" && $0 != "TTR" }
        var out: [FeatureRow] = ids.map { id in
            let freq: Double
            let z: Double
            switch id {
            case "AWL":
                freq = doc.map { $0.awl } ?? (corpus.result.corpusAWL ?? corpus.documents.first?.awl ?? 0)
                z = doc.map { $0.z["AWL"] ?? 0 } ?? (corpus.result.corpusZ?["AWL"] ?? 0)
            case "TTR":
                freq = doc.map { Double($0.types) } ?? (corpus.result.corpusTypes ?? Double(corpus.documents.first?.types ?? 0))
                z = doc.map { $0.z["TTR"] ?? 0 } ?? (corpus.result.corpusZ?["TTR"] ?? 0)
            default:
                freq = doc.map { $0.freq[id] ?? 0 } ?? (corpus.documents.reduce(0.0) { $0 + ($1.freq[id] ?? 0) } / Double(max(1, corpus.documents.count)))
                z = doc.map { $0.z[id] ?? 0 } ?? (corpus.result.corpusZ?[id] ?? 0)
            }
            return FeatureRow(id: id, gloss: Features.glossText(id),
                              dims: Features.info(id).dims, positive: Features.info(id).positive,
                              freq: freq, z: z, raw: doc?.raw[id] ?? 0,
                              isMetric: id == "AWL" || id == "TTR")
        }
        if let d = dimFilter {
            out = out.filter { $0.dims.contains(d) }
        }
        if !query.isEmpty {
            let q = query.lowercased()
            out = out.filter { $0.id.lowercased().contains(q) || $0.gloss.contains(query) }
        }
        switch sort {
        case .absZ: out.sort { abs($0.z) > abs($1.z) }
        case .freq: out.sort { $0.freq > $1.freq }
        case .name: out.sort { $0.id < $1.id }
        }
        return out
    }

    private var maxAbsZ: Double { max(2, rows.map { abs($0.z) }.max() ?? 2) }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            controls
            table
        }
    }

    private var controls: some View {
        HStack(spacing: 10) {
            HStack(spacing: 6) {
                Image(systemName: "magnifyingglass")
                    .font(.system(size: 11, weight: .medium))
                    .foregroundStyle(.tertiary)
                TextField(T("搜索特征或中文名"), text: $query)
                    .textFieldStyle(.plain)
                    .font(.system(size: 12))
                if !query.isEmpty {
                    Button { query = "" } label: {
                        Image(systemName: "xmark.circle.fill").font(.system(size: 10))
                            .foregroundStyle(.tertiary)
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(.horizontal, 9).padding(.vertical, 6)
            .frame(width: 210)
            .background {
                RoundedRectangle(cornerRadius: 9, style: .continuous).fill(.thinMaterial)
                    .overlay { RoundedRectangle(cornerRadius: 9, style: .continuous)
                        .strokeBorder(Color.primary.opacity(0.06), lineWidth: 1) }
            }

            Chip(text: T("全部"), isOn: dimFilter == nil) { dimFilter = nil }
            ForEach(Dims.all) { m in
                Chip(text: m.label, isOn: dimFilter == m.id, tint: m.color) {
                    dimFilter = (dimFilter == m.id) ? nil : m.id
                }
            }

            Spacer()

            Picker("", selection: $sort) {
                ForEach(SortKey.allCases) { k in Text(k.rawValue).tag(k) }
            }
            .labelsHidden()
            .pickerStyle(.menu)
            .frame(width: 108)
            .controlSize(.small)
        }
    }

    private var table: some View {
        VStack(spacing: 0) {
            HStack {
                Text(T("特征")).frame(width: 128, alignment: .leading)
                Text(T("说明")).frame(maxWidth: .infinity, alignment: .leading)
                Text(T("每百词 / 值"))
                    .frame(width: 70, alignment: .trailing)
                HStack(spacing: 2) {
                    Text("z").frame(width: 40, alignment: .trailing)
                    HelpDot(term: T("z 分数"),
                            plain: T("把频次换算成「比 Biber 基准高/低几个标准差」。0 = 和基准一样，+2 以上算明显偏高，−2 以下明显偏低。"),
                            example: T("z = +3.4 的 [SPAU]：这类动词用得比基准多得多，是 D4 的主要推手。"),
                            width: 280)
                }
                .frame(width: 52, alignment: .trailing)
                Text(T("偏离")).frame(width: 92, alignment: .leading)
            }
            .font(.system(size: 10, weight: .medium))
            .foregroundStyle(.tertiary)
            .padding(.horizontal, 14)
            .padding(.vertical, 7)

            Divider().opacity(0.35)

            ScrollView {
                LazyVStack(spacing: 0) {
                    ForEach(rows) { r in
                        FeatureRowView(row: r, maxAbsZ: maxAbsZ, dims: dimFilter ?? r.dims.first ?? 1) {
                            withAnimation(Motion.snappy) {
                                ws.distributionMetric = .feature(r.id)
                                ws.selectedFeature = r.id
                                ws.tab = .distribution
                            }
                        }
                        Divider().opacity(0.18)
                    }
                }
            }
            .frame(minHeight: 260)
        }
        .glassCard(padding: 0)
        .overlay(alignment: .bottomLeading) {
            Text(T("共 %@ 个变量：65 个 Biber 特征 + AWL / TTR（标「指标」，单位不是每百词）", rows.count))
                .font(.system(size: 9.5))
                .foregroundStyle(.tertiary)
                .padding(.horizontal, 14)
                .padding(.bottom, 5)
                .allowsHitTesting(false)
        }
    }
}

struct FeatureRow: Identifiable {
    var id: String
    var gloss: String
    var dims: [Int]
    var positive: Bool
    var freq: Double
    var z: Double
    var raw: Int
    /// AWL / TTR 不是「每百词」频次，而是指标本身的值
    var isMetric: Bool = false
}

@MainActor
struct FeatureRowView: View {
    var row: FeatureRow
    var maxAbsZ: Double
    var dims: Int
    var onTap: () -> Void
    @State private var hover = false

    private var color: Color { Dims.color(row.dims.first ?? 1) }

    var body: some View {
        Button(action: onTap) {
            HStack(spacing: 0) {
                HStack(spacing: 6) {
                    Text(row.id)
                        .font(.system(size: 12, weight: .semibold, design: .monospaced))
                        .foregroundStyle(color)
                    if row.isMetric {
                        Text(T("指标"))
                            .font(.system(size: 7.5, weight: .bold))
                            .padding(.horizontal, 3).padding(.vertical, 0.5)
                            .background { RoundedRectangle(cornerRadius: 2.5).fill(Color.primary.opacity(0.07)) }
                            .foregroundStyle(.tertiary)
                    }
                    if row.dims.count > 1 {
                        Text("+\(row.dims.count)")
                            .font(.system(size: 8, weight: .bold))
                            .foregroundStyle(.tertiary)
                    }
                }
                .frame(width: 128, alignment: .leading)

                Text(row.gloss)
                    .font(.system(size: 11.5))
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
                    .frame(maxWidth: .infinity, alignment: .leading)

                Text(row.id == "TTR" ? String(format: "%.0f", row.freq)
                                     : String(format: "%.2f", row.freq))
                    .font(.system(size: 11.5, design: .rounded).monospacedDigit())
                    .foregroundStyle(row.isMetric ? AnyShapeStyle(Color.primary)
                                                  : AnyShapeStyle(Color.secondary))
                    .frame(width: 70, alignment: .trailing)

                Text(abs(row.z) >= 100 ? "⚠︎" : String(format: "%+.2f", row.z))
                    .font(.system(size: 11.5, weight: .medium, design: .rounded).monospacedDigit())
                    .foregroundStyle(abs(row.z) > 2 ? color : .secondary)
                    .frame(width: 52, alignment: .trailing)
                    .help(abs(row.z) >= 100
                          ? "z = \(String(format: "%.1f", row.z))：该特征 sd 极小（[SPIN] 是 0.00001），原版 MAT 也会给出这种爆炸值。这是原版行为，不是算错。"
                          : "")

                DivergingBar(value: row.z, maxAbs: maxAbsZ, color: color, height: 4)
                    .frame(width: 92)
                    .padding(.leading, 10)
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 6.5)
            .background(hover ? Color.primary.opacity(0.04) : Color.clear)
        }
        .buttonStyle(.plain)
        .onHover { hover = $0 }
        .help(T("点击看这个特征在各篇里的分布"))
    }
}
