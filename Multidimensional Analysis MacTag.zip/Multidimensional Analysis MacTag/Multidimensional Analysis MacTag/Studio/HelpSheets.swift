import SwiftUI
import AppKit

// MARK: - Help 菜单能打开的窗口

enum HelpSheet: String, Identifiable, CaseIterable {
    case introduction
    case manual
    case github
    case license
    case versionHistory
    case update

    var id: String { rawValue }

    @MainActor var title: String {
        switch self {
        case .introduction: return T("Introduction")
        case .manual: return T("Manual")
        case .github: return "GitHub Homepage"
        case .license: return "Show License"
        case .versionHistory: return "Show Version History"
        case .update: return "Check for Update"
        }
    }

    var icon: String {
        switch self {
        case .introduction: return "book"
        case .manual: return "book.pages"
        case .github: return "chevron.left.forwardslash.chevron.right"
        case .license: return "doc.text"
        case .versionHistory: return "clock.arrow.circlepath"
        case .update: return "arrow.triangle.2.circlepath"
        }
    }
}

// MARK: - 容器

@MainActor
struct HelpSheetView: View {
    var sheet: HelpSheet
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 8) {
                Image(systemName: sheet.icon)
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundStyle(Theme.accent)
                Text(sheet.title)
                    .font(.system(size: 14, weight: .semibold, design: .rounded))
                Spacer()
                Text("\(AppInfo.name) \(AppInfo.version)")
                    .font(.system(size: 10, design: .rounded))
                    .foregroundStyle(.tertiary)
                Button { dismiss() } label: {
                    Image(systemName: "xmark.circle.fill")
                        .font(.system(size: 13))
                        .foregroundStyle(.tertiary)
                }
                .buttonStyle(.plain)
            }
            .padding(.horizontal, 18)
            .padding(.vertical, 12)

            Divider().opacity(0.5)

            Group {
                switch sheet {
                case .introduction: IntroductionView()
                case .manual: ManualView()
                case .github: GitHubView()
                case .license: LicenseView()
                case .versionHistory: VersionHistoryView()
                case .update: UpdateView()
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .frame(width: 680, height: 660)
        .background(Color(nsColor: .windowBackgroundColor))
    }
}

// MARK: - Introduction

@MainActor
struct IntroductionView: View {
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                VStack(alignment: .leading, spacing: 6) {
                    Text(LText("这是做什么的", "What this is").text)
                        .font(.system(size: 15, weight: .semibold, design: .rounded))
                    Text(LText("MA Studio 把 Douglas Biber 的多维分析（Multidimensional Analysis）做成了原生 macOS 应用：读入一批英文纯文本，标词性、算 67 个语言特征、换算成 z 分数、再合成 6 个维度分，最后判定文本类型。",
                               "MA Studio brings Douglas Biber's Multidimensional Analysis to macOS: load plain English text, tag parts of speech, count 67 linguistic features, convert them to z-scores, combine them into six dimension scores, and identify the text type.").text)
                        .font(.system(size: 12))
                        .foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }

                section(LText("三步用起来", "Three steps"), [
                    (LText("导入语料", "Import"),
                     LText("点左上角「导入」或直接把 .txt / 文件夹拖进窗口。一个文件夹算一个语料库，里面的 .txt 每篇算一个样本。",
                           "Use Import at the top left, or drag .txt files or a folder into the window. One folder is one corpus; each .txt is one sample.")),
                    (LText("看结果", "Read"),
                     LText("概览给你文本类型和六个维度；维度页把分数放到 8 个参考体裁里比；分布页告诉你数据够不够正态。",
                           "Overview gives the text type and six dimensions; Dimensions places your scores among eight reference genres; Distribution says whether the data are close to normal.")),
                    (LText("导出", "Export"),
                     LText("工具栏「导出」可以出六张维度图、文本类型大图、三个 CSV；各数据表右上角能复制成表格或导出图片。",
                           "The Export menu produces six dimension charts, a text-type chart and three CSVs; every data table can be copied or exported as an image.")),
                ])

                section(LText("八个页签", "Eight tabs"), [
                    (LText("概览", "Overview"),
                     LText("文本类型判定、六维卡片、逐维度最近体裁。",
                           "Text-type verdict, six dimension cards, nearest genre per dimension.")),
                    (LText("维度", "Dimensions"),
                     LText("误差线图 / 横向柱状图两种呈现，可叠加第二个语料库对照。",
                           "Error bars or horizontal bars, optionally overlaid with a second corpus.")),
                    (LText("六维", "Six dims"),
                     LText("六个维度的横向条形图，两个语料上下对照。",
                           "Horizontal bars for the six dimensions, with a second corpus stacked underneath.")),
                    (LText("文本类型", "Text types"),
                     LText("五维轮廓；「原版方式」是每维一列散点，每类一个带名字的点。",
                           "A five-dimension profile; Classic mode scatters one labelled dot per type in each column.")),
                    (LText("特征", "Features"),
                     LText("67 个语言变量的频次与 z 分数，可按维度筛、按 |z| 排序。",
                           "Frequency and z-scores for 67 variables, filterable by dimension and sortable by |z|.")),
                    (LText("分布", "Distribution"),
                     LText("直方图 + 核密度 + 正态曲线 + Shapiro–Wilk，并判断该用 t 还是 U。",
                           "Histogram, density, normal curve and Shapiro–Wilk, with a t-versus-U recommendation.")),
                    (LText("对比", "Compare"),
                     LText("两个语料的六维比较：Welch t 与 Mann–Whitney U 并列，含效应量与置信区间。",
                           "Six-dimension comparison of two corpora: Welch's t and Mann–Whitney U side by side, with effect sizes and confidence intervals.")),
                    (LText("Z 对比", "Z-compare"),
                     LText("逐变量比 z 分数，按六个维度分组，可选 BH-FDR / Holm 校正。",
                           "Variable-by-variable z-score comparison, grouped by dimension, with BH-FDR or Holm correction.")),
                ])

                section(LText("关于引擎", "About the engine"), [
                    (LText("词性标注", "Tagging"),
                     LText("需要 Java + stanford-postagger 3.1.4 + left3words-wsj-0-18 模型，三者必须配套。点侧栏底部状态灯可以配置。",
                           "Needs Java, stanford-postagger 3.1.4 and the left3words-wsj-0-18 model — all three must match. Click the status light at the bottom of the sidebar to configure.")),
                    (LText("没有 Java 也能用", "No Java needed"),
                     LText("直接导入已经标好的 word_TAG 文本，应用会自动识别并跳过标注。",
                           "Import text that is already tagged as word_TAG; the app detects it and skips tagging.")),
                ])

                section(LText("几个快捷键", "Shortcuts"), [
                    (LText("⌘O", "⌘O"), LText("导入语料", "Import a corpus")),
                    (LText("⌘R", "⌘R"), LText("用当前设置重跑", "Re-run with current settings")),
                    (LText("⌘1…⌘8", "⌘1…⌘8"), LText("切换页签", "Switch tabs")),
                ])

                HStack {
                    Spacer()
                    Button(T("开始使用")) { dismiss() }
                        .buttonStyle(.borderedProminent)
                        .controlSize(.large)
                }
                .padding(.top, 4)
            }
            .padding(22)
        }
    }

    private func section(_ title: LText, _ items: [(LText, LText)]) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title.text)
                .font(.system(size: 13, weight: .semibold, design: .rounded))
            VStack(alignment: .leading, spacing: 7) {
                ForEach(Array(items.enumerated()), id: \.offset) { _, item in
                    HStack(alignment: .top, spacing: 8) {
                        Text(item.0.text)
                            .font(.system(size: 11.5, weight: .medium))
                            .frame(width: 108, alignment: .leading)
                        Text(item.1.text)
                            .font(.system(size: 11.5))
                            .foregroundStyle(.secondary)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }
            }
            .padding(12)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background {
                RoundedRectangle(cornerRadius: 10, style: .continuous)
                    .fill(Color.primary.opacity(0.035))
            }
        }
    }
}

// MARK: - GitHub

@MainActor
struct GitHubView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var copied = false

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack(spacing: 10) {
                Image(systemName: "chevron.left.forwardslash.chevron.right")
                    .font(.system(size: 22, weight: .light))
                    .foregroundStyle(Theme.accent)
                VStack(alignment: .leading, spacing: 2) {
                    Text(T("GitHub 仓库")).font(.system(size: 14, weight: .semibold, design: .rounded))
                    Text("\(AppInfo.repoOwner)/\(AppInfo.repoName)")
                        .font(.system(size: 11, design: .monospaced))
                        .foregroundStyle(.secondary)
                }
                Spacer()
            }

            if AppInfo.isPublished {
                Text(T("在浏览器里打开仓库，查看源码、提交问题或参与改进。"))
                    .font(.system(size: 12))
                    .foregroundStyle(.secondary)
                Link(destination: AppInfo.githubURL) {
                    Label(T("打开 GitHub 页面"), systemImage: "arrow.up.right.square")
                }
                .buttonStyle(.borderedProminent)
            } else {
                HStack(alignment: .top, spacing: 8) {
                    Image(systemName: "clock.badge.exclamationmark")
                        .font(.system(size: 13))
                        .foregroundStyle(.orange)
                    Text(T("仓库还没有公开。等发布后，「GitHub Homepage」与「Check for Update」会自动指向真实地址（代码里只需改 `AppInfo.repoOwner` / `repoName` 并把 `isPublished` 设为 true）。"))
                        .font(.system(size: 11.5))
                        .foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
                .padding(12)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background {
                    RoundedRectangle(cornerRadius: 10, style: .continuous)
                        .fill(Color.orange.opacity(0.10))
                }

                HStack(spacing: 8) {
                    Text(AppInfo.githubURL.absoluteString)
                        .font(.system(size: 11, design: .monospaced))
                        .foregroundStyle(.secondary)
                        .textSelection(.enabled)
                    Spacer()
                    Button(T(copied ? "已复制" : "复制地址")) {
                        NSPasteboard.general.clearContents()
                        NSPasteboard.general.setString(AppInfo.githubURL.absoluteString, forType: .string)
                        copied = true
                    }
                    .controlSize(.small)
                }
                .padding(10)
                .background {
                    RoundedRectangle(cornerRadius: 8, style: .continuous)
                        .fill(Color.primary.opacity(0.04))
                }
            }

            Spacer()
            HStack {
                Spacer()
                Button(T("关闭")) { dismiss() }.keyboardShortcut(.cancelAction)
            }
        }
        .padding(22)
    }
}

// MARK: - License

@MainActor
struct LicenseView: View {
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack(spacing: 8) {
                Text("GNU General Public License v3.0")
                    .font(.system(size: 12.5, weight: .semibold, design: .rounded))
                Spacer()
                Text("\(AppInfo.name) \(AppInfo.version) · \(AppInfo.copyright)")
                    .font(.system(size: 10))
                    .foregroundStyle(.tertiary)
            }
            .padding(.horizontal, 18)
            .padding(.vertical, 10)

            Divider().opacity(0.4)

            ScrollView {
                Text(LicenseText.gpl3)
                    .font(.system(size: 10.5, design: .monospaced))
                    .foregroundStyle(.secondary)
                    .textSelection(.enabled)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(18)
            }

            Divider().opacity(0.4)
            HStack {
                Text(T("仓库根目录的 LICENSE 与本页内容完全一致。"))
                    .font(.system(size: 10))
                    .foregroundStyle(.tertiary)
                Spacer()
                Button(T("关闭")) { dismiss() }.keyboardShortcut(.cancelAction)
            }
            .padding(.horizontal, 18)
            .padding(.vertical, 10)
        }
    }
}

// MARK: - Version History

@MainActor
struct VersionHistoryView: View {
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    ForEach(Changelog.entries) { entry in
                        entryCard(entry)
                    }

                    Text(LText("版本号规则：功能性更新 +0.1，修复 +0.0.1。",
                               "Versioning: features +0.1, fixes +0.0.1.").text)
                        .font(.system(size: 10))
                        .foregroundStyle(.tertiary)
                }
                .padding(20)
            }

            Divider().opacity(0.4)
            HStack {
                Spacer()
                Button(T("关闭")) { dismiss() }.keyboardShortcut(.cancelAction)
            }
            .padding(.horizontal, 18)
            .padding(.vertical, 10)
        }
    }

    @ViewBuilder
    private func entryCard(_ entry: ChangelogEntry) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            header(entry)
            Text(entry.summary.text)
                .font(.system(size: 11.5, weight: .medium))
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
            VStack(alignment: .leading, spacing: 4) {
                ForEach(Array(entry.notes.enumerated()), id: \.offset) { _, note in
                    HStack(alignment: .top, spacing: 6) {
                        Circle().fill(Theme.accent.opacity(0.55))
                            .frame(width: 4, height: 4)
                            .padding(.top, 5)
                        Text(note.text)
                            .font(.system(size: 11))
                            .foregroundStyle(.secondary)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }
            }
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background {
            RoundedRectangle(cornerRadius: 10, style: .continuous)
                .fill(Color.primary.opacity(0.035))
        }
    }

    @ViewBuilder
    private func header(_ entry: ChangelogEntry) -> some View {
        HStack(alignment: .firstTextBaseline, spacing: 8) {
            Text(T("版本 %@", entry.version))
                .font(.system(size: 14, weight: .semibold, design: .rounded))
            if entry.version == AppInfo.version {
                Text(T("当前"))
                    .font(.system(size: 9, weight: .semibold))
                    .padding(.horizontal, 5).padding(.vertical, 1.5)
                    .background { Capsule().fill(Theme.accent.opacity(0.16)) }
                    .foregroundStyle(Theme.accent)
            }
            Spacer()
            Text(entry.date)
                .font(.system(size: 10.5, design: .rounded))
                .foregroundStyle(.tertiary)
        }
    }
}

// MARK: - Check for Update

@MainActor
struct UpdateView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var state: UpdateChecker.State = .idle

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack(spacing: 12) {
                ZStack {
                    RoundedRectangle(cornerRadius: 10, style: .continuous)
                        .fill(LinearGradient(colors: [Dims.color(4), Dims.color(5)],
                                             startPoint: .topLeading, endPoint: .bottomTrailing))
                        .frame(width: 44, height: 44)
                    Image(systemName: "arrow.triangle.2.circlepath")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundStyle(.white)
                }
                VStack(alignment: .leading, spacing: 2) {
                    Text("\(AppInfo.name) \(AppInfo.version)")
                        .font(.system(size: 14, weight: .semibold, design: .rounded))
                    Text(T("构建于 %@", AppInfo.buildDate))
                        .font(.system(size: 10.5))
                        .foregroundStyle(.tertiary)
                }
                Spacer()
            }

            content

            Spacer()

            HStack(spacing: 8) {
                Button {
                    Task { await run() }
                } label: {
                    Label(T("重新检查"), systemImage: "arrow.clockwise")
                }
                .disabled(state == .checking)

                Spacer()
                Button(T("关闭")) { dismiss() }.keyboardShortcut(.cancelAction)
            }
        }
        .padding(22)
        .task { if state == .idle { await run() } }
    }

    @ViewBuilder
    private var content: some View {
        switch state {
        case .idle, .checking:
            HStack(spacing: 8) {
                ProgressView().controlSize(.small)
                Text(T("正在检查 GitHub 上的最新版本…"))
                    .font(.system(size: 11.5))
                    .foregroundStyle(.secondary)
            }
            .padding(.vertical, 6)

        case .notPublished:
            infoBox(icon: "shippingbox", tint: .orange,
                    title: T("还没有发布到 GitHub"),
                    message: T("当前是本地构建的 %@。等仓库公开后，这里会比对 GitHub Releases 的版本号；如果发现更新的版本，会在这里直接问你「是否更新」。", AppInfo.version))

        case .upToDate(let current):
            infoBox(icon: "checkmark.seal.fill", tint: .green,
                    title: T("已是最新版本（%@）", current),
                    message: T("GitHub 上最新的 Release 与你手上的版本一致。"))

        case .newer(let current, let latest, let url):
            infoBox(icon: "arrow.down.circle.fill", tint: Theme.accent,
                    title: T("发现新版本 %@", latest),
                    message: T("你当前是 %@。要前往下载页更新吗？", current))
            HStack(spacing: 8) {
                Link(destination: url) {
                    Label(T("前往下载"), systemImage: "arrow.up.right.square")
                }
                .buttonStyle(.borderedProminent)
                Button(T("稍后")) { dismiss() }
            }

        case .failed(let message):
            infoBox(icon: "exclamationmark.triangle.fill", tint: .red,
                    title: T("检查失败"),
                    message: message)
        }
    }

    private func infoBox(icon: String, tint: Color, title: String, message: String) -> some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: icon)
                .font(.system(size: 16))
                .foregroundStyle(tint)
            VStack(alignment: .leading, spacing: 4) {
                Text(title).font(.system(size: 12.5, weight: .semibold, design: .rounded))
                Text(message)
                    .font(.system(size: 11.5))
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            Spacer()
        }
        .padding(12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background {
            RoundedRectangle(cornerRadius: 10, style: .continuous).fill(tint.opacity(0.10))
        }
    }

    private func run() async {
        state = .checking
        let result = await UpdateChecker.check()
        withAnimation(Motion.snappy) { state = result }
    }
}
