import SwiftUI
import Observation

// MARK: - 语言与翻译
//
// 做法：代码里保留中文原文作为 **key**，查表得到当前语言的文案。
// 好处是运行时可切换（不需要重启），也不依赖 bundle 里的 .lproj 资源——
// 这样 Xcode 构建和 Tools/ui-build 的 SPM 构建走的是同一套逻辑。
//
// 插值字符串（"\(n) 篇"）不能直接当 key，改写成 T("%@ 篇", n) 的形式，
// 表里存的是带 %@ 的模板。

enum Lang: String, CaseIterable, Identifiable, Sendable {
    case en
    case zh

    var id: String { rawValue }

    /// 语言菜单里用自己的语言写，避免用户看不懂
    var label: String {
        switch self {
        case .en: return "English"
        case .zh: return "简体中文"
        }
    }
}

@MainActor
@Observable
final class Localizer {
    static let shared = Localizer()

    var lang: Lang {
        didSet {
            UserDefaults.standard.set(lang.rawValue, forKey: Self.key)
            // 用一个递增的 token 让根视图整棵重建，保证所有 T() 重新求值
            revision &+= 1
        }
    }

    /// 语言变化时 +1，根视图用它做 .id()
    private(set) var revision = 0

    private static let key = "MATLanguage"

    private init() {
        // 截图/测试用：MAT_LANG=zh 可强制语言
        if let forced = ProcessInfo.processInfo.environment["MAT_LANG"],
           let l = Lang(rawValue: forced) {
            lang = l
            return
        }
        let saved = UserDefaults.standard.string(forKey: Self.key)
        // 默认英语（用户要求）
        lang = saved.flatMap(Lang.init(rawValue:)) ?? .en
    }

    func translate(_ key: String) -> String {
        switch lang {
        case .zh: return key
        case .en: return Tables.zh2en[key] ?? key
        }
    }
}

/// 取当前语言的文案
@MainActor
func T(_ key: String) -> String {
    Localizer.shared.translate(key)
}

/// 带插值的模板：T("%@ 篇", count)
///
/// 不用 String(format:)：`%@` 传 Int 会崩（arm64 把整数当指针）。
/// 这里按顺序把每个 `%@` 替换成参数的字符串形式，既安全又不挑类型。
@MainActor
func T(_ key: String, _ args: Any...) -> String {
    var text = Localizer.shared.translate(key)
    for arg in args {
        guard let r = text.range(of: "%@") else { break }
        text.replaceSubrange(r, with: "\(arg)")
    }
    return text
}

/// 数组形式的参数（Progress 之类把参数存在模型里）
@MainActor
func T(_ key: String, _ args: [String]) -> String {
    var text = Localizer.shared.translate(key)
    for arg in args {
        guard let r = text.range(of: "%@") else { break }
        text.replaceSubrange(r, with: arg)
    }
    return text
}

/// 数字 + 单位这类拼装，避免复数问题写成 "3 item(s)"
@MainActor
func TCount(_ n: Int, _ unitKey: String) -> String {
    switch Localizer.shared.lang {
    case .zh: return "\(n) \(unitKey)"
    case .en: return n == 1 ? "1 \(T(unitKey))" : "\(n) \(T(unitKey))s"
    }
}
