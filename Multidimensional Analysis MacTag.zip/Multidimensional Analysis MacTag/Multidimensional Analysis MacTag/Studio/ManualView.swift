import SwiftUI
import Charts
import MATCore

// MARK: - 双语文本
//
// 手册的每一段都同时写好中英文，跟着设置里的语言切换。
// 图不截图，而是用 SwiftUI 现画——换语言、换外观都不会糊，也不需要打包图片资源。

struct LText {
    let zh: String
    let en: String

    @MainActor var text: String { Localizer.shared.lang == .zh ? zh : en }

    init(_ zh: String, _ en: String) {
        self.zh = zh
        self.en = en
    }
}

// MARK: - 手册

@MainActor
struct ManualView: View {
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 26) {
                intro
                chapter1
                chapter2
                chapter3
                chapter4
                chapter5
                chapter6
                glossary
            }
            .padding(.horizontal, 22)
            .padding(.vertical, 18)
            .frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    // MARK: 开篇

    private var intro: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(LText("MA Studio 使用手册", "MA Studio Manual").text)
                .font(.system(size: 22, weight: .semibold, design: .rounded))
            Text(LText("这份手册按「你会遇到的问题」组织：图怎么看、数字什么意思、什么时候该用哪种检验。每一节都配一张示意图。",
                       "This manual is organised around the questions you will actually ask: how to read a chart, what a number means, and which test to use. Every section comes with a diagram.").text)
                .font(.system(size: 12))
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
    }

    // MARK: 第 1 章：流程

    private var chapter1: some View {
        section(index: "1",
                title: LText("从文本到结论：三步", "From text to conclusion: three steps")) {
            Text(LText("导入语料 → 读图 → 导出。中间所有数字都由 MATCore 计算，界面只负责呈现，所以 CSV 里的值和屏幕上永远一致。",
                       "Import a corpus, read the charts, export. Every number comes from MATCore; the interface only presents it, so the CSV and the screen always agree.").text)
                .font(.system(size: 12)).foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)

            FigureFlow()
                .frame(height: 92)

            bullets([
                LText("导入：单个 .txt、多个 .txt，或一个只放 .txt 的文件夹。一个文件夹 = 一个语料库，里面每篇 .txt = 一个样本。",
                      "Import: one .txt, several .txt files, or a folder containing only .txt. One folder is one corpus; each .txt is one sample."),
                LText("算：标词性 → 统计 67 个语言特征 → 换成 z 分数 → 合成 6 个维度分 → 判文本类型。",
                      "Analysis: tag parts of speech → count 67 features → convert to z-scores → combine into six dimensions → identify the text type."),
                LText("别急着看维度：先看分布页的样本量。少于 4 篇时，任何两组检验都不该做。",
                      "Before reading dimensions, check the sample size on the Distribution tab. With fewer than 4 documents, skip two-group tests entirely."),
            ])
        }
    }

    // MARK: 第 2 章：维度图

    private var chapter2: some View {
        section(index: "2", title: LText("维度图怎么读", "How to read the dimension chart")) {
            Text(LText("每个维度都拿你的语料和 8 个参考体裁比。灰色是参考体裁（各自有颜色），彩色是你。",
                       "Each dimension compares your corpus with eight reference genres. Grey bars are the references (one colour each), colour is you.").text)
                .font(.system(size: 12)).foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)

            FigureDimensionChart()
                .frame(height: 210)
                .padding(.vertical, 4)

            bullets([
                LText("棒的范围 = 该体裁的得分区间（最低到最高），棒上的点是均值。棒越长，说明这个体裁内部差异越大。",
                      "The bar spans a genre's score range (min to max) and the dot is its mean. A longer bar means more internal variation in that genre."),
                LText("你的彩色棒和哪根灰棒靠得最近，就说明在语言特征上最像哪个体裁。右下角的参考表把距离算给你了。",
                      "Whichever grey bar sits closest to your coloured bar is the genre you most resemble. The reference table below the chart gives the exact distance."),
                LText("维度是标准分，0 = Biber 语料库的平均水平。+10 不是「十分」，而是「高出 10 个标准差单位」。",
                      "Dimension scores are standardised: 0 is the average of Biber's corpus. +10 does not mean 'ten points', it means ten standardised units above the mean."),
            ])
        }
    }

    // MARK: 第 3 章：六维与文本类型

    private var chapter3: some View {
        section(index: "3", title: LText("六维概览与文本类型", "Six dimensions and text type")) {
            Text(LText("六个维度是同一批特征的六种组合方式：有的特征往上推，有的往下拉。文本类型则是拿五个维度去和八种原型比距离。",
                       "The six dimensions are six ways of combining the same features — some push a dimension up, others pull it down. Text type then compares five dimensions against eight prototypes.").text)
                .font(.system(size: 12)).foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)

            FigureSixDim()
                .frame(height: 150)
                .padding(.vertical, 4)

            bullets([
                LText("D1 互动性：口语、私动词、缩写越多，分越高。D5 抽象性：被动、名词化越多，分越高。",
                      "D1 involvement rises with private verbs, contractions and spoken features; D5 abstraction rises with passives and nominalisations."),
                LText("文本类型只看 D1–D5（原版就是这么实现的），D6 不参与判定。",
                      "Text type uses D1–D5 only — that is how the original implements it. D6 never affects the verdict."),
                LText("「原版方式」是每个维度一列散点，每类一个带名字的点；「维度轮廓」把语料和每一篇连成折线，看得到组内离散。",
                      "'Classic' plots one column per dimension with a labelled dot per type; 'Profile' joins corpus and documents into lines so you can see within-group spread."),
            ])
        }
    }

    // MARK: 第 4 章：特征与 z

    private var chapter4: some View {
        section(index: "4", title: LText("特征与 z 分数", "Features and z-scores")) {
            Text(LText("特征是数出来的：某个词性/结构出现了多少次，换算成「每百词」再和 Biber 的基准比，得到 z 分数。",
                       "Features are counted: how often a tag or construction occurs, converted to a per-100-word rate, then compared with Biber's reference to give a z-score.").text)
                .font(.system(size: 12)).foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)

            FigureZScale()
                .frame(height: 96)
                .padding(.vertical, 6)

            bullets([
                LText("z = 0 与基准持平；|z| > 2 才算明显偏高/偏低。列表默认按 |z| 排序，最上面的就是最能区分你语料的特征。",
                      "z = 0 matches the reference; |z| > 2 counts as clearly high or low. The table sorts by |z|, so the top rows are what set your corpus apart."),
                LText("AWL（平均词长）和 TTR（类符/形符比）不是每百词频次，表里标了「指标」。",
                      "AWL (average word length) and TTR (type/token ratio) are not per-100-word rates; they are tagged 'index' in the table."),
                LText("个别特征会出现 z = 8100 这种数字：它的基准标准差是 0.00001，原版 MAT 同样会给出这个值，不是算错。",
                      "A few features show absurd z values (e.g. 8100) because their reference SD is 0.00001. The original MAT produces the same number; it is not a bug."),
            ])
        }
    }

    // MARK: 第 5 章：分布与检验

    private var chapter5: some View {
        section(index: "5", title: LText("分布页：该用 t 还是 U", "Distribution: t or U?")) {
            Text(LText("两组比较之前先看形状。分布接近正态用 Welch t，明显偏斜用 Mann–Whitney U——后者只看名次，不受极端值影响。",
                       "Look at the shape before comparing groups. Roughly normal → Welch's t. Clearly skewed → Mann–Whitney U, which uses ranks and ignores extreme values.").text)
                .font(.system(size: 12)).foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)

            FigureDistribution()
                .frame(height: 170)
                .padding(.vertical, 4)

            bullets([
                LText("直方图看形状，核密度是它的平滑版，虚线是「如果完全正态应该长这样」。",
                      "The histogram shows the shape, the density curve smooths it, and the dashed line is what a perfectly normal sample would look like."),
                LText("Shapiro–Wilk 给一个 p：≥ 0.05 没有证据说它不正态；< 0.05 明显偏离。",
                      "Shapiro–Wilk returns a p: ≥ 0.05 means no evidence against normality; < 0.05 means it clearly departs."),
                LText("样本少于 4 篇时不做检验——页面会直接告诉你「样本太少」，而不是硬给一个 p。",
                      "With fewer than 4 documents the app refuses to test and says so, instead of inventing a p-value."),
            ])
        }
    }

    // MARK: 第 6 章：对比

    private var chapter6: some View {
        section(index: "6", title: LText("对比两个语料库", "Comparing two corpora")) {
            Text(LText("对比页回答「两组有没有差别」；Z 对比页回答「哪些具体变量在变」。两页都会同时给 t 和 U，并把结论不一致的情况标出来——这本身就是信息。",
                       "The Compare tab answers 'do the groups differ'; Z-compare answers 'which variables move'. Both run t and U side by side and flag disagreement, which is itself informative.").text)
                .font(.system(size: 12)).foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)

            FigureCompare()
                .frame(height: 150)
                .padding(.vertical, 4)

            bullets([
                LText("效应量（Cohen's d、秩相关 r）告诉你「差多少」；95% 置信区间告诉你「这个估计有多稳」。",
                      "Effect size (Cohen's d, rank correlation r) says how large the gap is; the 95% confidence interval says how precise that estimate is."),
                LText("一次测 65 个变量会凭空冒出几个「显著」。Z 对比页默认开 BH-FDR，也可以切 Holm 或关闭。",
                      "Testing 65 variables produces a few chance 'hits'. Z-compare defaults to BH-FDR, with Holm or no correction available."),
                LText("「仅 t 显著」「仅 U 显著」通常意味着分布偏斜或方差不齐——这比一个自动选择的结论更值得报告。",
                      "'t only' or 'U only' usually means skew or unequal variance — worth reporting rather than hiding behind an automatic choice."),
            ])
        }
    }

    // MARK: 术语表

    private var glossary: some View {
        section(index: "7", title: LText("数字速查", "What the numbers mean")) {
            VStack(spacing: 0) {
                ForEach(Array(glossaryRows.enumerated()), id: \.offset) { i, row in
                    HStack(alignment: .top, spacing: 12) {
                        Text(row.0.text)
                            .font(.system(size: 11.5, weight: .semibold))
                            .frame(width: 150, alignment: .leading)
                        Text(row.1.text)
                            .font(.system(size: 11.5))
                            .foregroundStyle(.secondary)
                            .fixedSize(horizontal: false, vertical: true)
                        Spacer(minLength: 0)
                    }
                    .padding(.vertical, 7)
                    .padding(.horizontal, 10)
                    .background(i % 2 == 1 ? Color.primary.opacity(0.03) : Color.clear)
                }
            }
            .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
        }
    }

    private var glossaryRows: [(LText, LText)] {
        [
            (LText("维度分（D1–D6）", "Dimension score (D1–D6)"),
             LText("标准分：0 = Biber 语料库平均，+10 ≈ 高出 10 个标准差单位。", "Standardised: 0 = Biber's average, +10 ≈ ten standardised units above it.")),
            (LText("z 分数", "z-score"),
             LText("单个特征相对基准的高低，|z| > 2 算明显。", "How far one feature sits from its reference; |z| > 2 is clearly off.")),
            (LText("每百词", "Per 100 words"),
             LText("把频次按文本长度归一化，长短文本才能比。", "Frequency normalised by text length, so long and short texts compare.")),
            (LText("AWL / TTR", "AWL / TTR"),
             LText("平均词长 / 类符形符比；TTR 受文本长度影响，短文本会虚高。", "Average word length / type-token ratio; TTR is length-sensitive and inflates in short texts.")),
            (LText("标准误（SEM）", "Standard error (SEM)"),
             LText("均值的抖动幅度 = 标准差 ÷ √篇数，比标准差小得多。", "How much the mean itself wobbles = SD ÷ √n; much smaller than the SD.")),
            (LText("p 值", "p value"),
             LText("「如果两组没差别，看到这么大差距的概率」。不是「差别为真的概率」。", "The chance of seeing a gap this large if the groups did not differ — not the chance the difference is real.")),
            (LText("q 值 / BH-FDR", "q value / BH-FDR"),
             LText("多重比较校正后的 p；65 个检验要有约 5% 的假阳性才叫 q < 0.05。", "A p corrected for multiple tests; q < 0.05 allows about 5% false discoveries among 65 tests.")),
            (LText("Holm", "Holm"),
             LText("更保守的校正：控制「至少出现一次假阳性」的概率。", "A more conservative correction: controls the chance of any false positive at all.")),
            (LText("Cohen's d / r", "Cohen's d / r"),
             LText("效应量：0.2 小、0.5 中、0.8 大（r 用 0.1 / 0.3 / 0.5）。", "Effect size: 0.2 small, 0.5 medium, 0.8 large (for r: 0.1 / 0.3 / 0.5).")),
            (LText("Shapiro–Wilk", "Shapiro–Wilk"),
             LText("正态性检验；p ≥ 0.05 表示没有证据说它不正态。", "A normality test; p ≥ 0.05 means no evidence against normality.")),
            (LText("核密度（KDE）", "Kernel density (KDE)"),
             LText("把直方图磨平后的曲线，样本少时会溢出数据范围（正常现象）。", "A smoothed histogram; with few samples it spills past the data range, which is normal.")),
        ]
    }

    // MARK: 版式

    private func section<Content: View>(index: String, title: LText,
                                        @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 8) {
                Text(index)
                    .font(.system(size: 10, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)
                    .frame(width: 18, height: 18)
                    .background { Circle().fill(Theme.accent) }
                Text(title.text)
                    .font(.system(size: 15, weight: .semibold, design: .rounded))
                Spacer()
            }
            content()
        }
    }

    private func bullets(_ items: [LText]) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            ForEach(Array(items.enumerated()), id: \.offset) { _, item in
                HStack(alignment: .top, spacing: 7) {
                    Circle().fill(Theme.accent.opacity(0.6))
                        .frame(width: 4, height: 4)
                        .padding(.top, 6)
                    Text(item.text)
                        .font(.system(size: 11.5))
                        .foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
            }
        }
    }
}

// MARK: - 示意图
//
// 全部现场绘制：换语言、换深浅色都不会糊，也不用打包图片。

private struct FigureFlow: View {
    @MainActor
    var body: some View {
        HStack(spacing: 10) {
            box("tray.and.arrow.down", LText("导入 .txt", "Import .txt"), "1")
            arrow
            box("gearshape.2", LText("标注 + 统计", "Tag + count"), "2")
            arrow
            box("chart.bar.xaxis", LText("读图 / 导出", "Read / export"), "3")
        }
        .frame(maxWidth: .infinity)
    }

    @MainActor
    private func box(_ icon: String, _ text: LText, _ n: String) -> some View {
        VStack(spacing: 6) {
            Image(systemName: icon).font(.system(size: 18, weight: .light)).foregroundStyle(Theme.accent)
            Text(text.text).font(.system(size: 11, weight: .medium))
        }
        .frame(maxWidth: .infinity, minHeight: 74)
        .background {
            RoundedRectangle(cornerRadius: 10, style: .continuous)
                .fill(Theme.accent.opacity(0.07))
                .overlay {
                    RoundedRectangle(cornerRadius: 10, style: .continuous)
                        .strokeBorder(Theme.accent.opacity(0.25), lineWidth: 1)
                }
        }
    }

    private var arrow: some View {
        Image(systemName: "arrow.right").font(.system(size: 11, weight: .semibold)).foregroundStyle(.tertiary)
    }
}

private struct FigureDimensionChart: View {
    private struct Row {
        let name: String
        let low: Double
        let high: Double
        let mean: Double
    }
    private let rows: [Row] = [
        .init(name: "Conv.", low: 17.7, high: 54.1, mean: 35.3),
        .init(name: "Speech", low: -7.3, high: 14.8, mean: 2.2),
        .init(name: "Academic", low: -26.5, high: 7.1, mean: -14.9),
    ]

    var body: some View {
        Chart {
            ForEach(Array(rows.enumerated()), id: \.offset) { i, r in
                BarMark(x: .value("g", r.name), yStart: .value("lo", r.low), yEnd: .value("hi", r.high),
                        width: .fixed(7))
                    .foregroundStyle(GenrePalette.color(index: i * 2).opacity(0.75))
                    .cornerRadius(3)
                PointMark(x: .value("g", r.name), y: .value("m", r.mean))
                    .symbolSize(34)
                    .foregroundStyle(GenrePalette.color(index: i * 2))
            }
            // 你的语料
            BarMark(x: .value("g", "Yours"), yStart: .value("lo", -18), yEnd: .value("hi", 60), width: .fixed(12))
                .foregroundStyle(SeriesColors.a.opacity(0.85))
                .cornerRadius(3)
            PointMark(x: .value("g", "Yours"), y: .value("m", 10.5))
                .symbolSize(60).foregroundStyle(SeriesColors.a)
        }
        .chartYScale(domain: -32...66)
        .chartXAxis {
            AxisMarks { v in
                AxisValueLabel {
                    if let s = v.as(String.self) { Text(s).font(.system(size: 10)) }
                }
            }
        }
        .chartYAxis {
            AxisMarks(position: .leading, values: [0, 20, 40]) { v in
                AxisGridLine().foregroundStyle(Color.primary.opacity(0.06))
                AxisValueLabel {
                    if let d = v.as(Double.self) {
                        Text("\(Int(d))").font(.system(size: 9)).foregroundStyle(.tertiary)
                    }
                }
            }
        }
    }
}

private struct FigureSixDim: View {
    @MainActor
    var body: some View {
        let dims = Dims.all
        let values: [Double] = [10.5, 3.8, -1.4, 5.1, 2.7, 0.9]
        Chart {
            ForEach(Array(dims.enumerated()), id: \.element.id) { i, m in
                BarMark(xStart: .value("z", 0), xEnd: .value("v", values[i]),
                        y: .value("row", Double(dims.count - 1 - i)), height: .fixed(9))
                    .foregroundStyle(m.color)
                    .cornerRadius(4)
            }
            RuleMark(x: .value("zero", 0)).foregroundStyle(Color.primary.opacity(0.2))
        }
        .chartXScale(domain: -3...12)
        .chartYAxis {
            AxisMarks(position: .leading, values: (0..<dims.count).map { Double($0) }) { v in
                AxisValueLabel {
                    if let d = v.as(Double.self) {
                        let idx = dims.count - 1 - Int(d.rounded())
                        if idx >= 0, idx < dims.count {
                            Text(dims[idx].label).font(.system(size: 9, weight: .semibold)).foregroundStyle(dims[idx].color)
                        }
                    }
                }
                AxisTick().foregroundStyle(.clear)
            }
        }
        .chartXAxis {
            AxisMarks(values: [0, 5, 10]) { v in
                AxisGridLine().foregroundStyle(Color.primary.opacity(0.06))
                AxisValueLabel {
                    if let d = v.as(Double.self) { Text("\(Int(d))").font(.system(size: 9)).foregroundStyle(.tertiary) }
                }
            }
        }
    }
}

private struct FigureZScale: View {
    @MainActor
    var body: some View {
        VStack(spacing: 10) {
            GeometryReader { geo in
                let w = geo.size.width
                ZStack(alignment: .leading) {
                    Capsule().fill(Color.primary.opacity(0.07)).frame(height: 8)
                    // -3…+3 的刻度
                    ForEach([-3.0, -2, 0, 2, 3], id: \.self) { t in
                        Rectangle().fill(Color.primary.opacity(0.18))
                            .frame(width: 1, height: 12)
                            .offset(x: w * (t + 3) / 6)
                    }
                    Circle().fill(Dims.color(4))
                        .frame(width: 14, height: 14)
                        .offset(x: w * (3.4 + 3) / 6 - 7)
                        .shadow(color: Dims.color(4).opacity(0.4), radius: 5)
                }
            }
            .frame(height: 16)

            HStack {
                Text(LText("−3 明显偏低", "−3 clearly low").text)
                Spacer()
                Text(LText("0 与基准持平", "0 = reference").text)
                Spacer()
                Text(LText("+3 明显偏高", "+3 clearly high").text)
            }
            .font(.system(size: 9))
            .foregroundStyle(.tertiary)
        }
        .padding(.horizontal, 6)
    }
}

private struct FigureDistribution: View {
    private struct Bin: Identifiable { let id = UUID(); let x: Double; let h: Double }
    private let bins: [Bin] = [
        .init(x: 3, h: 2), .init(x: 5, h: 5), .init(x: 7, h: 8),
        .init(x: 9, h: 6), .init(x: 11, h: 3), .init(x: 13, h: 1),
    ]

    var body: some View {
        Chart {
            ForEach(bins) { b in
                BarMark(x: .value("x", b.x), y: .value("h", b.h), width: .fixed(16))
                    .foregroundStyle(Dims.color(5).opacity(0.45))
                    .cornerRadius(2)
            }
            ForEach(Array(stride(from: 1.0, through: 15.0, by: 0.5)), id: \.self) { x in
                LineMark(x: .value("x", x), y: .value("n", normal(x, mu: 7.5, sd: 2.6) * 26),
                         series: .value("s", "normal"))
                    .foregroundStyle(Color.primary.opacity(0.45))
                    .lineStyle(StrokeStyle(lineWidth: 1.3, dash: [4, 3]))
            }
        }
        .chartXAxis {
            AxisMarks(values: [3, 7, 11, 15]) { v in
                AxisValueLabel {
                    if let d = v.as(Double.self) { Text("\(Int(d))").font(.system(size: 9)).foregroundStyle(.tertiary) }
                }
            }
        }
        .chartYAxis(.hidden)
    }

    private func normal(_ x: Double, mu: Double, sd: Double) -> Double {
        exp(-0.5 * pow((x - mu) / sd, 2)) / (sd * (2 * Double.pi).squareRoot())
    }
}

private struct FigureCompare: View {
    @MainActor
    var body: some View {
        HStack(spacing: 16) {
            Chart {
                BarMark(x: .value("g", "A"), y: .value("v", 5.7), width: .fixed(26))
                    .foregroundStyle(SeriesColors.a).cornerRadius(5)
                    .annotation(position: .top) { Text("5.70").font(.system(size: 9)).foregroundStyle(SeriesColors.a) }
                BarMark(x: .value("g", "B"), y: .value("v", 8.98), width: .fixed(26))
                    .foregroundStyle(SeriesColors.b).cornerRadius(5)
                    .annotation(position: .top) { Text("8.98").font(.system(size: 9)).foregroundStyle(SeriesColors.b) }
            }
            .chartYScale(domain: 0...11)
            .chartXAxis {
                AxisMarks { v in
                    AxisValueLabel {
                        if let s = v.as(String.self) { Text(s).font(.system(size: 10)) }
                    }
                }
            }
            .chartYAxis(.hidden)
            .frame(width: 150)

            VStack(alignment: .leading, spacing: 8) {
                Text(LText("Welch t · p = 0.005", "Welch t · p = 0.005").text)
                    .font(.system(size: 11, weight: .semibold, design: .rounded))
                    .foregroundStyle(Dims.color(5))
                Text(LText("Mann–Whitney U · p = 0.023", "Mann–Whitney U · p = 0.023").text)
                    .font(.system(size: 11, weight: .semibold, design: .rounded))
                    .foregroundStyle(Dims.color(2))
                Text(LText("差值 A − B = −3.28，d = 1.28", "Difference A − B = −3.28, d = 1.28").text)
                    .font(.system(size: 10))
                    .foregroundStyle(.secondary)
                Text(LText("两种检验都显著 → 结论可靠", "Both tests agree → the result is robust").text)
                    .font(.system(size: 10))
                    .foregroundStyle(.tertiary)
            }
            Spacer(minLength: 0)
        }
        .padding(10)
        .background {
            RoundedRectangle(cornerRadius: 10, style: .continuous).fill(Color.primary.opacity(0.03))
        }
    }
}
