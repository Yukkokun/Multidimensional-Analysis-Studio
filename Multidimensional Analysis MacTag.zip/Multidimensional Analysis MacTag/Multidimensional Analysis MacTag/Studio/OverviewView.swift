import SwiftUI
import Charts
import MATCore

// MARK: - 概览

@MainActor
struct OverviewView: View {
    @Environment(Workspace.self) private var ws
    var corpus: Corpus

    private var doc: DocumentResult? {
        guard let n = ws.selectedDocument else { return nil }
        return corpus.documents.first { $0.name == n }
    }
    private var dims: [Int: Double] { doc?.dims ?? corpus.dims }
    private var textType: String { doc?.textType ?? corpus.textType }

    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            statRow
            HStack(alignment: .top, spacing: 18) {
                typeCard
                nearestGenres
            }
            dimensionGrid
            if let doc { documentDetail(doc) }
        }
    }

    // MARK: 顶部四个数字

    private var statRow: some View {
        HStack(spacing: 12) {
            StatTile(label: T("词数"), value: Double(doc?.tokens ?? corpus.tokens),
                     decimals: 0, tint: Theme.accent, icon: "textformat.abc")
            StatTile(label: T("篇数"), value: Double(corpus.documents.count),
                     decimals: 0, tint: Dims.color(2), icon: "doc.on.doc")
            StatTile(label: T("平均词长"), value: doc?.awl ?? (corpus.result.corpusAWL ?? 0),
                     tint: Dims.color(5), icon: "ruler")
            StatTile(label: T(doc == nil ? "类符数（均值）" : "类符数"),
                     value: Double(doc?.types ?? Int(corpus.result.corpusTypes ?? 0)),
                     decimals: 0, tint: Dims.color(3), icon: "textformat.size")
        }
    }

    // MARK: 文本类型

    private var typeCard: some View {
        let ranking = TextTypeRanking.rank(dims: dims)
        let best = ranking.first

        return VStack(alignment: .leading, spacing: 14) {
            SectionHeader(T("文本类型"), subtitle: T("Biber 1989 · D1–D5 欧氏距离最近"))

            HStack(alignment: .firstTextBaseline, spacing: 8) {
                Text(TextTypes.name(textType))
                    .font(.system(size: 22, weight: .semibold, design: .rounded))
                    .foregroundStyle(LinearGradient(colors: [Dims.color(5), Dims.color(4)],
                                                    startPoint: .leading, endPoint: .trailing))
                Spacer()
                if let best {
                    VStack(alignment: .trailing, spacing: 1) {
                        Text(String(format: "%.2f", best.distance)).monoNumber(18)
                        Text(T("距离")).font(.system(size: 9.5)).foregroundStyle(.tertiary)
                    }
                }
            }

            VStack(spacing: 7) {
                ForEach(ranking.prefix(4)) { r in
                    HStack(spacing: 8) {
                        Text(TextTypes.name(r.name))
                            .font(.system(size: 11))
                            .lineLimit(1)
                            .frame(width: 168, alignment: .leading)
                            .foregroundStyle(r.name == textType ? .primary : .secondary)
                            .help(r.name)
                            .help(r.name)
                        GeometryReader { geo in
                            let maxD = ranking.last?.distance ?? 1
                            Capsule()
                                .fill(Color.primary.opacity(0.07))
                                .overlay(alignment: .leading) {
                                    Capsule()
                                        .fill(LinearGradient(colors: [Dims.color(5).opacity(0.7), Dims.color(4)],
                                                             startPoint: .leading, endPoint: .trailing))
                                        .frame(width: max(3, geo.size.width * (1 - r.distance / max(maxD, 1))))
                                }
                        }
                        .frame(height: 5)
                        Text(String(format: "%.1f", r.distance))
                            .font(.system(size: 10, design: .rounded).monospacedDigit())
                            .foregroundStyle(.tertiary)
                            .frame(width: 40, alignment: .trailing)
                    }
                }
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .glassCard()
    }

    // MARK: 最近体裁（按 D1..D6 逐个）

    private var nearestGenres: some View {
        let catalog = Catalog.shared
        return VStack(alignment: .leading, spacing: 12) {
            SectionHeader(T("逐维度最近体裁"), subtitle: T("各维度距离最近的参考体裁"))
            VStack(spacing: 6) {
                ForEach(1...6, id: \.self) { d in
                    let g = nearestGenre(d, catalog: catalog)
                    HStack(spacing: 8) {
                        Badge(text: "D\(d)", tint: Dims.color(d))
                        Text(g.map { GenreRow.shortName($0.name) } ?? "—")
                            .font(.system(size: 11))
                            .lineLimit(1)
                        Spacer()
                        Text(String(format: "%.1f", dims[d] ?? 0))
                            .font(.system(size: 10.5, weight: .medium, design: .rounded).monospacedDigit())
                            .foregroundStyle(Dims.color(d))
                    }
                }
            }
        }
        .frame(width: 290)
        .glassCard()
    }

    private func nearestGenre(_ d: Int, catalog: Catalog) -> GenreRef? {
        let v = dims[d] ?? 0
        return catalog.genres.min { a, b in
            abs((a.values[safe: d - 1] ?? 0) - v) < abs((b.values[safe: d - 1] ?? 0) - v)
        }
    }

    // MARK: 六维

    private var dimensionGrid: some View {
        VStack(alignment: .leading, spacing: 10) {
            SectionHeader(T("六个维度"), subtitle: T("点任一张卡片看细节"))
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 240), spacing: 12)], spacing: 12) {
                ForEach(Dims.all) { m in
                    DimCard(meta: m, value: dims[m.id] ?? 0,
                            allValues: Dims.all.map { dims[$0.id] ?? 0 }) {
                        withAnimation(Motion.snappy) {
                            ws.selectedDim = m.id
                            ws.tab = .dimensions
                        }
                    }
                }
            }
        }
    }

    // MARK: 单篇明细

    private func documentDetail(_ doc: DocumentResult) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            SectionHeader(T("这篇文档"), subtitle: doc.name)
            HStack(spacing: 12) {
                StatTile(label: "Tokens", value: Double(doc.tokens), decimals: 0, tint: .secondary)
                StatTile(label: "AWL", value: doc.awl, tint: Dims.color(5))
                StatTile(label: "TTR", value: Double(doc.types), decimals: 0, tint: Dims.color(3))
            }
        }
    }
}

// MARK: 维度卡片

@MainActor
struct DimCard: View {
    var meta: DimMeta
    var value: Double
    var allValues: [Double]
    var onTap: () -> Void
    @State private var hover = false

    private var maxAbs: Double { max(10, allValues.map { abs($0) }.max() ?? 10) }

    var body: some View {
        Button(action: onTap) {
            VStack(alignment: .leading, spacing: 9) {
                HStack {
                    Text(meta.label)
                        .font(.system(size: 10, weight: .bold, design: .rounded))
                        .padding(.horizontal, 6).padding(.vertical, 2.5)
                        .background { Capsule().fill(meta.color.opacity(0.18)) }
                        .foregroundStyle(meta.color)
                    Text(meta.title)
                        .font(.system(size: 11.5, weight: .medium))
                        .foregroundStyle(.secondary)
                        .lineLimit(2)
                        .fixedSize(horizontal: false, vertical: true)
                    Spacer()
                }
                BigNumber(value: value, decimals: 2, color: meta.color, size: 27)
                DivergingBar(value: value, maxAbs: maxAbs, color: meta.color, height: 5)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .glassCard(padding: 14)
            .overlay {
                RoundedRectangle(cornerRadius: Theme.radius, style: .continuous)
                    .strokeBorder(meta.color.opacity(hover ? 0.45 : 0), lineWidth: 1)
            }
            .shadow(color: meta.color.opacity(hover ? 0.18 : 0), radius: 14, y: 4)
        }
        .buttonStyle(.plain)
        .onHover { hover = $0 }
        .animation(Motion.quick, value: hover)
    }
}

// MARK: - 文本类型距离

struct TextTypeRanking: Identifiable {
    var id: String { name }
    var name: String
    var distance: Double

    static func rank(dims: [Int: Double]) -> [TextTypeRanking] {
        Catalog.shared.textTypes.map { t in
            var acc = 0.0
            for i in 0..<5 {
                let d = (dims[i + 1] ?? 0) - t.values[i]
                acc += d * d
            }
            return TextTypeRanking(name: t.name, distance: acc.squareRoot())
        }
        .sorted { $0.distance < $1.distance }
    }
}

extension Array {
    subscript(safe i: Int) -> Element? { indices.contains(i) ? self[i] : nil }
}
