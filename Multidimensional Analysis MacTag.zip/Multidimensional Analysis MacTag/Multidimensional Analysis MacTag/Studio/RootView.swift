import SwiftUI
import UniformTypeIdentifiers
import MATCore

// MARK: - 根视图

@MainActor
struct RootView: View {
    @Environment(Workspace.self) private var ws
    @Environment(\.colorScheme) private var scheme
    @State private var dropping = false

    var body: some View {
        @Bindable var ws = ws

        NavigationSplitView {
            SidebarView()
                .navigationSplitViewColumnWidth(min: 238, ideal: 272, max: 330)
                // 注意：同一个视图只能挂一个 .sheet，Help 的窗口放在侧栏才不会被引擎面板顶掉
                .sheet(item: Bindable(ws).helpSheet) { sheet in
                    HelpSheetView(sheet: sheet)
                }
        } detail: {
            ZStack {
                Theme.canvas(scheme)

                if let corpus = ws.current {
                    DetailView(corpus: corpus)
                        .transition(.opacity)
                } else {
                    VStack(spacing: 14) {
                        EmptyHint(icon: "text.viewfinder",
                                  title: T("把语料拖进来"),
                                  message: T("支持单个 .txt、多个 .txt，或一个只放 .txt 的文件夹。\n只读取纯文本，其它格式会被忽略。"),
                                  actionTitle: T("选择文件…")) { ImportPanel.open { ws.importItems($0) } }
                        Button(T("先看示例语料（10 篇，1,684 词）")) { ws.loadDemo() }
                            .buttonStyle(.link)
                            .font(.system(size: 11.5))
                    }
                }

                if dropping {
                    DropOverlay()
                }
            }
            .overlay(alignment: .bottom) {
                if let p = ws.progress {
                    RunProgressBar(progress: p)
                        .padding(18)
                        .frame(maxWidth: 460)
                        .transition(.move(edge: .bottom).combined(with: .opacity))
                }
            }
            .animation(Motion.snappy, value: ws.progress)
            .animation(Motion.soft, value: ws.current?.id)
        }
        // 全局唯一的术语浮窗：用 overlay（不参与布局，不会破坏 NavigationSplitView 的尺寸）
        .overlay {
            if let item = HelpCenter.shared.item {
                HelpTooltipLayer(item: item)
                    .allowsHitTesting(false)
                    .transition(.opacity)
            }
        }
        .coordinateSpace(name: HelpSpace.name)
        // 语言切换时整棵树重建，确保所有 T() 重新求值
        .id(Localizer.shared.revision)
        .toolbar { toolbar }
        .dropDestination(for: URL.self) { urls, _ in
            ws.importItems(urls)
            return true
        } isTargeted: { dropping = $0 }
        .alert(item: $ws.banner) { banner in
            Alert(title: Text(T(banner.title)), message: Text(T(banner.message)), dismissButton: .default(Text(T("好"))))
        }
        .sheet(isPresented: $ws.showEngineSheet) {
            EngineSheet()
        }

    }

    @ToolbarContentBuilder
    private var toolbar: some ToolbarContent {
        @Bindable var ws = ws

        ToolbarItemGroup(placement: .navigation) {
            Button {
                ImportPanel.open { ws.importItems($0) }
            } label: {
                Label(T("导入"), systemImage: "square.and.arrow.down")
            }
            .help(T("导入 .txt 或文件夹（⌘O）"))
            .keyboardShortcut("o")

            Button {
                if let c = ws.current, let folder = c.folder {
                    ws.run(files: Workspace.expand([folder]), name: c.name)
                } else {
                    ImportPanel.open { ws.importItems($0) }
                }
            } label: {
                Label(T("重跑"), systemImage: "arrow.clockwise")
            }
            .disabled(ws.isRunning)
            .help(T("用当前设置重新分析（⌘R）"))
            .keyboardShortcut("r")
        }

        ToolbarItemGroup(placement: .primaryAction) {
            Menu {
                Toggle(T("Zscore correction（z 截断 ±5）"), isOn: $ws.settings.clamp)
                Toggle(T("Count: 全部词性（All tags）"), isOn: $ws.settings.allTags)
                Divider()
                Picker(T("TTR 窗口"), selection: $ws.settings.ttrWindow) {
                    Text(T("400（默认）")).tag(400)
                    Text("200").tag(200)
                    Text("100").tag(100)
                }
            } label: {
                Label(T("设置"), systemImage: "slider.horizontal.3")
            }
            .help(T("分析设置"))

            Menu {
                Section(T("维度图（6 张）")) {
                    Button(T("原版风格…")) { ExportService.exportDimensions(ws, style: .legacy) }
                    Button(T("横向柱状图…")) { ExportService.exportDimensions(ws, style: .horizontal) }
                }
                Divider()
                Button(T("文本类型大图…")) { ExportService.exportTextType(ws) }
                Button(T("三个 CSV…")) { ExportService.exportCSV(ws.current) }
                Divider()
                Button(T("在 Finder 中显示语料…")) {
                    if let f = ws.current?.folder { NSWorkspace.shared.activateFileViewerSelecting([f]) }
                }
            } label: {
                Label(T("导出"), systemImage: "square.and.arrow.up")
            }
        }
    }
}

// MARK: - 拖放遮罩

@MainActor
struct DropOverlay: View {
    var body: some View {
        ZStack {
            Rectangle().fill(.ultraThinMaterial).ignoresSafeArea()
            VStack(spacing: 14) {
                Image(systemName: "arrow.down.doc.fill")
                    .font(.system(size: 44, weight: .light))
                    .foregroundStyle(Theme.accent)
                Text(T("松手就开始分析"))
                    .font(.system(size: 17, weight: .semibold, design: .rounded))
                Text(T("文件夹会自动取里面的 .txt"))
                    .font(.system(size: 12))
                    .foregroundStyle(.secondary)
            }
            .padding(38)
            .background {
                RoundedRectangle(cornerRadius: 24, style: .continuous)
                    .fill(.thinMaterial)
                    .overlay {
                        RoundedRectangle(cornerRadius: 24, style: .continuous)
                            .strokeBorder(Theme.accent.opacity(0.6), style: StrokeStyle(lineWidth: 1.5, dash: [7, 5]))
                    }
            }
        }
    }
}

// MARK: - 侧边栏

@MainActor
struct SidebarView: View {
    @Environment(Workspace.self) private var ws

    var body: some View {
        @Bindable var ws = ws
        VStack(spacing: 0) {
            header
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 10) {
                    HStack {
                        Text(T("语料库"))
                            .font(.system(size: 10.5, weight: .semibold))
                            .textCase(.uppercase)
                            .kerning(0.8)
                            .foregroundStyle(.tertiary)
                        Spacer()
                        Text("\(ws.corpora.count)")
                            .font(.system(size: 10.5, weight: .medium).monospacedDigit())
                            .foregroundStyle(.tertiary)
                    }
                    .padding(.horizontal, 6)

                    ForEach(ws.corpora) { corpus in
                        CorpusRow(corpus: corpus, isSelected: ws.current?.id == corpus.id)
                            .onTapGesture {
                                withAnimation(Motion.snappy) {
                                    ws.selection = corpus.id
                                    ws.selectedDocument = nil
                                }
                            }
                            .contextMenu {
                                Button(T("用当前设置重跑")) {
                                    if let f = corpus.folder {
                                        ws.run(files: Workspace.expand([f]), name: corpus.name)
                                    }
                                }
                                Button(T("移除"), role: .destructive) { ws.remove(corpus) }
                            }
                    }

                    if ws.corpora.isEmpty {
                        Text(T("还没有语料。\n点下面的按钮，或者把文件拖进右边的区域。"))
                            .font(.system(size: 11.5))
                            .foregroundStyle(.tertiary)
                            .padding(.horizontal, 8)
                            .padding(.top, 6)
                            .lineSpacing(3)
                    }
                }
                .padding(12)
            }
            footer
        }
        .background(.ultraThinMaterial)
    }

    private var header: some View {
        HStack(spacing: 10) {
            ZStack {
                RoundedRectangle(cornerRadius: 9, style: .continuous)
                    .fill(LinearGradient(colors: [Dims.color(1), Dims.color(4)],
                                         startPoint: .topLeading, endPoint: .bottomTrailing))
                    .frame(width: 30, height: 30)
                Image(systemName: "text.alignleft")
                    .font(.system(size: 14, weight: .bold))
                    .foregroundStyle(.white)
            }
            VStack(alignment: .leading, spacing: 1) {
                Text("MA Studio")
                    .font(.system(size: 14, weight: .semibold, design: .rounded))
                Text(T("多维度分析工作室"))
                    .font(.system(size: 9.5))
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
                    .minimumScaleFactor(0.75)
            }
            Spacer()
        }
        .padding(.horizontal, 14)
        .padding(.top, 30)          // 让开窗口红绿灯
        .padding(.bottom, 10)
    }

    private var footer: some View {
        VStack(spacing: 8) {
            Divider().opacity(0.5)
            Button {
                ImportPanel.open { ws.importItems($0) }
            } label: {
                HStack(spacing: 7) {
                    Image(systemName: "plus.circle.fill")
                    Text(T("导入语料")).font(.system(size: 12, weight: .semibold))
                    Spacer()
                    Text("⌘O").font(.system(size: 10, design: .rounded)).foregroundStyle(.tertiary)
                }
                .padding(.horizontal, 10)
                .padding(.vertical, 8)
                .background {
                    RoundedRectangle(cornerRadius: 9, style: .continuous)
                        .fill(Theme.accent.opacity(0.14))
                }
                .foregroundStyle(Theme.accent)
            }
            .buttonStyle(.plain)

            Button {
                ws.showEngineSheet = true
            } label: {
                HStack(spacing: 6) {
                    Circle()
                        .fill(ws.engine.isReady ? Color.green : Color.orange)
                        .frame(width: 6, height: 6)
                    Text(ws.engine.badge)
                        .font(.system(size: 10.5))
                        .foregroundStyle(.secondary)
                    Spacer()
                    Image(systemName: "gearshape")
                        .font(.system(size: 9))
                        .foregroundStyle(.tertiary)
                }
                .padding(.horizontal, 10)
                .padding(.vertical, 6)
            }
            .buttonStyle(.plain)
        }
        .padding(.horizontal, 10)
        .padding(.bottom, 10)
    }
}

@MainActor
struct CorpusRow: View {
    var corpus: Corpus
    var isSelected: Bool
    @State private var hover = false

    private var dims: [(Int, Double)] { (1...6).map { ($0, corpus.dims[$0] ?? 0) } }
    private var maxAbs: Double { max(1, dims.map { abs($0.1) }.max() ?? 1) }

    var body: some View {
        VStack(alignment: .leading, spacing: 7) {
            HStack(spacing: 6) {
                Text(corpus.name)
                    .font(.system(size: 12.5, weight: .semibold))
                    .lineLimit(1)
                    .foregroundStyle(isSelected ? AnyShapeStyle(Color.primary) : AnyShapeStyle(Color.primary.opacity(0.9)))
                Spacer()
                Text("\(corpus.documents.count)")
                    .font(.system(size: 10, weight: .medium, design: .rounded).monospacedDigit())
                    .foregroundStyle(.tertiary)
            }
            HStack(spacing: 3) {
                ForEach(dims, id: \.0) { d, v in
                    Capsule()
                        .fill(Dims.color(d).opacity(0.85))
                        .frame(width: 4, height: CGFloat(6 + 16 * min(1, abs(v) / maxAbs)))
                        .frame(maxHeight: .infinity, alignment: v >= 0 ? .bottom : .top)
                }
            }
            .frame(height: 24, alignment: .center)
            .opacity(0.9)

            Text(TextTypes.name(corpus.textType))
                .font(.system(size: 10))
                .foregroundStyle(.secondary)
                .lineLimit(1)
        }
        .padding(10)
        .background {
            RoundedRectangle(cornerRadius: 12, style: .continuous)
                .fill(isSelected ? AnyShapeStyle(Theme.accent.opacity(0.16))
                                 : AnyShapeStyle(Color.primary.opacity(hover ? 0.05 : 0.02)))
                .overlay {
                    RoundedRectangle(cornerRadius: 12, style: .continuous)
                        .strokeBorder(isSelected ? Theme.accent.opacity(0.45) : Color.clear, lineWidth: 1)
                }
        }
        .contentShape(Rectangle())
        .onHover { hover = $0 }
        .animation(Motion.quick, value: hover)
        .animation(Motion.snappy, value: isSelected)
    }
}

// MARK: - 详情容器

@MainActor
struct DetailView: View {
    @Environment(Workspace.self) private var ws
    var corpus: Corpus
    @Namespace private var tabNS

    var body: some View {
        @Bindable var ws = ws

        VStack(spacing: 0) {
            header
            Divider().opacity(0.4)
            ScrollView {
                Group {
                    switch ws.tab {
                    case .overview:     OverviewView(corpus: corpus)
                    case .dimensions:   DimensionsView(corpus: corpus)
                    case .sixDim:       SixDimView(corpus: corpus)
                    case .textType:     TextTypeView(corpus: corpus)
                    case .features:     FeaturesView(corpus: corpus)
                    case .distribution: DistributionView(corpus: corpus)
                    case .compare:      CompareView()
                    case .zcompare:     ZCompareView()
                    }
                }
                .padding(22)
                .frame(maxWidth: .infinity, alignment: .topLeading)
                .id(ws.tab)          // 切页签回到顶部
            }
            .scrollIndicators(.automatic)
        }
    }

    private var header: some View {
        @Bindable var ws = ws

        return VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .center, spacing: 12) {
                VStack(alignment: .leading, spacing: 3) {
                    Text(corpus.name)
                        .font(.system(size: 20, weight: .semibold, design: .rounded))
                    HStack(spacing: 8) {
                        Text(T("%@ 篇", corpus.documents.count)).font(.system(size: 11))
                        Text("·")
                        Text(T("%@ 词", corpus.tokens)).font(.system(size: 11))
                        Text("·")
                        Text(corpus.settings.summary).font(.system(size: 11))
                    }
                    .foregroundStyle(.secondary)
                }
                Spacer()

                if corpus.documents.count > 1 {
                    Picker("", selection: $ws.selectedDocument) {
                        Text(T("语料整体")).tag(String?.none)
                        Divider()
                        ForEach(corpus.documents, id: \.name) { d in
                            Text(d.name).tag(String?.some(d.name))
                        }
                    }
                    .labelsHidden()
                    .frame(width: 156)
                    .controlSize(.small)
                }
            }

            tabBar
        }
        .padding(.horizontal, 22)
        .padding(.top, 16)
        .padding(.bottom, 10)
    }

    private var tabBar: some View {
        @Bindable var ws = ws

        return ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 3) {
                ForEach(Workspace.Tab.allCases) { t in
                    Button {
                        withAnimation(Motion.snappy) { ws.tab = t }
                    } label: {
                        HStack(spacing: 4) {
                            Image(systemName: t.icon).font(.system(size: 10, weight: .semibold))
                            Text(t.title).font(.system(size: 11.5, weight: .medium))
                        }
                        .padding(.horizontal, 9)
                        .padding(.vertical, 5.5)
                        .background {
                            if ws.tab == t {
                                Capsule()
                                    .fill(.regularMaterial)
                                    .overlay { Capsule().strokeBorder(Theme.accent.opacity(0.35), lineWidth: 1) }
                                    .matchedGeometryEffect(id: "tab", in: tabNS)
                            }
                        }
                        .foregroundStyle(ws.tab == t ? Theme.accent : Color.secondary)
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(.vertical, 1)
        }
        .scrollClipDisabled()
    }
}

// MARK: - 导入面板 / 导出

@MainActor
enum ImportPanel {
    static func open(_ completion: @escaping ([URL]) -> Void) {
        let panel = NSOpenPanel()
        panel.title = T("选择语料")
        panel.message = T("可以选 .txt 文件，也可以选一个只放 .txt 的文件夹")
        panel.allowsMultipleSelection = true
        panel.canChooseDirectories = true
        panel.canChooseFiles = true
        panel.allowedContentTypes = [.plainText, .folder]
        if panel.runModal() == .OK { completion(panel.urls) }
    }
}
