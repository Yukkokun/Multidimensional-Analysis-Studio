import SwiftUI
import Charts
import MATCore

// MARK: - 六维概览（从维度页独立出来的页签）

@MainActor
struct SixDimView: View {
    @Environment(Workspace.self) private var ws
    var corpus: Corpus

    /// 图 ↔ 逐维度表 共用的悬停维度
    @State private var hoveredDim: Int?

    private var doc: DocumentResult? {
        guard let n = ws.selectedDocument else { return nil }
        return corpus.documents.first { $0.name == n }
    }
    private var compare: Corpus? {
        guard let id = ws.dimCompareID, id != corpus.id else { return nil }
        return ws.corpora.first { $0.id == id }
    }

    private var pairs: [(m: DimMeta, v: Double)] {
        Dims.all.map { m in
            let v: Double
            if let d = doc { v = d.dims[m.id] ?? 0 } else { v = corpus.dims[m.id] ?? 0 }
            return (m, v)
        }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(spacing: 10) {
                SectionHeader(T("六维概览"), subtitle: doc?.name ?? corpus.name)
                Spacer()
                compareMenu
                if compare != nil {
                    HStack(spacing: 12) {
                        LegendItem(shape: .bar, color: SeriesColors.a, label: corpus.name)
                        LegendItem(shape: .bar, color: SeriesColors.b, label: compare!.name)
                    }
                } else {
                    Badge(text: T("灰点 = 语料均值"), tint: .secondary)
                }
            }

            if compare == nil {
                singleChart
            } else {
                groupedChart
            }

            summaryTable
        }
    }

    /// 和维度页同款的「叠加对比语料」选择器
    private var compareMenu: some View {
        @Bindable var ws = ws
        return HStack(spacing: 6) {
            Menu {
                Button(T("不叠加")) { ws.dimCompareID = nil }
                Divider()
                ForEach(ws.corpora.filter { $0.id != corpus.id }) { c in
                    Button(c.name) { ws.dimCompareID = c.id }
                }
            } label: {
                HStack(spacing: 6) {
                    Image(systemName: "square.on.square")
                        .font(.system(size: 9.5, weight: .semibold))
                    Text(compare.map { T("对比：%@", $0.name) } ?? T("对比另一语料"))
                        .font(.system(size: 11.5))
                    Image(systemName: "chevron.down").font(.system(size: 8, weight: .semibold))
                        .foregroundStyle(.tertiary)
                }
                .padding(.horizontal, 9).padding(.vertical, 5)
                .background {
                    Capsule()
                        .fill(compare == nil ? AnyShapeStyle(.ultraThinMaterial)
                                             : AnyShapeStyle(SeriesColors.b.opacity(0.16)))
                        .overlay {
                            Capsule().strokeBorder(compare == nil ? Color.primary.opacity(0.07)
                                                                  : SeriesColors.b.opacity(0.45),
                                                   lineWidth: 1)
                        }
                }
                .foregroundStyle(compare == nil ? Color.secondary : SeriesColors.b)
            }
            .menuStyle(.borderlessButton)
            .fixedSize()

            if compare != nil {
                Button {
                    withAnimation(Motion.snappy) { ws.dimCompareID = nil }
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .font(.system(size: 11)).foregroundStyle(.tertiary)
                }
                .buttonStyle(.plain)
            }
        }
    }

    // MARK: 单语料

    /// 用**数值纵轴 + 索引**（y = 5…0），而不是分类 band：
    /// 分类 band 下 BarMark 与 AxisValueLabel 各算一套位置，纵轴标签会整体错开（用户截图里的 D1…D6 漂移）。
    private func yPos(_ i: Int) -> Double { Double(pairs.count - 1 - i) }

    private var yDomainRows: ClosedRange<Double> { -0.55...(Double(pairs.count) - 0.45) }

    private var singleChart: some View {
        let peak = pairs.map { abs($0.v) }.max() ?? 5
        let domainMax: Double = max(5, peak * 1.22)
        let showMean = corpus.documents.count > 1

        return Chart {
            ForEach(Array(pairs.enumerated()), id: \.element.m.id) { i, pair in
                BarMark(xStart: .value("零", 0), xEnd: .value("分数", pair.v),
                        y: .value("行", yPos(i)), height: .fixed(15))
                    .foregroundStyle(
                        LinearGradient(colors: [pair.m.color.opacity(pair.v >= 0 ? 0.55 : 0.30), pair.m.color],
                                       startPoint: .leading, endPoint: .trailing))
                    .cornerRadius(5)
                    .opacity(hoveredDim == nil || hoveredDim == pair.m.id ? 1 : 0.28)
                    .annotation(position: pair.v >= 0 ? .trailing : .leading, spacing: 4) {
                        Text(String(format: "%.2f", pair.v))
                            .font(.system(size: 10.5, weight: .semibold, design: .rounded).monospacedDigit())
                            .foregroundStyle(pair.m.color)
                    }

                if showMean {
                    PointMark(x: .value("均值", corpus.dims[pair.m.id] ?? 0),
                              y: .value("行", yPos(i)))
                        .symbolSize(40)
                        .foregroundStyle(Color.primary.opacity(0.40))
                        .opacity(hoveredDim == nil || hoveredDim == pair.m.id ? 1 : 0.28)
                }
            }

            RuleMark(x: .value("zero", 0))
                .foregroundStyle(Color.primary.opacity(0.22))
                .lineStyle(StrokeStyle(lineWidth: 1))
        }
        .chartXScale(domain: -domainMax...domainMax)
        .chartXAxis { xAxis }
        .chartYAxis { rowAxis }
        .chartYScale(domain: yDomainRows)
        .chartOverlay { proxy in hoverLayer(proxy) }
        .animation(Motion.quick, value: hoveredDim)
        .frame(height: 300)
        .glassCard()
    }

    // MARK: 双语料：同一维度内上下两条

    /// 两个语料不再左右并排挤压，而是在同一行里上下两条：
    /// A 在上、B 在下，各自从 0 起算，末端标数值。
    private var groupedChart: some View {
        let allValues = pairs.map(\.v) + (compare.map { c in Dims.all.map { c.dims[$0.id] ?? 0 } } ?? [])
        let peak = allValues.map { abs($0) }.max() ?? 5
        let domainMax: Double = max(5, peak * 1.30)
        let gap = 0.19

        return Chart {
            ForEach(Array(pairs.enumerated()), id: \.element.m.id) { i, pair in
                BarMark(xStart: .value("零", 0), xEnd: .value("分数", pair.v),
                        y: .value("行", yPos(i) + gap), height: .fixed(7))
                    .foregroundStyle(LinearGradient(colors: [SeriesColors.a.opacity(0.75), SeriesColors.a],
                                                    startPoint: pair.v >= 0 ? .leading : .trailing,
                                                    endPoint: pair.v >= 0 ? .trailing : .leading))
                    .cornerRadius(3.5)
                    .opacity(hoveredDim == nil || hoveredDim == pair.m.id ? 1 : 0.28)
                    .annotation(position: pair.v >= 0 ? .trailing : .leading, spacing: 5) {
                        Text(String(format: "%.1f", pair.v))
                            .font(.system(size: 9, weight: .medium, design: .rounded).monospacedDigit())
                            .foregroundStyle(SeriesColors.a)
                            .fixedSize()
                    }

                if let c = compare {
                    let v = c.dims[pair.m.id] ?? 0
                    BarMark(xStart: .value("零", 0), xEnd: .value("分数", v),
                            y: .value("行", yPos(i) - gap), height: .fixed(7))
                        .foregroundStyle(LinearGradient(colors: [SeriesColors.b.opacity(0.75), SeriesColors.b],
                                                        startPoint: v >= 0 ? .leading : .trailing,
                                                        endPoint: v >= 0 ? .trailing : .leading))
                        .cornerRadius(3.5)
                        .opacity(hoveredDim == nil || hoveredDim == pair.m.id ? 1 : 0.28)
                        .annotation(position: v >= 0 ? .trailing : .leading, spacing: 5) {
                            Text(String(format: "%.1f", v))
                                .font(.system(size: 9, weight: .medium, design: .rounded).monospacedDigit())
                                .foregroundStyle(SeriesColors.b)
                                .fixedSize()
                        }
                }
            }

            RuleMark(x: .value("zero", 0))
                .foregroundStyle(Color.primary.opacity(0.26))
                .lineStyle(StrokeStyle(lineWidth: 1))
        }
        .chartXScale(domain: -domainMax...domainMax, range: .plotDimension(padding: 22))
        .chartXAxis { xAxis }
        .chartYAxis { rowAxis }
        .chartYScale(domain: yDomainRows)
        .chartOverlay { proxy in hoverLayer(proxy) }
        .animation(Motion.quick, value: hoveredDim)
        .frame(height: 340)
        .glassCard()
    }

    /// 行标签：数值索引 → D1…D6
    private var rowAxis: some AxisContent {
        AxisMarks(position: .leading, values: (0..<pairs.count).map { Double($0) }) { value in
            AxisValueLabel {
                if let d = value.as(Double.self) {
                    let idx = pairs.count - 1 - Int(d.rounded())
                    if idx >= 0, idx < pairs.count {
                        Text(pairs[idx].m.label)
                            .font(.system(size: 11, weight: .semibold, design: .rounded))
                            .foregroundStyle(pairs[idx].m.color)
                    }
                }
            }
            AxisTick().foregroundStyle(.clear)
        }
    }

    private func hoverLayer(_ proxy: ChartProxy) -> some View {
        GeometryReader { geo in
            Rectangle().fill(.clear).contentShape(Rectangle())
                .onContinuousHover { phase in
                    switch phase {
                    case .active(let p):
                        guard let plot = proxy.plotFrame else { return }
                        let y = p.y - geo[plot].origin.y
                        if let row: Double = proxy.value(atY: y) {
                            let idx = pairs.count - 1 - Int(row.rounded())
                            if idx >= 0, idx < pairs.count {
                                withAnimation(Motion.quick) { hoveredDim = pairs[idx].m.id }
                            }
                        }
                    case .ended:
                        withAnimation(Motion.quick) { hoveredDim = nil }
                    }
                }
        }
    }

    private var xAxis: some AxisContent {
        AxisMarks(values: .automatic(desiredCount: 7)) { value in
            AxisGridLine().foregroundStyle(Color.primary.opacity(0.06))
            AxisValueLabel {
                if let d = value.as(Double.self) {
                    Text(String(format: "%.0f", d))
                        .font(.system(size: 10, design: .rounded).monospacedDigit())
                        .foregroundStyle(.tertiary)
                }
            }
        }
    }

    private var yAxis: some AxisContent {
        AxisMarks(position: .leading) { value in
            AxisValueLabel {
                if let s = value.as(String.self) {
                    Text(s).font(.system(size: 11, weight: .medium, design: .rounded))
                }
            }
        }
    }

    // MARK: 明细表

    private var summaryTable: some View {
        VStack(alignment: .leading, spacing: 8) {
            SectionHeader(T("逐维度"), subtitle: T("每根棒的数值 + 距离最近的参考体裁"))
            Grid(alignment: .leading, horizontalSpacing: 16, verticalSpacing: 7) {
                GridRow {
                    Text(T("维度"))
                    Text(CorpusLabel.short(corpus.name, limit: 12)).gridColumnAlignment(.trailing)
                    if compare != nil {
                        Text(CorpusLabel.short(compare!.name, limit: 12)).gridColumnAlignment(.trailing)
                    }
                    if compare != nil { Text(T("差值")).gridColumnAlignment(.trailing) }
                    Text(T("最近体裁"))
                }
                .font(.system(size: 10, weight: .medium))
                .foregroundStyle(.tertiary)

                Divider().gridCellColumns(compare == nil ? 3 : 5).opacity(0.3)

                ForEach(pairs, id: \.m.id) { pair in
                    let bValue = compare?.dims[pair.m.id]
                    GridRow {
                        HStack(spacing: 6) {
                            Circle().fill(pair.m.color).frame(width: 6, height: 6)
                            Text("D\(pair.m.id) \(pair.m.title)").font(.system(size: 11.5))
                        }
                        Text(String(format: "%.2f", pair.v))
                            .font(.system(size: 11, design: .rounded).monospacedDigit())
                            .foregroundStyle(SeriesColors.a)
                        if compare != nil {
                            Text(bValue.map { String(format: "%.2f", $0) } ?? "—")
                                .font(.system(size: 11, design: .rounded).monospacedDigit())
                                .foregroundStyle(SeriesColors.b)
                        }
                        if let b = bValue {
                            Text(String(format: "%+.2f", pair.v - b))
                                .font(.system(size: 11, weight: .medium, design: .rounded).monospacedDigit())
                                .foregroundStyle(pair.m.color)
                        }
                        Text(nearestGenre(pair.m.id, value: pair.v))
                            .font(.system(size: 10.5))
                            .foregroundStyle(.secondary)
                    }
                    .padding(.horizontal, 6)
                    .padding(.vertical, 4)
                    .background {
                        if hoveredDim == pair.m.id {
                            RoundedRectangle(cornerRadius: 6, style: .continuous)
                                .fill(pair.m.color.opacity(0.12))
                        }
                    }
                    .contentShape(Rectangle())
                    .onHover { inside in
                        withAnimation(Motion.quick) {
                            if inside { hoveredDim = pair.m.id }
                            else if hoveredDim == pair.m.id { hoveredDim = nil }
                        }
                    }
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .glassCard()
    }

    private func nearestGenre(_ dim: Int, value: Double) -> String {
        let g = Catalog.shared.genres.min {
            abs(($0.values[safe: dim - 1] ?? 0) - value) < abs(($1.values[safe: dim - 1] ?? 0) - value)
        }
        return g.map { "\(GenreRow.shortName($0.name))（\(String(format: "%.1f", $0.values[safe: dim - 1] ?? 0))）" } ?? "—"
    }
}
