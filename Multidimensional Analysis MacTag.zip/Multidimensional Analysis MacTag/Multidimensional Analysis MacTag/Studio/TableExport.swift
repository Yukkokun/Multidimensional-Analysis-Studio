import SwiftUI
import AppKit
import UniformTypeIdentifiers

// MARK: - 表格的复制与导出
//
// 两张表（六维差异 / 每个维度的变量块）都要「复制到 Excel」和「导出图片」。
// 复制走 TSV：Excel 粘进去自动分列，比 CSV 省事（不用处理逗号与引号）。
// 导出不复用屏幕上的视图，而是按同样的数据重新排一张干净的静态图——
// 屏幕上那张带悬停高亮、圆角、毛玻璃，截图出来反而不好看。

@MainActor
enum TableExport {

    static func copyTSV(_ rows: [[String]]) {
        let text = rows.map { $0.joined(separator: "\t") }.joined(separator: "\n")
        let pb = NSPasteboard.general
        pb.clearContents()
        pb.setString(text, forType: .string)
    }

    static func image(title: String, subtitle: String?, header: [String], rows: [[String]]) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            VStack(alignment: .leading, spacing: 3) {
                Text(title).font(.system(size: 17, weight: .semibold, design: .rounded))
                if let subtitle {
                    Text(subtitle).font(.system(size: 11)).foregroundStyle(.secondary)
                }
            }

            Grid(alignment: .leading, horizontalSpacing: 18, verticalSpacing: 7) {
                GridRow {
                    ForEach(Array(header.enumerated()), id: \.offset) { i, h in
                        Text(h)
                            .font(.system(size: 11, weight: .semibold))
                            .foregroundStyle(.secondary)
                            .gridColumnAlignment(i == 0 ? .leading : .trailing)
                    }
                }
                Divider().gridCellColumns(header.count).opacity(0.35)

                ForEach(Array(rows.enumerated()), id: \.offset) { idx, row in
                    GridRow {
                        ForEach(Array(row.enumerated()), id: \.offset) { i, cell in
                            Text(cell)
                                .font(.system(size: 11.5, weight: i == 0 ? .medium : .regular,
                                              design: i == 0 ? .default : .rounded).monospacedDigit())
                                .foregroundStyle(i == 0 ? Color.primary : Color.primary.opacity(0.85))
                        }
                    }
                    .padding(.vertical, 1)
                    .background(idx % 2 == 1 ? Color.primary.opacity(0.025) : Color.clear)
                }
            }
        }
        .padding(22)
        .frame(width: 820, alignment: .leading)
        .background(Color(nsColor: .textBackgroundColor))
    }

    static func askAndExport(title: String, subtitle: String?, header: [String], rows: [[String]]) {
        let panel = NSSavePanel()
        panel.allowedContentTypes = [.png]
        panel.nameFieldStringValue = sanitize(title) + ".png"
        guard panel.runModal() == .OK, let url = panel.url else { return }
        export(title: title, subtitle: subtitle, header: header, rows: rows, to: url)
    }

    static func export(title: String, subtitle: String?, header: [String], rows: [[String]], to url: URL) {
        let content = image(title: title, subtitle: subtitle, header: header, rows: rows)
        let renderer = ImageRenderer(content: content)
        renderer.scale = 2
        guard let img = renderer.nsImage,
              let tiff = img.tiffRepresentation,
              let rep = NSBitmapImageRep(data: tiff),
              let png = rep.representation(using: .png, properties: [:]) else { return }
        try? png.write(to: url)
    }

    private static func sanitize(_ s: String) -> String {
        s.replacingOccurrences(of: "/", with: "-")
            .replacingOccurrences(of: ":", with: "-")
            .trimmingCharacters(in: .whitespaces)
    }
}

// MARK: - 小图标按钮

struct IconAction: View {
    var systemName: String
    var help: String
    var tint: Color = .secondary
    var action: () -> Void

    @State private var hover = false
    @State private var bounce = 0

    var body: some View {
        Button {
            bounce += 1
            action()
        } label: {
            Image(systemName: systemName)
                .font(.system(size: 10.5, weight: .semibold))
                .foregroundStyle(hover ? Theme.accent : tint.opacity(0.75))
                .frame(width: 22, height: 20)
                .background {
                    RoundedRectangle(cornerRadius: 5, style: .continuous)
                        .fill(hover ? Theme.accent.opacity(0.12) : Color.clear)
                }
                .scaleEffect(hover ? 1.08 : 1)
        }
        .buttonStyle(.plain)
        .help(help)
        .onHover { hover = $0 }
        .symbolEffect(.bounce, value: bounce)
        .animation(Motion.quick, value: hover)
    }
}
