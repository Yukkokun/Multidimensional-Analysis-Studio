import SwiftUI
import Charts
import MATCore

// MARK: - 文本类型的两种呈现

enum TextTypeStyle: String, CaseIterable, Identifiable {
    case original = "原版方式"     // 复刻 texttype_graph.pl：每个维度一列散点，每类一个带名字的点
    case contour = "维度轮廓"      // 本应用的设计：语料折线 + 每一篇 + 8 条类型折线
    var id: String { rawValue }

    @MainActor var title: String { T(rawValue) }

    @MainActor var hint: String {
        switch self {
        case .original: return T("原版：5 个维度各一列，8 种类型各一个带名字的点")
        case .contour: return T("语料折线 + 每一篇 + 8 条类型轮廓")
        }
    }
}

// MARK: - 图表

/// 原版 `texttype_graph.pl` 画的是「5 个维度 × 每类一个标签点」的散点图（2100×1000），
/// 并且把 D1 乘了 0.1（`line 35`）来平衡量级。两种呈现都沿用这个读数方式。
@MainActor
struct TextTypeChartView: View {
    var corpus: Corpus
    var compare: Corpus? = nil
    var style: TextTypeStyle = .contour
    var highlight: String? = nil          // 外部（列表）驱动的类型名
    var height: CGFloat = 380
    var showTitle: Bool = true

    private let dims = 1...5

    private var types: [Centroid] { Catalog.shared.textTypes }

    private var nearestName: String? { types.min { d($0, corpus) < d($1, corpus) }?.name }
    private var effectiveHighlight: String? { highlight ?? nearestName }

    /// 只有用户真的在列表上悬停时才压暗其它类型；
    /// 默认只把「最近的一种」标出来，其余标签照常显示（原版方式要看得到 8 个名字）
    private var userHovering: Bool { highlight != nil }

    private func scale(_ dim: Int, _ v: Double) -> Double { dim == 1 ? v / 10 : v }

    /// 真实距离（不除以 10），与文本类型判定用的口径一致
    private func d(_ t: Centroid, _ c: Corpus) -> Double {
        var acc = 0.0
        for dim in dims {
            let a = c.dims[dim] ?? 0
            let b = t.values[safe: dim - 1] ?? 0
            acc += (a - b) * (a - b)
        }
        return acc.squareRoot()
    }

    private func yDomain() -> ClosedRange<Double> {
        var values: [Double] = []
        for c in [corpus, compare].compactMap({ $0 }) {
            values += dims.map { scale($0, c.dims[$0] ?? 0) }
            for doc in c.documents {
                values += dims.map { scale($0, doc.dims[$0] ?? 0) }
            }
        }
        for t in types {
            values += dims.map { scale($0, t.values[safe: $0 - 1] ?? 0) }
        }
        let lo = values.min() ?? -10
        let hi = values.max() ?? 10
        let pad = max(2, (hi - lo) * 0.14)
        return (lo - pad)...(hi + pad)
    }

    private func label(_ dim: Int) -> String { dim == 1 ? "D1 ÷10" : "D\(dim)" }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            if showTitle {
                HStack(alignment: .firstTextBaseline, spacing: 8) {
                    Text(T("五个维度的轮廓")).font(.system(size: 12.5, weight: .semibold))
                    Text(style.hint).font(.system(size: 10)).foregroundStyle(.tertiary)
                    Spacer()
                    if let n = nearestName {
                        Badge(text: T("A 最近：%@", TextTypes.name(n)), tint: Dims.color(2), filled: true)
                    }
                }
            }

            switch style {
            case .original: originalChart
            case .contour: contourChart
            }

            legend
        }
        .animation(Motion.quick, value: effectiveHighlight)
        .animation(Motion.snappy, value: style)
    }

    // MARK: 原版方式：每列散点 + 标签

    private var originalChart: some View {
        Chart {
            // 8 种文本类型：每个维度一个点，带名字
            ForEach(Array(types.enumerated()), id: \.element.name) { ti, t in
                let isHot = effectiveHighlight == t.name
                ForEach(dims, id: \.self) { dim in
                    PointMark(x: .value("维度", label(dim)),
                              y: .value("得分", scale(dim, t.values[safe: dim - 1] ?? 0)))
                        .foregroundStyle(TypePalette.color(ti))
                        .symbolSize(isHot ? 90 : 46)
                        .opacity(isHot ? 1 : (userHovering ? 0.35 : 0.9))
                        .annotation(position: ti % 2 == 0 ? .trailing : .leading, spacing: 3) {
                            // 悬停某一条时只留它的标签，别的隐去，避免一片糊
                            Text(TextTypes.brief(t.name))
                                .font(.system(size: 7.8, weight: isHot ? .semibold : .regular))
                                .foregroundStyle(TypePalette.color(ti))
                                .padding(.horizontal, 2)
                                .background {
                                    Capsule().fill(Color(nsColor: .textBackgroundColor).opacity(isHot ? 0.9 : 0.55))
                                }
                                .opacity(isHot ? 1 : (userHovering ? 0 : 0.9))
                        }
                }
            }

            // 语料（可能有 A / B 两个）
            ForEach(Array([corpus, compare].compactMap { $0 }.enumerated()), id: \.element.id) { ci, c in
                let color = ci == 0 ? SeriesColors.a : SeriesColors.b
                ForEach(dims, id: \.self) { dim in
                    PointMark(x: .value("维度", label(dim)),
                              y: .value("得分", scale(dim, c.dims[dim] ?? 0)))
                        .foregroundStyle(color)
                        .symbolSize(150)
                        .symbol {
                            Circle()
                                .fill(color)
                                .frame(width: 13, height: 13)
                                .overlay { Circle().strokeBorder(.white, lineWidth: 2) }
                        }
                        .annotation(position: .top, spacing: 3) {
                            Text(ci == 0 ? "A" : "B")
                                .font(.system(size: 8.5, weight: .bold))
                                .foregroundStyle(color)
                        }
                }
            }
        }
        .chartYScale(domain: yDomain())
        .chartXAxis {
            AxisMarks { value in
                AxisValueLabel {
                    if let s = value.as(String.self) {
                        Text(s).font(.system(size: 10.5, weight: .medium))
                    }
                }
                AxisTick().foregroundStyle(.clear)
            }
        }
        .chartYAxis { yAxis }
        .frame(height: height)
    }

    // MARK: 维度轮廓：折线

    private var contourChart: some View {
        Chart {
            // 8 种类型（虚线）
            ForEach(types, id: \.name) { t in
                let isHot = effectiveHighlight == t.name
                ForEach(dims, id: \.self) { dim in
                    LineMark(x: .value("维度", label(dim)),
                             y: .value("得分", scale(dim, t.values[safe: dim - 1] ?? 0)),
                             series: .value("系列", t.name))
                        .foregroundStyle(isHot ? AnyShapeStyle(Dims.color(2))
                                               : AnyShapeStyle(Color.gray.opacity(0.40)))
                        .lineStyle(StrokeStyle(lineWidth: isHot ? 2.2 : 1,
                                               dash: isHot ? [] : [3, 2]))
                        .interpolationMethod(.catmullRom)

                    PointMark(x: .value("维度", label(dim)),
                              y: .value("得分", scale(dim, t.values[safe: dim - 1] ?? 0)))
                        .symbolSize(isHot ? 30 : 8)
                        .foregroundStyle(isHot ? Dims.color(2) : Color.gray.opacity(0.30))
                }
            }

            // 每一篇（A 的细线；有 B 时也给 B 画，更淡）
            ForEach(Array([corpus, compare].compactMap { $0 }.enumerated()), id: \.element.id) { ci, c in
                let color = ci == 0 ? SeriesColors.a : SeriesColors.b
                ForEach(c.documents, id: \.name) { doc in
                    ForEach(dims, id: \.self) { dim in
                        LineMark(x: .value("维度", label(dim)),
                                 y: .value("得分", scale(dim, doc.dims[dim] ?? 0)),
                                 series: .value("系列", "doc-\(ci)-" + doc.name))
                            .foregroundStyle(color.opacity(0.16))
                            .lineStyle(StrokeStyle(lineWidth: 1))
                    }
                }
            }

            // 语料均值
            ForEach(Array([corpus, compare].compactMap { $0 }.enumerated()), id: \.element.id) { ci, c in
                let color = ci == 0 ? SeriesColors.a : SeriesColors.b
                ForEach(dims, id: \.self) { dim in
                    LineMark(x: .value("维度", label(dim)),
                             y: .value("得分", scale(dim, c.dims[dim] ?? 0)),
                             series: .value("系列", "corpus-\(ci)"))
                        .foregroundStyle(color)
                        .lineStyle(StrokeStyle(lineWidth: 2.8, lineCap: .round))
                        .interpolationMethod(.catmullRom)

                    PointMark(x: .value("维度", label(dim)),
                              y: .value("得分", scale(dim, c.dims[dim] ?? 0)))
                        .symbolSize(46)
                        .foregroundStyle(color)
                        .annotation(position: .top, spacing: 3) {
                            Text(String(format: "%.1f", c.dims[dim] ?? 0))
                                .font(.system(size: 9, weight: .semibold, design: .rounded).monospacedDigit())
                                .foregroundStyle(color)
                        }
                }
            }

            if let hot = effectiveHighlight, let t = types.first(where: { $0.name == hot }) {
                PointMark(x: .value("维度", label(5)),
                          y: .value("得分", scale(5, t.values[safe: 4] ?? 0)))
                    .symbolSize(0.1)
                    .annotation(position: .leading, spacing: 4) {
                        Text(TextTypes.name(hot))
                            .font(.system(size: 9.5, weight: .semibold, design: .rounded))
                            .foregroundStyle(Dims.color(2))
                    }
            }
        }
        .chartYScale(domain: yDomain())
        .chartXAxis {
            AxisMarks { value in
                AxisValueLabel {
                    if let s = value.as(String.self) {
                        Text(s).font(.system(size: 10.5, weight: .medium))
                    }
                }
                AxisTick().foregroundStyle(.clear)
            }
        }
        .chartYAxis { yAxis }
        .frame(height: height)
    }

    private var yAxis: some AxisContent {
        AxisMarks(position: .leading, values: .automatic(desiredCount: 5)) { value in
            AxisGridLine().foregroundStyle(Color.primary.opacity(0.06))
            AxisValueLabel {
                if let v = value.as(Double.self) {
                    Text(String(format: "%.0f", v))
                        .font(.system(size: 10, design: .rounded).monospacedDigit())
                        .foregroundStyle(.tertiary)
                }
            }
        }
    }

    // MARK: 图例

    private var legend: some View {
        HStack(spacing: 12) {
            if style == .contour {
                LegendItem(shape: .line, color: SeriesColors.a, label: corpus.name)
                if let b = compare { LegendItem(shape: .line, color: SeriesColors.b, label: b.name) }
                LegendItem(shape: .dashed, color: Color.gray.opacity(0.55), label: T("8 种文本类型"))
                LegendItem(shape: .line, color: Dims.color(2), label: T("当前查看的一种"))
            } else {
                HStack(spacing: 4) {
                    Text(T("文本类型")).font(.system(size: 10)).foregroundStyle(.secondary)
                    ForEach(Array(types.enumerated()), id: \.element.name) { i, t in
                        Circle().fill(TypePalette.color(i)).frame(width: 7, height: 7)
                            .help(TextTypes.name(t.name))
                    }
                }
                LegendItem(shape: .dot, color: SeriesColors.a, label: corpus.name)
                if let b = compare { LegendItem(shape: .dot, color: SeriesColors.b, label: b.name) }
            }
            Spacer()
            Text(T("D1 除以 10 显示（原版 texttype_graph.pl:35 同样处理）"))
                .font(.system(size: 9.5))
                .foregroundStyle(.tertiary)
        }
    }
}

// MARK: - 页面

@MainActor
struct TextTypeView: View {
    @Environment(Workspace.self) private var ws
    var corpus: Corpus

    @State private var style: TextTypeStyle = .original
    /// 列表里悬停的类型；nil 时展示「最近的一种」
    @State private var hovering: String?

    private var compare: Corpus? {
        guard let id = ws.dimCompareID, id != corpus.id else { return nil }
        return ws.corpora.first { $0.id == id }
    }

    private var distances: [TypeDistance] { TypeDistance.build(corpus: corpus, compare: compare) }
    private var typeName: String { corpus.textType }
    private var nearestName: String? { distances.min { $0.a < $1.a }?.name }
    private var effective: String? { hovering ?? nearestName }

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            header
            TextTypeChartView(corpus: corpus, compare: compare, style: ws.textTypeStyle,
                              highlight: hovering, height: 380)
                .glassCard()
            HStack(alignment: .top, spacing: 16) {
                distanceTable
                aboutCard
            }
        }
    }

    private var header: some View {
        HStack(alignment: .center, spacing: 10) {
            VStack(alignment: .leading, spacing: 2) {
                Text(TextTypes.name(typeName))
                    .font(.system(size: 19, weight: .semibold, design: .rounded))
                Text(typeName)
                    .font(.system(size: 10.5))
                    .foregroundStyle(.tertiary)
            }

            Spacer()

            compareMenu

            Picker("", selection: Bindable(ws).textTypeStyle) {
                ForEach(TextTypeStyle.allCases) { s in Text(s.title).tag(s) }
            }
            .pickerStyle(.segmented)
            .labelsHidden()
            .frame(width: 178)
            .controlSize(.small)

            if let best = distances.min(by: { $0.a < $1.a }) {
                Badge(text: T("A 距离 %@", String(format: "%.2f", best.a)), tint: Dims.color(2), filled: true)
            }
        }
    }

    private var compareMenu: some View {
        @Bindable var ws = ws
        return HStack(spacing: 5) {
            Menu {
                Button(T("不对比")) { ws.dimCompareID = nil }
                Divider()
                ForEach(ws.corpora.filter { $0.id != corpus.id }) { c in
                    Button(c.name) { ws.dimCompareID = c.id }
                }
            } label: {
                HStack(spacing: 5) {
                    Image(systemName: "square.on.square")
                        .font(.system(size: 9, weight: .semibold))
                    Text(compare.map { T("B：%@", $0.name) } ?? T("对比语料"))
                        .font(.system(size: 11))
                        .lineLimit(1)
                    Image(systemName: "chevron.down").font(.system(size: 7.5, weight: .semibold))
                        .foregroundStyle(.tertiary)
                }
                .padding(.horizontal, 8).padding(.vertical, 4.5)
                .background {
                    Capsule()
                        .fill(compare == nil ? AnyShapeStyle(.ultraThinMaterial)
                                             : AnyShapeStyle(SeriesColors.b.opacity(0.16)))
                        .overlay {
                            Capsule().strokeBorder(compare == nil ? Color.primary.opacity(0.07)
                                                                  : SeriesColors.b.opacity(0.45), lineWidth: 1)
                        }
                }
                .foregroundStyle(compare == nil ? Color.secondary : SeriesColors.b)
            }
            .menuStyle(.borderlessButton)
            .fixedSize()

            if compare != nil {
                Button {
                    withAnimation(Motion.snappy) { ws.dimCompareID = nil }
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .font(.system(size: 10)).foregroundStyle(.tertiary)
                }
                .buttonStyle(.plain)
            }
        }
    }

    // MARK: 距离表

    private var distanceTable: some View {
        let rows = distances
        let maxD = rows.map { max($0.a, $0.b ?? 0) }.max() ?? 1
        return VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 6) {
                SectionHeader(T("与 8 种文本类型的距离"), subtitle: T("欧氏距离，越小越像"))
                HelpDot(term: T("怎么用这张表"),
                        plain: T("把指针移到任意一行，上面的图会把那一类标成琥珀色（原版方式下是放大并加粗标签）。用它确认「不是最近的那类」也确实和你不一样。"),
                        example: T("悬停「学术说明」，如果它的点在 D3/D5 上离你的 A 很远，说明确实不是它。"),
                        width: 300)
                Spacer()
            }

            VStack(spacing: 4) {
                ForEach(Array(rows.enumerated()), id: \.element.name) { i, r in
                    row(index: i, r: r, maxD: maxD)
                }
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .glassCard()
    }

    private func row(index i: Int, r: TypeDistance, maxD: Double) -> some View {
        let isHot = effective == r.name
        let color = TypePalette.color(name: r.name)
        return HStack(spacing: 8) {
            Text("\(i + 1)")
                .font(.system(size: 9, weight: .semibold, design: .rounded).monospacedDigit())
                .foregroundStyle(.tertiary)
                .frame(width: 12, alignment: .trailing)
            Circle().fill(color).frame(width: 6, height: 6)
            Text(TextTypes.name(r.name))
                .font(.system(size: 11.5, weight: isHot ? .semibold : .regular))
                .foregroundStyle(isHot ? Dims.color(2) : .primary)
                .frame(width: 96, alignment: .leading)
                .lineLimit(1)
            GeometryReader { geo in
                Capsule()
                    .fill(Color.primary.opacity(0.06))
                    .overlay(alignment: .leading) {
                        Capsule()
                            .fill(isHot ? AnyShapeStyle(Dims.color(2))
                                        : AnyShapeStyle(color.opacity(0.75)))
                            .frame(width: max(3, geo.size.width * (1 - r.a / max(maxD, 1))))
                    }
            }
            .frame(height: isHot ? 7 : 5)
            Text(String(format: "%.2f", r.a))
                .font(.system(size: 10.5, weight: isHot ? .semibold : .regular, design: .rounded).monospacedDigit())
                .foregroundStyle(isHot ? AnyShapeStyle(Dims.color(2)) : AnyShapeStyle(.secondary))
                .frame(width: 40, alignment: .trailing)
            if let b = r.b {
                Text(String(format: "%.2f", b))
                    .font(.system(size: 10.5, design: .rounded).monospacedDigit())
                    .foregroundStyle(SeriesColors.b)
                    .frame(width: 40, alignment: .trailing)
            }
        }
        .padding(.horizontal, 6)
        .padding(.vertical, 4)
        .background {
            if isHot {
                RoundedRectangle(cornerRadius: 6, style: .continuous)
                    .fill(Dims.color(2).opacity(0.10))
            }
        }
        .contentShape(Rectangle())
        .onHover { inside in
            withAnimation(Motion.quick) {
                if inside { hovering = r.name }
                else if hovering == r.name { hovering = nil }
            }
        }
        .help(r.name)
    }

    private var aboutCard: some View {
        VStack(alignment: .leading, spacing: 9) {
            SectionHeader(T("怎么读"))
            Text(T("原版方式下，每个维度是一列：8 种文本类型各一个带名字的点，A（和 B）用大号描边点标出。哪种类型的点在五列上都更靠近你的点，就是它。"))
                .font(.system(size: 11))
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
            Divider().opacity(0.35)
            HStack(spacing: 5) {
                Text(T("判定只用到 D1–D5")).font(.system(size: 10.5, weight: .medium))
                HelpDot(term: T("为什么不算 D6"),
                        plain: T("文本类型的质心只有 5 个维度，D6 不在里面——这是原版 calc_dimensions 的实现，不是漏了。"),
                        example: T("所以 D6 再高也不会改变文本类型判定。"))
            }
            Text(T("距离 = √Σ(Di − 质心i)²，与原版一致。D1 在图上除以 10 只是为了不被它的量级压扁其他维度，距离仍按原值算。"))
                .font(.system(size: 10))
                .foregroundStyle(.tertiary)
                .fixedSize(horizontal: false, vertical: true)
        }
        .frame(width: 300)
        .glassCard()
    }
}

// MARK: - 距离数据

struct TypeDistance: Identifiable {
    var id: String { name }
    var name: String
    var a: Double
    var b: Double?

    static func build(corpus: Corpus, compare: Corpus?) -> [TypeDistance] {
        let types = Catalog.shared.textTypes
        func dist(_ t: Centroid, _ c: Corpus) -> Double {
            var acc = 0.0
            for dim in 1...5 {
                let a = c.dims[dim] ?? 0
                let b = t.values[safe: dim - 1] ?? 0
                acc += (a - b) * (a - b)
            }
            return acc.squareRoot()
        }
        return types.map { t in
            TypeDistance(name: t.name, a: dist(t, corpus),
                         b: compare.map { dist(t, $0) })
        }
        .sorted { $0.a < $1.a }
    }
}
