import SwiftUI
import MATCore

// MARK: - 视觉系统
//
// 一套克制的深色/浅色双模语言：
// 玻璃卡片 + 极细描边 + 维度专属色 + 数字用等宽圆体。
// 所有颜色都走语义色，跟随系统外观，不硬编码黑白。

extension Color {
    init(hex: UInt32, opacity: Double = 1) {
        self.init(.sRGB,
                  red: Double((hex >> 16) & 0xFF) / 255,
                  green: Double((hex >> 8) & 0xFF) / 255,
                  blue: Double(hex & 0xFF) / 255,
                  opacity: opacity)
    }
}

enum Theme {
    static let radius: CGFloat = 18
    static let radiusSmall: CGFloat = 12

    /// 卡片描边：深色下用白 6%，浅色下用黑 5%
    static func hairline(_ scheme: ColorScheme) -> Color {
        scheme == .dark ? Color.white.opacity(0.07) : Color.black.opacity(0.06)
    }

    static let accent = Color(hex: 0x5B8CFF)

    /// 页面底色：窗口底色 + 两团很淡的维度色光晕
    static func canvas(_ scheme: ColorScheme) -> some View {
        ZStack {
            Rectangle().fill(Color(nsColor: .windowBackgroundColor))
            RadialGradient(colors: [Dims.meta(1).color.opacity(scheme == .dark ? 0.16 : 0.10), .clear],
                           center: .topLeading, startRadius: 0, endRadius: 620)
            RadialGradient(colors: [Dims.meta(5).color.opacity(scheme == .dark ? 0.14 : 0.08), .clear],
                           center: .bottomTrailing, startRadius: 0, endRadius: 720)
        }
        .ignoresSafeArea()
    }
}

// MARK: - 维度元数据

struct DimMeta: Identifiable, Hashable {
    let id: Int
    let zhTitle: String      // 中文一句话
    let english: String      // 原版标题
    let color: Color
    var label: String { "D\(id)" }

    /// 按当前语言给标题
    @MainActor var title: String {
        Localizer.shared.lang == .zh ? zhTitle : english
    }
}

enum Dims {
    static let all: [DimMeta] = [
        .init(id: 1, zhTitle: "互动性 vs 信息性", english: "Involved vs Informational Production",
              color: Color(hex: 0xFF7A59)),
        .init(id: 2, zhTitle: "叙事性", english: "Narrative vs Non-Narrative Concerns",
              color: Color(hex: 0xFFB020)),
        .init(id: 3, zhTitle: "显性 vs 情境依赖", english: "Explicit vs Situation-Dependent Reference",
              color: Color(hex: 0x2FCFB8)),
        .init(id: 4, zhTitle: "显性劝说", english: "Overt Expression of Persuasion",
              color: Color(hex: 0xA78BFA)),
        .init(id: 5, zhTitle: "抽象 vs 具体", english: "Abstract vs Non-Abstract Information",
              color: Color(hex: 0x4EA8FF)),
        .init(id: 6, zhTitle: "在线信息加工", english: "On-Line Informational Elaboration",
              color: Color(hex: 0xF472B6)),
    ]
    static func meta(_ i: Int) -> DimMeta { all[max(0, min(5, i - 1))] }
    static func color(_ i: Int) -> Color { meta(i).color }
}

// MARK: - 语料库名字的显示
//
// 图上的分类轴位置有限，语料库名要截断；完整名字放在悬停信息条、图例和表格里。

enum CorpusLabel {
    static func short(_ name: String, limit: Int = 12) -> String {
        name.count <= limit ? name : String(name.prefix(limit)) + "…"
    }
}

// MARK: - 参考体裁配色
//
// 8 个体裁各有一个固定颜色，跨图表、图例、表格都用同一个。
// 刻意用**低饱和**的色：参考数据是背景，语料的 A/B（珊瑚 / 天蓝，高饱和）必须压得住它们。

enum GenrePalette {
    /// 顺序与 Catalog.genres 一致
    static let names = ["Conversations", "Broadcasts", "Prepared speeches", "Personal letters",
                        "General fiction", "Press reportage", "Academic prose", "Official documents"]

    private static let colors: [Color] = [
        Color(hex: 0xD98C8C),   // 对话 · 砖红
        Color(hex: 0xD9A66B),   // 广播 · 赭橙
        Color(hex: 0xC2B45C),   // 演讲 · 芥黄
        Color(hex: 0x8FB573),   // 书信 · 草绿
        Color(hex: 0x6FA8A0),   // 小说 · 青瓷
        Color(hex: 0x7F9CC4),   // 新闻 · 雾蓝
        Color(hex: 0x9B8FC4),   // 学术 · 灰紫
        Color(hex: 0xB98BA6),   // 公文 · 藕荷
    ]

    static func color(index: Int) -> Color {
        colors[max(0, min(colors.count - 1, index))]
    }

    static func color(name: String) -> Color {
        if let i = names.firstIndex(of: name) { return color(index: i) }
        return .gray
    }

    static func index(of name: String) -> Int { names.firstIndex(of: name) ?? 0 }
}

// MARK: - 文本类型配色（8 种类型，避开会与语料 A/B 混淆的红与蓝）

enum TypePalette {
    private static let colors: [Color] = [
        Color(hex: 0xD98C8C), Color(hex: 0xE0A458), Color(hex: 0xB9A64A), Color(hex: 0x7FA86A),
        Color(hex: 0x5FA8A0), Color(hex: 0x8B7FC0), Color(hex: 0xC074A0), Color(hex: 0x8A8F98),
    ]
    static func color(_ i: Int) -> Color { colors[i % colors.count] }
    static func color(name: String) -> Color {
        let list = Catalog.shared.textTypes
        if let i = list.firstIndex(where: { $0.name == name }) { return color(i) }
        return .gray
    }
}

// MARK: - 文本类型中文名

enum TextTypes {
    static let zh: [String: String] = [
        "Intimate interpersonal interaction": "亲密人际互动",
        "Informational interaction": "信息性互动",
        "Scientific exposition": "科学说明",
        "Learned exposition": "学术说明",
        "Imaginative narrative": "想象叙事",
        "General narrative exposition": "一般叙事说明",
        "Situated reportage": "现场报道",
        "Involved persuasion": "介入性劝说",
    ]
    @MainActor static func name(_ en: String) -> String {
        Localizer.shared.lang == .zh ? (zh[en] ?? en) : en
    }

    /// 图里标签用的短名（8 个字以内）
    static let short: [String: String] = [
        "Intimate interpersonal interaction": "亲密人际",
        "Informational interaction": "信息互动",
        "Scientific exposition": "科学说明",
        "Learned exposition": "学术说明",
        "Imaginative narrative": "想象叙事",
        "General narrative exposition": "叙事说明",
        "Situated reportage": "现场报道",
        "Involved persuasion": "介入劝说",
    ]
    @MainActor static func brief(_ en: String) -> String {
        if Localizer.shared.lang == .zh { return short[en] ?? (zh[en] ?? en) }
        return shortEN[en] ?? en
    }

    static let shortEN: [String: String] = [
        "Intimate interpersonal interaction": "Intimate",
        "Informational interaction": "Info. interaction",
        "Scientific exposition": "Scientific",
        "Learned exposition": "Learned",
        "Imaginative narrative": "Imaginative",
        "General narrative exposition": "Gen. narrative",
        "Situated reportage": "Reportage",
        "Involved persuasion": "Persuasion",
    ]
}

// MARK: - 特征词典（中英对照 + 维度归属）

struct FeatureInfo {
    let id: String
    let gloss: String
    let dims: [Int]
    let positive: Bool       // 在该维度里是正向还是负向
}

enum Features {
    /// 维度公式里的正负项（来自 calc_dimensions.pl:184-205），用于筛选和着色
    static let d1p = ["[PRIV]", "[THATD]", "[CONT]", "VPRT", "SPP2", "[PROD]", "XX0", "DEMP",
                      "EMPH", "FPP1", "PIT", "[BEMA]", "CAUS", "DPAR", "INPR", "AMP", "POMD",
                      "ANDC", "[STPR]"]
    static let d1n = ["NN", "AWL", "PIN", "TTR", "JJ"]
    static let d2 = ["VBD", "TPP3", "[PEAS]", "[PUBV]", "SYNE", "[PRESP]"]
    static let d3p = ["[WHOBJ]", "[WHSUB]", "PHC", "NOMZ"]
    static let d3n = ["TIME", "PLACE", "RB"]
    static let d4 = ["TO", "PRMD", "[SUAV]", "COND", "NEMD", "[SPAU]"]
    static let d5 = ["CONJ", "[PASS]", "[WZPAST]", "OSUB"]
    static let d6 = ["THVC", "DEMO"]

    /// 中英对照。键必须和 biber-features.json 完全一致。
    static let gloss: [String: String] = [
        "AMP": "强调性副词", "ANDC": "句首并列", "[BEMA]": "存在性 be", "[BYPA]": "by 被动",
        "CAUS": "因果连词", "CONC": "让步连词", "COND": "条件连词", "CONJ": "连接副词",
        "[CONT]": "缩写", "DEMO": "指示代词", "DEMP": "指示代词 that", "DPAR": "话语小品词",
        "DWNT": "减弱性副词", "EMPH": "强调词", "EX": "存在句 there", "FPP1": "第一人称复数",
        "GER": "动名词", "HDG": "模糊限制语", "INPR": "不定代词", "JJ": "形容词", "NEMD": "必要性情态",
        "NN": "名词", "NOMZ": "名词化", "OSUB": "其他从属连词", "[PASS]": "被动语态",
        "[PASTP]": "过去分词从句", "[PEAS]": "现在完成时", "PHC": "短语并列", "PIN": "介词",
        "[PIRE]": "前置介词关系从句", "PIT": "代词 it", "PLACE": "地点副词", "POMD": "可能性情态",
        "PRED": "谓语形容词", "[PRESP]": "现在分词从句", "[PRIV]": "私动词", "PRMD": "预测性情态",
        "[PROD]": "代词 do", "[PUBV]": "公共动词", "RB": "副词", "[SERE]": "there 存在句",
        "[SMP]": "seem/appear", "[SPAU]": "劝说性动词", "[SPIN]": "分裂不定式", "SPP2": "第二人称",
        "[STPR]": "分裂助动词", "[SUAV]": "当然性动词", "SYNE": "分析型否定", "THAC": "that 形容词补语",
        "[THATD]": "that 从句作形容词", "THVC": "that 动词补语", "TIME": "时间副词", "TO": "不定式 to",
        "TOBJ": "that 作宾语", "TPP3": "第三人称", "TSUB": "that 作主语", "VBD": "过去时动词",
        "VPRT": "现在时动词", "[WHCL]": "wh 从句", "[WHOBJ]": "wh 作宾语", "[WHQU]": "wh 疑问句",
        "[WHSUB]": "wh 作主语", "[WZPAST]": "过去时 wh 从句", "[WZPRES]": "现在时 wh 从句",
        "XX0": "否定式", "AWL": "平均词长", "TTR": "类符形符比",
    ]

    /// 英文释义（Biber 的标准术语）
    static let glossEN: [String: String] = [
        "AMP": "Amplifiers", "ANDC": "Sentence-initial 'and'", "[BEMA]": "Existential 'be'",
        "[BYPA]": "By-passives", "CAUS": "Causal conjunctions", "CONC": "Concessive conjunctions",
        "COND": "Conditional conjunctions", "CONJ": "Conjuncts", "[CONT]": "Contractions",
        "DEMO": "Demonstratives", "DEMP": "Demonstrative 'that'", "DPAR": "Discourse particles",
        "DWNT": "Downtoners", "EMPH": "Emphatics", "EX": "Existential 'there'",
        "FPP1": "First-person plural", "GER": "Gerunds", "HDG": "Hedges",
        "INPR": "Indefinite pronouns", "JJ": "Adjectives", "NEMD": "Necessity modals",
        "NN": "Nouns", "NOMZ": "Nominalisations", "OSUB": "Other subordinators",
        "[PASS]": "Passives", "[PASTP]": "Past participial clauses", "[PEAS]": "Present perfect",
        "PHC": "Phrasal coordination", "PIN": "Prepositions", "[PIRE]": "Pied-piping relativisers",
        "PIT": "Pronoun 'it'", "PLACE": "Place adverbials", "POMD": "Possibility modals",
        "PRED": "Predicative adjectives", "[PRESP]": "Present participial clauses",
        "[PRIV]": "Private verbs", "PRMD": "Prediction modals", "[PROD]": "Pro-verb 'do'",
        "[PUBV]": "Public verbs", "RB": "Adverbs", "[SERE]": "Existential 'there'",
        "[SMP]": "'Seem' / 'appear'", "[SPAU]": "Suasive verbs", "[SPIN]": "Split infinitives",
        "SPP2": "Second-person pronouns", "[STPR]": "Split auxiliaries", "[SUAV]": "Suasive verbs",
        "SYNE": "Synthetic negation", "THAC": "That adjective complements",
        "[THATD]": "That relative clauses", "THVC": "That verb complements",
        "TIME": "Time adverbials", "TO": "Infinitives", "TOBJ": "That clauses as object",
        "TPP3": "Third-person pronouns", "TSUB": "That clauses as subject", "VBD": "Past tense verbs",
        "VPRT": "Present tense verbs", "[WHCL]": "Wh-clauses", "[WHOBJ]": "Wh-clauses as object",
        "[WHQU]": "Wh-questions", "[WHSUB]": "Wh-clauses as subject",
        "[WZPAST]": "Past wh-clauses", "[WZPRES]": "Present wh-clauses", "XX0": "Negation",
        "AWL": "Average word length", "TTR": "Type/token ratio",
    ]

    /// 按语言取释义（界面上唯一的入口）
    @MainActor static func glossText(_ id: String) -> String {
        if Localizer.shared.lang == .zh { return gloss[id] ?? id }
        return glossEN[id] ?? gloss[id] ?? id
    }

    static func info(_ id: String) -> FeatureInfo {
        var d: [(Int, Bool)] = []
        if d1p.contains(id) { d.append((1, true)) }
        if d1n.contains(id) { d.append((1, false)) }
        if d2.contains(id) { d.append((2, true)) }
        if d3p.contains(id) { d.append((3, true)) }
        if d3n.contains(id) { d.append((3, false)) }
        if d4.contains(id) { d.append((4, true)) }
        if d5.contains(id) { d.append((5, true)) }
        if d6.contains(id) { d.append((6, true)) }
        return FeatureInfo(id: id, gloss: gloss[id] ?? id,
                           dims: d.map(\.0), positive: d.first?.1 ?? true)
    }

    static func color(_ id: String) -> Color {
        let i = info(id)
        guard let d = i.dims.first else { return .secondary }
        return Dims.color(d)
    }

    /// UI 里按「维度 → 特征」分组时用的顺序
    static func grouped(_ ids: [String]) -> [(dim: Int, ids: [String])] {
        (1...6).map { d in
            (d, ids.filter { info($0).dims.contains(d) })
        }
    }
}

// MARK: - 通用修饰

struct GlassCard: ViewModifier {
    @Environment(\.colorScheme) private var scheme
    var padding: CGFloat = 16

    func body(content: Content) -> some View {
        content
            .padding(padding)
            .background {
                RoundedRectangle(cornerRadius: Theme.radius, style: .continuous)
                    .fill(.thinMaterial)
                    .overlay {
                        RoundedRectangle(cornerRadius: Theme.radius, style: .continuous)
                            .strokeBorder(Theme.hairline(scheme), lineWidth: 1)
                    }
            }
    }
}

extension View {
    func glassCard(padding: CGFloat = 16) -> some View { modifier(GlassCard(padding: padding)) }

    func monoNumber(_ size: CGFloat = 20, weight: Font.Weight = .semibold) -> some View {
        font(.system(size: size, weight: weight, design: .rounded).monospacedDigit())
    }
}

// MARK: - 动画曲线

enum Motion {
    static let snappy = Animation.spring(response: 0.36, dampingFraction: 0.82)
    static let soft = Animation.spring(response: 0.55, dampingFraction: 0.9)
    static let quick = Animation.easeOut(duration: 0.18)
}
