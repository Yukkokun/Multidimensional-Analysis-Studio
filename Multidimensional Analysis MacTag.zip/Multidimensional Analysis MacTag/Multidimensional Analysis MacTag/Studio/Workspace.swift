import SwiftUI
import Observation
import MATCore

// MARK: - 运行设置（对应 MAT 主界面的三个开关）

struct RunSettings: Equatable, Sendable {
    var ttrWindow: Int = 400
    var clamp: Bool = true          // Zscore correction
    var allTags: Bool = false       // Count: All tags vs Only VASW

    @MainActor var summary: String {
        var parts = ["TTR \(ttrWindow)"]
        parts.append(T(clamp ? "z 校正开" : "z 校正关"))
        parts.append(T(allTags ? "全部词性" : "Biber 特征"))
        return parts.joined(separator: " · ")
    }
}

// MARK: - 引擎状态

struct EngineStatus: Equatable {
    var vendor: URL?
    var java: URL?
    var jar: URL?
    var model: URL?
    var problem: String?

    var isReady: Bool { java != nil && jar != nil && model != nil }

    @MainActor var badge: String {
        if isReady { return T("引擎就绪") }
        if java == nil && jar == nil { return T("引擎未配置") }
        return T("引擎不完整")
    }

    static func detect() -> EngineStatus {
        var s = EngineStatus()
        let fm = FileManager.default

        // 1) vendor 目录
        var candidates: [URL] = []
        if let p = UserDefaults.standard.string(forKey: "MATVendorPath"), !p.isEmpty {
            candidates.append(URL(fileURLWithPath: p))
        }
        if let p = ProcessInfo.processInfo.environment["MAT_VENDOR"], !p.isEmpty {
            candidates.append(URL(fileURLWithPath: p))
        }
        if let r = Bundle.main.resourceURL {
            candidates.append(r.appendingPathComponent("Vendor/Tagging"))
        }
        #if DEBUG
        candidates.append(URL(fileURLWithPath:
            "/Volumes/ML.Origin/xcode project/multidimensional analysis tagger Remaster/Vendor/Tagging"))
        #endif
        // 从 app 位置向上找仓库
        var up = Bundle.main.bundleURL
        for _ in 0..<6 {
            up.deleteLastPathComponent()
            candidates.append(up.appendingPathComponent("Vendor/Tagging"))
        }
        s.vendor = candidates.first { fm.fileExists(atPath: $0.appendingPathComponent("stanford-postagger.jar").path) }

        // 2) jar / 模型
        if let v = s.vendor {
            let jar = v.appendingPathComponent("stanford-postagger.jar")
            if fm.fileExists(atPath: jar.path) { s.jar = jar }
            let models = (try? fm.contentsOfDirectory(at: v.appendingPathComponent("models"),
                                                      includingPropertiesForKeys: nil)) ?? []
            let taggers = models.filter { $0.pathExtension == "tagger" }
            s.model = taggers.first { $0.lastPathComponent == "left3words-wsj-0-18.tagger" }
                ?? taggers.first { $0.lastPathComponent.contains("wsj") }
                ?? taggers.sorted { $0.lastPathComponent < $1.lastPathComponent }.first
        }

        // 3) java（试跑验证，能识别 macOS 的假 shim）
        s.java = JavaLocator.locate()

        if s.vendor == nil { s.problem = "找不到 stanford-postagger.jar 与模型文件" }
        else if s.model == nil { s.problem = "models/ 里没有 .tagger 模型" }
        else if s.java == nil { s.problem = "没有可用的 Java 运行时" }
        return s
    }

    /// 只做离线分析时（文件已是 MAT 标注格式）不需要 java
    var canAnalyzeTaggedOnly: Bool { true }
}

// MARK: - 语料库

struct Corpus: Identifiable, Sendable {
    let id = UUID()
    var name: String
    var folder: URL?
    var result: AnalysisResult
    var settings: RunSettings
    var createdAt = Date()

    var documents: [DocumentResult] { result.documents }
    var tokens: Int { documents.reduce(0) { $0 + $1.tokens } }
    var textType: String { result.corpusTextType ?? documents.first?.textType ?? "—" }

    /// 语料级维度分：优先用 MAT 的 corpusDims（先平均 z 再求和），否则退化为单文档
    var dims: [Int: Double] {
        if let c = result.corpusDims { return c }
        return documents.first?.dims ?? [:]
    }

    func value(_ metric: Metric) -> Double {
        switch metric {
        case .dimension(let d):
            return dims[d] ?? 0
        case .feature(let f):
            if f == "AWL" { return result.corpusAWL ?? documents.first?.awl ?? 0 }
            if f == "TTR" { return result.corpusTypes ?? Double(documents.first?.types ?? 0) }
            let vals = documents.map { $0.freq[f] ?? 0 }
            return vals.isEmpty ? 0 : vals.reduce(0, +) / Double(vals.count)
        }
    }

    func value(_ metric: Metric, document name: String) -> Double {
        guard let doc = documents.first(where: { $0.name == name }) else { return value(metric) }
        switch metric {
        case .dimension(let d): return doc.dims[d] ?? 0
        case .feature(let f):
            if f == "AWL" { return doc.awl }
            if f == "TTR" { return Double(doc.types) }
            return doc.freq[f] ?? 0
        }
    }

    /// 某个指标在「各文档」上的取值序列（分布图与检验的输入）
    func samples(_ metric: Metric) -> [Double] {
        documents.map { doc in
            switch metric {
            case .dimension(let d): return doc.dims[d] ?? 0
            case .feature(let f):
                if f == "AWL" { return doc.awl }
                if f == "TTR" { return Double(doc.types) }
                return doc.freq[f] ?? 0
            }
        }
    }
}

// MARK: - 指标

enum Metric: Hashable, Identifiable, Sendable {
    case dimension(Int)
    case feature(String)

    var id: String {
        switch self {
        case .dimension(let d): return "D\(d)"
        case .feature(let f): return f
        }
    }
    @MainActor var title: String {
        switch self {
        case .dimension(let d): return "D\(d) · \(Dims.meta(d).title)"
        case .feature(let f): return f == "AWL" || f == "TTR" ? f : "\(f) · \(Features.glossText(f))"
        }
    }
    var short: String {
        switch self {
        case .dimension(let d): return "D\(d)"
        case .feature(let f): return f
        }
    }
    var color: Color {
        switch self {
        case .dimension(let d): return Dims.color(d)
        case .feature(let f): return Features.color(f)
        }
    }
    /// 维度分是标准分，特征频次是每百词
    var unit: String {
        switch self {
        case .dimension: return ""
        case .feature(let f): return (f == "AWL" || f == "TTR") ? "" : "每百词"
        }
    }
}

// MARK: - 工作区

@MainActor
@Observable
final class Workspace {

    struct Progress: Equatable {
        var done: Int = 0
        var total: Int = 1
        /// 中文模板，用 %@ 占位，显示时按当前语言翻译再填 args
        var label: String = ""
        var args: [String] = []
        var fraction: Double { total > 0 ? min(1, Double(done) / Double(total)) : 0 }
    }

    struct Banner: Identifiable, Equatable {
        let id = UUID()
        var title: String
        var message: String
        var isError: Bool = true
    }

    enum Tab: String, CaseIterable, Identifiable {
        case overview = "概览"
        case dimensions = "维度"
        case sixDim = "六维"
        case textType = "文本类型"
        case features = "特征"
        case distribution = "分布"
        case compare = "对比"
        case zcompare = "Z 对比"

        var id: String { rawValue }

        @MainActor var title: String {
            if self == .dimensions && Localizer.shared.lang == .en { return "Dimensions" }
            return T(rawValue)
        }

        var icon: String {
            switch self {
            case .overview: return "square.grid.2x2"
            case .dimensions: return "chart.bar.xaxis"
            case .sixDim: return "chart.bar.horizontal.page"
            case .textType: return "point.3.connected.trianglepath.dotted"
            case .features: return "list.bullet.rectangle"
            case .distribution: return "waveform.path.ecg"
            case .compare: return "arrow.left.arrow.right"
            case .zcompare: return "chart.dots.scatter"
            }
        }
    }

    enum ChartStyle: String, CaseIterable, Identifiable {
        case legacy = "原版风格"
        case horizontal = "横向柱状图"
        var id: String { rawValue }
        @MainActor var title: String { T(rawValue) }
    }

    init() {
        // 开发期方便截图：MAT_DEMO=1 启动即载入示例语料
        // 开发期截图/演示用：环境变量或 UserDefaults 都能触发
        let env = ProcessInfo.processInfo.environment
        let ud = UserDefaults.standard
        let tabKey = env["MAT_TAB"] ?? ud.string(forKey: "DemoTab")
        if let t = tabKey {
            let mapped: Tab? = Tab(rawValue: t) ?? [
                "overview": .overview, "dimensions": .dimensions, "sixdim": .sixDim,
                "texttype": .textType, "features": .features,
                "distribution": .distribution, "compare": .compare, "zcompare": .zcompare][t]
            if let mapped { self.tab = mapped }
        }
        if let st = env["MAT_STYLE"], st.contains("bar") || st == "horizontal" {
            self.chartStyle = .horizontal
        }
        // 截图用：启动即打开某个 Help 窗口
        if let want = env["MAT_SHEET"], let sheet = HelpSheet(rawValue: want) {
            Task { @MainActor in
                try? await Task.sleep(nanoseconds: 900_000_000)
                self.helpSheet = sheet
            }
        }
        let demo = env["MAT_DEMO"] ?? (ud.bool(forKey: "DemoLoad") ? "1" : nil)
        if demo == "1" || demo == "2" {
            Task { @MainActor in
                try? await Task.sleep(nanoseconds: 400_000_000)
                loadDemo()
                if ProcessInfo.processInfo.environment["MAT_EXPORT"] == "1" {
                    try? await Task.sleep(nanoseconds: 3_000_000_000)
                    let dir = URL(fileURLWithPath: "/tmp/matexport")
                    ExportService.writeDimensions(self, style: .legacy, to: dir)
                    ExportService.writeDimensions(self, style: .horizontal, to: dir)
                    ExportService.writeTextType(self, to: dir.appendingPathComponent("TextTypes.png"))
                    FileHandle.standardError.write(Data("exported to \(dir.path)\n".utf8))
                }
                if demo == "2" {
                    try? await Task.sleep(nanoseconds: 12_000_000_000)
                    let second = URL(fileURLWithPath: "/tmp/matdemo/bulk")
                    if FileManager.default.fileExists(atPath: second.path) { importItems([second]) }
                }
            }
        }
    }

    var corpora: [Corpus] = []
    var selection: Corpus.ID?
    var tab: Tab = .overview
    var chartStyle: ChartStyle = .legacy
    var settings = RunSettings()
    var engine = EngineStatus.detect()
    var isRunning = false
    var progress: Progress?
    var banner: Banner?
    var showEngineSheet = false
    var helpSheet: HelpSheet?
    var selectedDocument: String?          // nil = 语料整体
    var compareLeft: Corpus.ID?
    var compareRight: Corpus.ID?
    /// 维度图里叠加的对比语料（nil = 只看一个）
    var dimCompareID: Corpus.ID?

    // 跨标签页的选中状态
    var selectedDim: Int = 1
    var textTypeStyle: TextTypeStyle = .original
    var selectedFeature: String = "NN"
    var distributionMetric: Metric = .dimension(1)
    var compareMetric: Metric = .dimension(1)
    var showDensity = true
    var showNormalCurve = true
    var showQQ = false

    // 当前选中的语料
    var current: Corpus? {
        guard let selection else { return corpora.first }
        return corpora.first { $0.id == selection } ?? corpora.first
    }

    // MARK: 示例语料

    /// 仓库里自带的 10 篇 GroundTruth 语料（开发/试用用；正式版应打进 bundle）
    static func demoCorpus() -> URL? {
        let fm = FileManager.default
        var candidates: [URL] = []
        if let d = ProcessInfo.processInfo.environment["MAT_DEMO_DIR"] {
            candidates.append(URL(fileURLWithPath: d))
        }
        candidates.append(URL(fileURLWithPath: "/tmp/matdemo/GroundTruth"))
        if let d = ProcessInfo.processInfo.environment["MAT_DEMO_DIR"] {
            candidates.append(URL(fileURLWithPath: d))
        }
        candidates.append(URL(fileURLWithPath: "/tmp/matdemo/GroundTruth"))
        if let r = Bundle.main.resourceURL { candidates.append(r.appendingPathComponent("SampleCorpus")) }
        #if DEBUG
        candidates.append(URL(fileURLWithPath:
            "/Volumes/ML.Origin/xcode project/multidimensional analysis tagger Remaster/Corpus/GroundTruth"))
        #endif
        var up = Bundle.main.bundleURL
        for _ in 0..<6 {
            up.deleteLastPathComponent()
            candidates.append(up.appendingPathComponent("Corpus/GroundTruth"))
        }
        return candidates.first { fm.fileExists(atPath: $0.path) }
    }

    func loadDemo() {
        guard let dir = Self.demoCorpus() else {
            banner = Banner(title: "找不到示例语料",
                            message: "示例语料在仓库的 Corpus/GroundTruth。你也可以直接拖入自己的 .txt。")
            return
        }
        importItems([dir])
    }
    // MARK: 导入

    func importItems(_ urls: [URL]) {
        let files = Self.expand(urls)
        guard !files.isEmpty else {
            banner = Banner(title: "没有可分析的文本",
                            message: "只支持纯文本 .txt。MAT 只接受这个格式，其它文件会被忽略。")
            return
        }
        let name = Self.corpusName(for: urls, files: files)
        run(files: files, name: name)
    }

    static func expand(_ urls: [URL]) -> [URL] {
        var out: [URL] = []
        let fm = FileManager.default
        for url in urls {
            var isDir: ObjCBool = false
            guard fm.fileExists(atPath: url.path, isDirectory: &isDir) else { continue }
            if isDir.boolValue {
                let items = (try? fm.contentsOfDirectory(at: url, includingPropertiesForKeys: nil)) ?? []
                out += items
                    .filter { $0.pathExtension.lowercased() == "txt" }
                    .sorted { $0.lastPathComponent < $1.lastPathComponent }
            } else if url.pathExtension.lowercased() == "txt" {
                out.append(url)
            }
        }
        // 去重 + 稳定排序（行序必须可复现，和 MAT 一致）
        var seen = Set<String>()
        return out.filter { seen.insert($0.standardizedFileURL.path).inserted }
                  .sorted { $0.lastPathComponent < $1.lastPathComponent }
    }

    static func corpusName(for urls: [URL], files: [URL]) -> String {
        if urls.count == 1, let first = urls.first {
            var isDir: ObjCBool = false
            FileManager.default.fileExists(atPath: first.path, isDirectory: &isDir)
            if isDir.boolValue { return first.lastPathComponent }
            return first.deletingPathExtension().lastPathComponent + "（单篇）"
        }
        if let parent = files.first?.deletingLastPathComponent().lastPathComponent, !parent.isEmpty {
            return parent
        }
        return "未命名语料"
    }

    // MARK: 跑分析

    func run(files: [URL], name: String) {
        guard !isRunning else { return }
        isRunning = true
        progress = Progress(done: 0, total: 2, label: "读取文本…")
        selectedDocument = nil

        let s = settings
        let e = engine
        let corpusName = name

        Task {
            do {
                let docs = try await Self.prepare(files: files, name: corpusName,
                                                  settings: s, engine: e) { done, total, label, args in
                    Task { @MainActor in
                        self.progress = Progress(done: done, total: total, label: label, args: args)
                    }
                }
                // 分析（CPU 密集但很快，放到后台）
                let analyzer = Analyzer()
                let result = await Task.detached(priority: .userInitiated) {
                    analyzer.analyze(docs, corpusName: corpusName,
                                     ttrWindow: s.ttrWindow, clamp: s.clamp)
                }.value

                let corpus = Corpus(name: corpusName, folder: files.first?.deletingLastPathComponent(),
                                    result: result, settings: s)
                withAnimation(Motion.soft) {
                    corpora.insert(corpus, at: 0)
                    selection = corpus.id
                    if compareLeft == nil { compareLeft = corpus.id }
                    else if compareRight == nil { compareRight = corpus.id }
                    if ProcessInfo.processInfo.environment["MAT_TAB"] == nil { tab = .overview }
                    if ProcessInfo.processInfo.environment["MAT_DIMCOMPARE"] == "1",
                       corpora.count >= 2 {
                        dimCompareID = corpora.last?.id
                    }
                    isRunning = false
                    progress = nil
                }
            } catch {
                withAnimation(Motion.snappy) {
                    isRunning = false
                    progress = nil
                    banner = Banner(title: "分析失败", message: Self.describe(error))
                }
            }
        }
    }

    nonisolated static func prepare(
        files: [URL], name: String, settings: RunSettings, engine: EngineStatus,
        progress: @escaping @Sendable (Int, Int, String, [String]) -> Void
    ) async throws -> [(name: String, tokens: [Token])] {

        progress(0, max(files.count, 1), "读取 %@ 个文件…", ["\(files.count)"])
        var texts: [(name: String, text: String)] = []
        var tagged: [(name: String, tokens: [Token])] = []

        for (i, url) in files.enumerated() {
            let scoped = url.startAccessingSecurityScopedResource()
            defer { if scoped { url.stopAccessingSecurityScopedResource() } }
            guard let raw = try? String(contentsOf: url, encoding: .utf8) else {
                throw StudioError.unreadable(url.lastPathComponent)
            }
            let base = url.deletingPathExtension().lastPathComponent
            if looksTagged(raw) {
                let toks = Token.parseStream(raw).map { Token(surface: $0.surface, tag: $0.tag) }
                tagged.append((base, toks))
            } else {
                texts.append((base, TextPreparer.normalize(raw)))
            }
            progress(i + 1, files.count, "读取 %@…", [base])
        }

        var docs: [(name: String, tokens: [Token])] = tagged

        if !texts.isEmpty {
            guard let java = engine.java, let jar = engine.jar, let model = engine.model else {
                throw StudioError.engineNotReady(engine.problem ?? "缺少 Java / jar / 模型")
            }
            let config = TaggerConfig(javaExecutable: java, classPath: [jar], model: model)
            let tagger = try StanfordTagger(config: config)
            let taggedDocs = try await tagger.tag(texts) { done, total in
                progress(done, total, "Stanford 标注 %@/%@", ["\(done)", "\(total)"])
            }
            for d in taggedDocs {
                let toks = d.lines.flatMap { line in
                    line.map { Token(surface: $0.surface, tag: $0.tag) }
                }
                docs.append((d.name, toks))
            }
        }
        progress(files.count, files.count, "计算特征…", [])
        return docs.sorted { $0.name < $1.name }
    }

    /// 判断一个 .txt 是不是已经标注过（`word_TAG` 形态）
    nonisolated static func looksTagged(_ text: String) -> Bool {
        let tokens = text.split(whereSeparator: { $0 == " " || $0 == "\n" || $0 == "\r" })
            .prefix(120)
        guard !tokens.isEmpty else { return false }
        var hits = 0
        for t in tokens {
            if let us = t.lastIndex(of: "_"), us != t.startIndex {
                let tag = t[t.index(after: us)...]
                if let f = tag.first, f.isUppercase || f == "." || f == "," || f == "$" || f == ":" {
                    if tag.count <= 5 { hits += 1 }
                }
            }
        }
        return Double(hits) / Double(tokens.count) > 0.6
    }

    nonisolated static func describe(_ error: Error) -> String {
        if let e = error as? StudioError { return e.message }
        if let e = error as? TaggingError { return e.description }
        return error.localizedDescription
    }

    func remove(_ corpus: Corpus) {
        withAnimation(Motion.snappy) {
            corpora.removeAll { $0.id == corpus.id }
            if selection == corpus.id { selection = corpora.first?.id }
        }
    }
}

enum StudioError: Error {
    case unreadable(String)
    case engineNotReady(String)

    var message: String {
        switch self {
        case .unreadable(let f):
            return "读不了「\(f)」。MAT 只接受 UTF-8 / ANSI 纯文本。"
        case .engineNotReady(let why):
            return "标注引擎没准备好：\(why)。可以在「引擎」里指定 Vendor 目录，或直接导入已经标注好的文件。"
        }
    }
}
