import SwiftUI
import AppKit
import UniformTypeIdentifiers
import MATCore

// MARK: - Z 分数对比（按六个维度的特征构成分组）

@MainActor
struct ZCompareView: View {
    @Environment(Workspace.self) private var ws

    /// 多重比较校正方式
    enum Correction: String, CaseIterable, Identifiable {
        case bh = "BH-FDR"
        case holm = "Holm"
        case none = "不校正"
        @MainActor var title: String { T(rawValue) }
        @MainActor var label: String { rawValue }
        var id: String { rawValue }
        var short: String { self == .none ? "p" : "q" }
        var help: String {
            switch self {
            case .bh: return "控制「假阳性的比例」。65 个检验里允许约 5% 的显著结果是假的，功效比 Holm 高。"
            case .holm: return "控制「至少出现一次假阳性」的概率，比 BH 保守，审稿人更认。"
            case .none: return "不校正，直接看 p。只适合预先指定了少数几个变量的探索。"
            }
        }
    }

    @State private var selectedDims: Set<Int> = [1, 2, 3, 4, 5, 6]
    @State private var onlySignificant = false
    @State private var correction: Correction = .bh
    @State private var sortByDelta = true
    /// 只影响显示：被用户从表里移除的变量
    @State private var hidden: Set<String> = []

    private var left: Corpus? { ws.corpora.first { $0.id == ws.compareLeft } ?? ws.corpora.first }
    private var right: Corpus? {
        let c = ws.corpora.first { $0.id == ws.compareRight }
        if let c, c.id != left?.id { return c }
        return ws.corpora.first { $0.id != left?.id }
    }

    /// 可以对比的变量：65 个 Biber 特征 + AWL/TTR。
    /// `Count: All tags` 多出来的普通词性没有 z 分数（z 需要 Biber 的 mean/sd），所以不在表里。
    private var allFeatures: [String] { Catalog.shared.featureOrder + ["AWL", "TTR"] }

    private struct Row: Identifiable {
        var id: String { feature }
        var feature: String
        var dim: Int
        var positive: Bool
        var aMean: Double
        var bMean: Double
        var tP: Double?
        var tQ: Double
        var uP: Double?
        var uQ: Double
        var delta: Double { aMean - bMean }
    }

    private struct DimBlock: Identifiable {
        var id: Int
        var rows: [Row]
        var significant: Int
        var hiddenCount: Int
    }

    // MARK: 计算

    private func buildBlocks() -> [DimBlock] {
        guard let a = left, let b = right else { return [] }

        // 先算全部，再统一校正 —— 多重比较必须按「一族」校正，不能按维度分开
        var raw: [(feature: String, dim: Int, pos: Bool, a: Double, b: Double, tP: Double?, uP: Double?)] = []
        for f in allFeatures {
            let za = a.documents.map { $0.z[f] ?? 0 }
            let zb = b.documents.map { $0.z[f] ?? 0 }
            let t = Stats.welchT(za, zb)
            let u = Stats.mannWhitneyU(za, zb)
            let info = Features.info(f)
            raw.append((f, info.dims.first ?? 1, info.positive,
                        Stats.describe(za).mean, Stats.describe(zb).mean, t?.p, u?.p))
        }

        let tp = raw.map { $0.tP ?? 1 }
        let up = raw.map { $0.uP ?? 1 }
        let tQs: [Double]
        let uQs: [Double]
        switch correction {
        case .bh:
            tQs = Stats.benjaminiHochberg(tp)
            uQs = Stats.benjaminiHochberg(up)
        case .holm:
            tQs = Stats.holm(tp)
            uQs = Stats.holm(up)
        case .none:
            tQs = tp
            uQs = up
        }

        var rows: [Row] = []
        for (i, r) in raw.enumerated() {
            rows.append(Row(feature: r.feature, dim: r.dim, positive: r.pos,
                            aMean: r.a, bMean: r.b, tP: r.tP, tQ: tQs[i], uP: r.uP, uQ: uQs[i]))
        }

        var blocks: [DimBlock] = []
        for d in 1...6 where selectedDims.contains(d) {
            let allInDim = rows.filter { $0.dim == d }
            var visible = allInDim.filter { !hidden.contains($0.feature) }
            if onlySignificant { visible = visible.filter { isSignificant($0) } }
            if sortByDelta {
                visible.sort { abs($0.delta) > abs($1.delta) }
            } else {
                visible.sort { $0.tQ < $1.tQ }
            }
            blocks.append(DimBlock(id: d, rows: visible,
                                   significant: visible.filter { isSignificant($0) }.count,
                                   hiddenCount: allInDim.filter { hidden.contains($0.feature) }.count))
        }
        return blocks
    }

    private func isSignificant(_ r: Row) -> Bool {
        if correction == .none { return (r.tP ?? 1) < 0.05 || (r.uP ?? 1) < 0.05 }
        return min(r.tQ, r.uQ) < 0.05
    }

    private func verdict(_ r: Row) -> (String, Color) {
        let tv = correction == .none ? (r.tP ?? 1) : r.tQ
        let uv = correction == .none ? (r.uP ?? 1) : r.uQ
        switch (tv < 0.05, uv < 0.05) {
        case (true, true): return ("都显著", Dims.color(1))
        case (true, false): return ("仅 t", Dims.color(5))
        case (false, true): return ("仅 U", Dims.color(2))
        case (false, false): return ("无差异", .secondary)
        }
    }

    // MARK: 视图

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            if ws.corpora.count < 2 {
                EmptyHint(icon: "chart.dots.scatter",
                          title: T("需要两个语料库"),
                          message: T("再导入一个语料库，就能逐个特征比较 z 分数。\n每个语料库至少 4 篇，检验才有意义。"))
            } else if let a = left, let b = right {
                controls(a, b)
                summary(a, b)
                if !hidden.isEmpty { hiddenBar }
                ForEach(buildBlocks()) { block in
                    blockCard(block, a: a, b: b)
                }
                footnote
            }
        }
    }

    // MARK: 控制

    private func controls(_ a: Corpus, _ b: Corpus) -> some View {
        @Bindable var ws = ws
        return VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 10) {
                corpusMenu(slot: "A", selection: $ws.compareLeft, fallback: a, color: SeriesColors.a)
                Image(systemName: "arrow.left.arrow.right")
                    .font(.system(size: 11, weight: .semibold)).foregroundStyle(.tertiary)
                corpusMenu(slot: "B", selection: $ws.compareRight, fallback: b, color: SeriesColors.b)

                Divider().frame(height: 18)

                HStack(spacing: 3) {
                    Picker("", selection: $correction) {
                        ForEach(Correction.allCases) { c in Text(c.title).tag(c) }
                    }
                    .pickerStyle(.menu)
                    .labelsHidden()
                    .frame(width: 104)
                    .controlSize(.small)
                    HelpDot(term: T("多重比较校正"),
                            plain: T("一次测几十个变量，纯靠 p<0.05 会凭空冒出几个「显著」。校正就是把门槛收紧：BH 控制假阳性比例，Holm 控制「至少错一次」的概率。"),
                            example: T("65 个变量里，BH 后 q<0.05 的通常比未校正少三分之一到一半。"),
                            width: 300)
                }

                Toggle(isOn: $onlySignificant) {
                    Text(T("只看显著")).font(.system(size: 11))
                }
                .toggleStyle(.switch).controlSize(.mini)

                Toggle(isOn: $sortByDelta) {
                    Text(T("按差值排序")).font(.system(size: 11))
                }
                .toggleStyle(.switch).controlSize(.mini)

                Spacer()

                Button {
                    exportCSV(a, b)
                } label: {
                    Label(T("导出全部 CSV…"), systemImage: "square.and.arrow.down")
                        .font(.system(size: 11))
                }
                .controlSize(.small)
            }

            HStack(spacing: 6) {
                Text(T("维度")).font(.system(size: 10)).foregroundStyle(.tertiary)
                ForEach(Dims.all) { m in
                    Chip(text: "D\(m.id) \(m.title)", isOn: selectedDims.contains(m.id), tint: m.color) {
                        if selectedDims.contains(m.id) { selectedDims.remove(m.id) }
                        else { selectedDims.insert(m.id) }
                    }
                }
                Spacer()
            }
        }
    }

    /// 语料选择器：A/B 槽位用颜色点标出，右边是原生 Picker（一定显示当前选中的语料名）
    private func corpusMenu(slot: String, selection: Binding<Corpus.ID?>,
                            fallback: Corpus, color: Color) -> some View {
        let current = selection.wrappedValue.flatMap { id in ws.corpora.first { $0.id == id } } ?? fallback
        return HStack(spacing: 5) {
            Text(slot)
                .font(.system(size: 9, weight: .bold, design: .rounded))
                .foregroundStyle(.white)
                .frame(width: 14, height: 14)
                .background { Circle().fill(color) }

            Picker("", selection: selection) {
                ForEach(ws.corpora) { c in
                    Text(c.name).tag(Optional(c.id))
                }
            }
            .labelsHidden()
            .pickerStyle(.menu)
            .controlSize(.small)
            .frame(width: 132)

            Text(T("%@ 篇", current.documents.count))
                .font(.system(size: 9.5, design: .rounded))
                .foregroundStyle(.tertiary)
        }
        .padding(.horizontal, 7)
        .padding(.vertical, 3)
        .background {
            Capsule().fill(color.opacity(0.10))
                .overlay { Capsule().strokeBorder(color.opacity(0.30), lineWidth: 1) }
        }
    }

    // MARK: 概览

    private func summary(_ a: Corpus, _ b: Corpus) -> some View {
        let blocks = buildBlocks()
        let total = blocks.reduce(0) { $0 + $1.rows.count }
        let sig = blocks.reduce(0) { $0 + $1.significant }
        return HStack(spacing: 12) {
            StatTile(label: T("参与比较的变量"), value: Double(total), decimals: 0,
                     tint: Theme.accent, icon: "list.number")
            StatTile(label: T(correction == .none ? "显著（p < 0.05）" : "显著（q < 0.05）"),
                     value: Double(sig), decimals: 0,
                     tint: sig > 0 ? Dims.color(1) : .secondary, icon: "checkmark.seal")
            VStack(alignment: .leading, spacing: 6) {
                HStack(spacing: 5) {
                    Circle().fill(SeriesColors.a).frame(width: 6, height: 6)
                    Text(T("A / B 篇数")).font(.system(size: 10.5, weight: .medium)).foregroundStyle(.secondary)
                }
                HStack(alignment: .firstTextBaseline, spacing: 4) {
                    Text("\(a.documents.count)")
                        .font(.system(size: 22, weight: .semibold, design: .rounded).monospacedDigit())
                        .foregroundStyle(SeriesColors.a)
                    Text("/").font(.system(size: 14)).foregroundStyle(.tertiary)
                    Text("\(b.documents.count)")
                        .font(.system(size: 22, weight: .semibold, design: .rounded).monospacedDigit())
                        .foregroundStyle(SeriesColors.b)
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .glassCard(padding: 13)

            VStack(alignment: .leading, spacing: 6) {
                Text(T("校正方式")).font(.system(size: 10.5, weight: .medium))
                    .foregroundStyle(.secondary).textCase(.uppercase).kerning(0.4)
                Text(correction.title).font(.system(size: 15, weight: .semibold, design: .rounded))
                Text(T(correction == .none ? "未校正，仅供探索" : "65 个检验作为一族"))
                    .font(.system(size: 10)).foregroundStyle(.tertiary)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .glassCard(padding: 13)
        }
    }

    private var hiddenBar: some View {
        HStack(spacing: 8) {
            Image(systemName: "eye.slash")
                .font(.system(size: 10)).foregroundStyle(.tertiary)
            Text(T("已隐藏 %@ 个变量（只影响显示，不影响统计）", hidden.count))
                .font(.system(size: 10.5)).foregroundStyle(.secondary)
            Button(T("全部恢复")) {
                withAnimation(Motion.snappy) { hidden.removeAll() }
            }
            .buttonStyle(.link)
            .font(.system(size: 10.5))
            Spacer()
        }
        .padding(.horizontal, 4)
    }

    // MARK: 每个维度一块

    private func blockCard(_ block: DimBlock, a: Corpus, b: Corpus) -> some View {
        let meta = Dims.meta(block.id)
        let header = [T("特征"), T("说明"), T("方向"), "A z", "B z", "Δ", "t \(correction.short)", "U \(correction.short)", T("判定")]
        let tsv: [[String]] = block.rows.map { r in
            [r.feature, Features.glossText(r.feature), r.positive ? "+" : "−",
             String(format: "%.2f", r.aMean), String(format: "%.2f", r.bMean),
             String(format: "%+.2f", r.delta),
             String(format: "%.4f", correction == .none ? (r.tP ?? 1) : r.tQ),
             String(format: "%.4f", correction == .none ? (r.uP ?? 1) : r.uQ),
             verdict(r).0]
        }

        return VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 8) {
                Text(meta.label)
                    .font(.system(size: 10, weight: .bold, design: .rounded))
                    .padding(.horizontal, 6).padding(.vertical, 2.5)
                    .background { Capsule().fill(meta.color.opacity(0.18)) }
                    .foregroundStyle(meta.color)
                Text(meta.title).font(.system(size: 12.5, weight: .semibold))
                Text(T("%@ 个变量 · %@ 个显著", block.rows.count, block.significant)
                     + (block.hiddenCount > 0 ? T(" · 隐藏 %@", block.hiddenCount) : ""))
                    .font(.system(size: 10)).foregroundStyle(.tertiary)
                Spacer()
                if !block.rows.isEmpty {
                    IconAction(systemName: "doc.on.doc",
                               help: T("复制这个维度（Tab 分隔，可直接粘进 Excel）")) {
                        TableExport.copyTSV([header] + tsv)
                    }
                    IconAction(systemName: "square.and.arrow.up", help: T("导出这个维度为图片…")) {
                        TableExport.askAndExport(
                            title: "D\(block.id) · \(meta.title)",
                            subtitle: T("A · %@（%@ 篇） vs B · %@（%@ 篇）· %@", a.name, a.documents.count, b.name, b.documents.count, correction.rawValue),
                            header: header, rows: tsv)
                    }
                }
            }

            if block.rows.isEmpty {
                Text(T(hidden.isEmpty ? "这个维度没有变量" : "这个维度的变量都被隐藏了"))
                    .font(.system(size: 10.5)).foregroundStyle(.tertiary)
                    .padding(.vertical, 6)
            } else {
                Grid(alignment: .leading, horizontalSpacing: 10, verticalSpacing: 5) {
                    GridRow {
                        Text(T("特征")).frame(width: 132, alignment: .leading)
                        Text(T("说明")).frame(width: 78, alignment: .leading)
                        Text("A z").gridColumnAlignment(.trailing).frame(width: 52)
                        Text("B z").gridColumnAlignment(.trailing).frame(width: 52)
                        Text("Δ").gridColumnAlignment(.trailing).frame(width: 52)
                        Text("t \(correction.short)").gridColumnAlignment(.trailing).frame(width: 54)
                        Text("U \(correction.short)").gridColumnAlignment(.trailing).frame(width: 54)
                        Text(T("判定")).gridColumnAlignment(.leading).frame(width: 60)
                    }
                    .font(.system(size: 9.5, weight: .medium))
                    .foregroundStyle(.tertiary)

                    Divider().gridCellColumns(8).opacity(0.25)

                    ForEach(block.rows) { r in
                        GridRow {
                            FeatureNameCell(feature: r.feature, color: meta.color,
                                            negative: !r.positive) {
                                withAnimation(Motion.snappy) { _ = hidden.insert(r.feature) }
                            }
                            .frame(width: 132, alignment: .leading)

                            Text(Features.glossText(r.feature))
                                .font(.system(size: 10.5))
                                .foregroundStyle(.secondary)
                                .lineLimit(1)
                                .frame(width: 78, alignment: .leading)

                            Text(String(format: "%+.2f", r.aMean))
                                .font(.system(size: 10.5, design: .rounded).monospacedDigit())
                                .foregroundStyle(SeriesColors.a)
                                .frame(width: 52, alignment: .trailing)
                            Text(String(format: "%+.2f", r.bMean))
                                .font(.system(size: 10.5, design: .rounded).monospacedDigit())
                                .foregroundStyle(SeriesColors.b)
                                .frame(width: 52, alignment: .trailing)
                            Text(String(format: "%+.2f", r.delta))
                                .font(.system(size: 10.5, weight: .medium, design: .rounded).monospacedDigit())
                                .frame(width: 52, alignment: .trailing)
                            pCell(correction == .none ? r.tP : r.tQ)
                                .frame(width: 54, alignment: .trailing)
                            pCell(correction == .none ? r.uP : r.uQ)
                                .frame(width: 54, alignment: .trailing)

                            let v = verdict(r)
                            Text(v.0)
                                .font(.system(size: 9.5, weight: .medium))
                                .foregroundStyle(v.1)
                                .frame(width: 60, alignment: .leading)
                        }
                        .padding(.vertical, 1)
                        .background {
                            if isSignificant(r) { meta.color.opacity(0.05) }
                        }
                    }
                }
            }
        }
        .glassCard()
    }

    private func pCell(_ p: Double?) -> some View {
        Group {
            if let p {
                Text(p < 0.0001 ? "<.0001" : String(format: "%.4f", p))
                    .font(.system(size: 10.5, weight: p < 0.05 ? .semibold : .regular,
                                  design: .rounded).monospacedDigit())
                    .foregroundStyle(p < 0.05 ? AnyShapeStyle(Color.primary) : AnyShapeStyle(.tertiary))
            } else {
                Text("—").font(.system(size: 10.5)).foregroundStyle(.tertiary)
            }
        }
    }

    private var footnote: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack(spacing: 5) {
                Image(systemName: "info.circle").font(.system(size: 9)).foregroundStyle(.tertiary)
                Text(T("每个变量用「每篇的 z 分数」当样本，做两组比较；A、B 篇数不同不影响 Welch t。"))
                    .font(.system(size: 10)).foregroundStyle(.secondary)
            }
            HStack(spacing: 5) {
                Image(systemName: "info.circle").font(.system(size: 9)).foregroundStyle(.tertiary)
                Text(T("带 − 的是该维度的负向特征。`Count: All tags` 多出来的普通词性没有 z 分数——z 需要 Biber 的 mean/sd，所以不在此表。"))
                    .font(.system(size: 10)).foregroundStyle(.secondary)
            }
        }
    }

    // MARK: 导出全部

    private func exportCSV(_ a: Corpus, _ b: Corpus) {
        let panel = NSSavePanel()
        panel.allowedContentTypes = [.commaSeparatedText]
        panel.nameFieldStringValue = "ZCompare_\(a.name)_vs_\(b.name).csv"
        guard panel.runModal() == .OK, let url = panel.url else { return }

        var lines = ["dimension,feature,gloss,direction,A_mean_z,B_mean_z,delta,t_p,t_q,u_p,u_q,verdict"]
        for block in buildBlocks() {
            for r in block.rows {
                let v = verdict(r)
                lines.append([
                    "D\(block.id)", r.feature, Features.glossText(r.feature),
                    r.positive ? "+" : "-",
                    String(format: "%.4f", r.aMean), String(format: "%.4f", r.bMean),
                    String(format: "%.4f", r.delta),
                    r.tP.map { String(format: "%.6f", $0) } ?? "",
                    String(format: "%.6f", r.tQ),
                    r.uP.map { String(format: "%.6f", $0) } ?? "",
                    String(format: "%.6f", r.uQ), v.0,
                ].joined(separator: ","))
            }
        }
        try? lines.joined(separator: "\n").write(to: url, atomically: true, encoding: .utf8)
    }
}

// MARK: - 可删除的特征名

/// 悬停时在名字右侧浮现一个 ✕，点一下把这一行从显示里移除（不动数据）
private struct FeatureNameCell: View {
    var feature: String
    var color: Color
    var negative: Bool
    var onDelete: () -> Void

    @State private var hover = false

    var body: some View {
        HStack(spacing: 4) {
            Text(feature)
                .font(.system(size: 11, weight: .semibold, design: .monospaced))
                .foregroundStyle(color)
                .lineLimit(1)

            if hover {
                Button(action: onDelete) {
                    Image(systemName: "xmark.circle.fill")
                        .font(.system(size: 9.5))
                        .foregroundStyle(Color.red.opacity(0.75))
                }
                .buttonStyle(.plain)
                .help(T("从表中移除（只影响显示）"))
                .transition(.scale(scale: 0.6).combined(with: .opacity))
            } else if negative {
                Text("−")
                    .font(.system(size: 9, weight: .bold))
                    .foregroundStyle(.tertiary)
                    .help(T("该维度的负向特征"))
            }

            Spacer(minLength: 0)
        }
        .contentShape(Rectangle())
        .onHover { inside in
            withAnimation(Motion.quick) { hover = inside }
        }
    }
}
